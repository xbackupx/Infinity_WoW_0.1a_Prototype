﻿namespace EventAI
{
    partial class FormMain
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.новыйСкриптToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сохранитьСкриптToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.настройкиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.помощьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.HelpEntry = new System.Windows.Forms.ToolTip(this.components);
            this._tbComment = new System.Windows.Forms.TextBox();
            this._cbActionType2 = new System.Windows.Forms.ComboBox();
            this._cbActionType3 = new System.Windows.Forms.ComboBox();
            this._cbActionType1 = new System.Windows.Forms.ComboBox();
            this._cbEventType = new System.Windows.Forms.ComboBox();
            this._tbEntryNpc = new System.Windows.Forms.TextBox();
            this._tbShance = new System.Windows.Forms.TextBox();
            this._tbTextContentDefault = new System.Windows.Forms.TextBox();
            this._cbLocale = new System.Windows.Forms.ComboBox();
            this._tbTextID = new System.Windows.Forms.TextBox();
            this._cbLenguage = new System.Windows.Forms.ComboBox();
            this._tbCommentAITexts = new System.Windows.Forms.TextBox();
            this._tbTextContentLocales = new System.Windows.Forms.TextBox();
            this._clbEventFlag = new System.Windows.Forms.CheckedListBox();
            this._cmFlag = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.UnselectALL1 = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectAll1 = new System.Windows.Forms.ToolStripMenuItem();
            this.Revert1 = new System.Windows.Forms.ToolStripMenuItem();
            this._tbSummonY = new System.Windows.Forms.TextBox();
            this._tbSummonX = new System.Windows.Forms.TextBox();
            this._tbSummonID = new System.Windows.Forms.TextBox();
            this._cbGossipCondtion_1 = new System.Windows.Forms.ComboBox();
            this._cbGossipCondtion_2 = new System.Windows.Forms.ComboBox();
            this._tbCreatureGossip = new System.Windows.Forms.TextBox();
            this._cbGossipOptionIcon = new System.Windows.Forms.ComboBox();
            this._cbGossipOptionID = new System.Windows.Forms.ComboBox();
            this._cbGossipOptionNpcFlag = new System.Windows.Forms.ComboBox();
            this._cbGossipOptionCondtion_2 = new System.Windows.Forms.ComboBox();
            this._cbGossipOptionCondtion_1 = new System.Windows.Forms.ComboBox();
            this._cbGossipOptionCondtion_3 = new System.Windows.Forms.ComboBox();
            this._tbScriptID = new System.Windows.Forms.TextBox();
            this._clbPhase = new System.Windows.Forms.CheckedListBox();
            this._cmPhase = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.UnselectALL = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectAll = new System.Windows.Forms.ToolStripMenuItem();
            this.Revert = new System.Windows.Forms.ToolStripMenuItem();
            this._tpScript = new System.Windows.Forms.TabPage();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this._bFind = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this._tbFilterCreat = new System.Windows.Forms.TextBox();
            this._tbFilterNum = new System.Windows.Forms.TextBox();
            this._cbFilteActionType = new System.Windows.Forms.ComboBox();
            this._cbFilteEventType = new System.Windows.Forms.ComboBox();
            this._lvScripts = new System.Windows.Forms.ListView();
            this.pMain = new System.Windows.Forms.Panel();
            this.rtbScriptOut = new System.Windows.Forms.RichTextBox();
            this._bCreateAIScript = new System.Windows.Forms.Button();
            this._bWriteFiles = new System.Windows.Forms.Button();
            this._gbPhase = new System.Windows.Forms.GroupBox();
            this._gbEventFlag = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this._gbEventType = new System.Windows.Forms.GroupBox();
            this.lEventType4 = new System.Windows.Forms.Label();
            this.lEventType3 = new System.Windows.Forms.Label();
            this.lEventType2 = new System.Windows.Forms.Label();
            this.lEventType1 = new System.Windows.Forms.Label();
            this._cbEventParametr4 = new System.Windows.Forms.ComboBox();
            this._cbEventParametr3 = new System.Windows.Forms.ComboBox();
            this._cbEventParametr1 = new System.Windows.Forms.ComboBox();
            this._cbEventParametr2 = new System.Windows.Forms.ComboBox();
            this._gbAction2 = new System.Windows.Forms.GroupBox();
            this._cbActionParam2_1 = new System.Windows.Forms.ComboBox();
            this.lActionParam2_1 = new System.Windows.Forms.Label();
            this.lActionParam2_3 = new System.Windows.Forms.Label();
            this.lActionParam2_2 = new System.Windows.Forms.Label();
            this._cbActionParam2_2 = new System.Windows.Forms.ComboBox();
            this._cbActionParam2_3 = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this._gbAction1 = new System.Windows.Forms.GroupBox();
            this._cbActionParam1_1 = new System.Windows.Forms.ComboBox();
            this.lActionParam1_3 = new System.Windows.Forms.Label();
            this.lActionParam1_2 = new System.Windows.Forms.Label();
            this.lActionParam1_1 = new System.Windows.Forms.Label();
            this._cbActionParam1_3 = new System.Windows.Forms.ComboBox();
            this._cbActionParam1_2 = new System.Windows.Forms.ComboBox();
            this._gbAction3 = new System.Windows.Forms.GroupBox();
            this._cbActionParam3_1 = new System.Windows.Forms.ComboBox();
            this.lActionParam3_3 = new System.Windows.Forms.Label();
            this.lActionParam3_2 = new System.Windows.Forms.Label();
            this.lActionParam3_1 = new System.Windows.Forms.Label();
            this._cbActionParam3_3 = new System.Windows.Forms.ComboBox();
            this._cbActionParam3_2 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lDateTime = new System.Windows.Forms.Label();
            this._tPanel = new System.Windows.Forms.TabControl();
            this._tpText = new System.Windows.Forms.TabPage();
            this._bTextSearch = new System.Windows.Forms.Button();
            this._lvText = new System.Windows.Forms.ListView();
            this.rtbTextOut = new System.Windows.Forms.RichTextBox();
            this.lDateTime2 = new System.Windows.Forms.Label();
            this.bCreateTextQuery = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this._bSoundSearch = new System.Windows.Forms.Button();
            this._cbTextEmote = new System.Windows.Forms.ComboBox();
            this._cbSoundEntry = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this._cbMessageType = new System.Windows.Forms.ComboBox();
            this._tpSummon = new System.Windows.Forms.TabPage();
            this._bCreateSummon = new System.Windows.Forms.Button();
            this._bWriteSummon = new System.Windows.Forms.Button();
            this._bSummonSearch = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this._tbSummonSps = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this._tbSummonO = new System.Windows.Forms.TextBox();
            this._tbSummonZ = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this._tbSummonComment = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this._rtbSummon = new System.Windows.Forms.RichTextBox();
            this._lvSummon = new System.Windows.Forms.ListView();
            this.columnHeader39 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader40 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader41 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader42 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader43 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader44 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader45 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this._tpGossip = new System.Windows.Forms.TabPage();
            this.rtbGossipMenuOut = new System.Windows.Forms.RichTextBox();
            this._gbGossipMenu = new System.Windows.Forms.GroupBox();
            this.label23 = new System.Windows.Forms.Label();
            this._bWriteFilesGossip = new System.Windows.Forms.Button();
            this._gbGossipCondtion2 = new System.Windows.Forms.GroupBox();
            this._cbCondtion2Value_1 = new System.Windows.Forms.ComboBox();
            this._cbCondtion2Value_2 = new System.Windows.Forms.ComboBox();
            this.lCondition2Val1 = new System.Windows.Forms.Label();
            this.lCondition2Val2 = new System.Windows.Forms.Label();
            this._bCreateGossip = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this._gbGossipCondtion1 = new System.Windows.Forms.GroupBox();
            this._cbCondtion1Value_2 = new System.Windows.Forms.ComboBox();
            this.lCondition1Val1 = new System.Windows.Forms.Label();
            this.lCondition1Val2 = new System.Windows.Forms.Label();
            this._cbCondtion1Value_1 = new System.Windows.Forms.ComboBox();
            this._tbGossipEntry = new System.Windows.Forms.TextBox();
            this._GossipTextID = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this._panelGossip_menu = new System.Windows.Forms.Panel();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this._lvNpc_text = new System.Windows.Forms.ListView();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this._lblnpctext = new System.Windows.Forms.Label();
            this._lvGossip_Creature = new System.Windows.Forms.ListView();
            this.columnHeader54 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader55 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this._lvGossip_menu = new System.Windows.Forms.ListView();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this._tbFilterGossip = new System.Windows.Forms.TextBox();
            this._rbGossip = new System.Windows.Forms.RadioButton();
            this._rbCreaure = new System.Windows.Forms.RadioButton();
            this._rbTextID = new System.Windows.Forms.RadioButton();
            this._bGossipSearch = new System.Windows.Forms.Button();
            this._tpGossipOption = new System.Windows.Forms.TabPage();
            this._gbGossipMenuOption = new System.Windows.Forms.GroupBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this._bGossipOptionCreate = new System.Windows.Forms.Button();
            this._bGossipOptionRecord = new System.Windows.Forms.Button();
            this.rtbGossipOptionMenuOut = new System.Windows.Forms.RichTextBox();
            this._gbGossipOptionCondtion3 = new System.Windows.Forms.GroupBox();
            this._cbOptionCondtion3Value_1 = new System.Windows.Forms.ComboBox();
            this._cbOptionCondtion3Value_2 = new System.Windows.Forms.ComboBox();
            this.lGossipOptionCondtion3Val1 = new System.Windows.Forms.Label();
            this.lGossipOptionCondtion3Val2 = new System.Windows.Forms.Label();
            this._gbGossipOptionCondtion2 = new System.Windows.Forms.GroupBox();
            this._cbOptionCondtion2Value_1 = new System.Windows.Forms.ComboBox();
            this._cbOptionCondtion2Value_2 = new System.Windows.Forms.ComboBox();
            this.lGossipOptionCondtion2Val1 = new System.Windows.Forms.Label();
            this.lGossipOptionCondtion2Val2 = new System.Windows.Forms.Label();
            this._gbGossipOptionCondtion1 = new System.Windows.Forms.GroupBox();
            this._cbOptionCondtion1Value_2 = new System.Windows.Forms.ComboBox();
            this.lGossipOptionCondtion1Val1 = new System.Windows.Forms.Label();
            this.lGossipOptionCondtion1Val2 = new System.Windows.Forms.Label();
            this._cbOptionCondtion1Value_1 = new System.Windows.Forms.ComboBox();
            this.label32 = new System.Windows.Forms.Label();
            this._tbGossipBoxText = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this._tbGossipBoxMoney = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this._tbGossipBoxCoded = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this._tbGossipAction = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this._tbGossipPOI_id = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this._tbGossipNpcMenu = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this._tbGossipOptionText = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this._tbGossipID = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this._tbGossipMenuID = new System.Windows.Forms.TextBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this._lvGossip_Option = new System.Windows.Forms.ListView();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this._bFilterMenuOption = new System.Windows.Forms.Button();
            this._tbfilterGossipMenu = new System.Windows.Forms.TextBox();
            this._rbGossipMenuOption = new System.Windows.Forms.RadioButton();
            this._tbNpcText = new System.Windows.Forms.TabPage();
            this._gpText = new System.Windows.Forms.GroupBox();
            this._tbNpc_textEm7_5 = new System.Windows.Forms.TextBox();
            this._cbNpc_textLang7 = new System.Windows.Forms.ComboBox();
            this._tbNpc_text7_1 = new System.Windows.Forms.TextBox();
            this.label107 = new System.Windows.Forms.Label();
            this.label108 = new System.Windows.Forms.Label();
            this._tbNpc_textEm7_1 = new System.Windows.Forms.TextBox();
            this._tbNpc_text7_0 = new System.Windows.Forms.TextBox();
            this.label109 = new System.Windows.Forms.Label();
            this.label110 = new System.Windows.Forms.Label();
            this.label111 = new System.Windows.Forms.Label();
            this._tbNpc_textEm7_2 = new System.Windows.Forms.TextBox();
            this.label112 = new System.Windows.Forms.Label();
            this._tbNpc_textProb7 = new System.Windows.Forms.TextBox();
            this._tbNpc_textEm7_4 = new System.Windows.Forms.TextBox();
            this.label113 = new System.Windows.Forms.Label();
            this.label114 = new System.Windows.Forms.Label();
            this.label115 = new System.Windows.Forms.Label();
            this.label116 = new System.Windows.Forms.Label();
            this._tbNpc_textEm7_3 = new System.Windows.Forms.TextBox();
            this._tbNpc_textEm7_0 = new System.Windows.Forms.TextBox();
            this._tbNpc_textEm6_5 = new System.Windows.Forms.TextBox();
            this._cbNpc_textLang6 = new System.Windows.Forms.ComboBox();
            this._tbNpc_text6_1 = new System.Windows.Forms.TextBox();
            this.label97 = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this._tbNpc_textEm6_1 = new System.Windows.Forms.TextBox();
            this._tbNpc_text6_0 = new System.Windows.Forms.TextBox();
            this.label99 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this._tbNpc_textEm6_2 = new System.Windows.Forms.TextBox();
            this.label102 = new System.Windows.Forms.Label();
            this._tbNpc_textProb6 = new System.Windows.Forms.TextBox();
            this._tbNpc_textEm6_4 = new System.Windows.Forms.TextBox();
            this.label103 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this._tbNpc_textEm6_3 = new System.Windows.Forms.TextBox();
            this._tbNpc_textEm6_0 = new System.Windows.Forms.TextBox();
            this._tbNpc_textEm5_5 = new System.Windows.Forms.TextBox();
            this._cbNpc_textLang5 = new System.Windows.Forms.ComboBox();
            this._tbNpc_text5_1 = new System.Windows.Forms.TextBox();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this._tbNpc_textEm5_1 = new System.Windows.Forms.TextBox();
            this._tbNpc_text5_0 = new System.Windows.Forms.TextBox();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this._tbNpc_textEm5_2 = new System.Windows.Forms.TextBox();
            this.label72 = new System.Windows.Forms.Label();
            this._tbNpc_textProb5 = new System.Windows.Forms.TextBox();
            this._tbNpc_textEm5_4 = new System.Windows.Forms.TextBox();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this._tbNpc_textEm5_3 = new System.Windows.Forms.TextBox();
            this._tbNpc_textEm5_0 = new System.Windows.Forms.TextBox();
            this._tbNpc_textEm4_5 = new System.Windows.Forms.TextBox();
            this._cbNpc_textLang4 = new System.Windows.Forms.ComboBox();
            this._tbNpc_text4_1 = new System.Windows.Forms.TextBox();
            this.label77 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this._tbNpc_textEm4_1 = new System.Windows.Forms.TextBox();
            this._tbNpc_text4_0 = new System.Windows.Forms.TextBox();
            this.label79 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this._tbNpc_textEm4_2 = new System.Windows.Forms.TextBox();
            this.label82 = new System.Windows.Forms.Label();
            this._tbNpc_textProb4 = new System.Windows.Forms.TextBox();
            this._tbNpc_textEm4_4 = new System.Windows.Forms.TextBox();
            this.label83 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this._tbNpc_textEm4_3 = new System.Windows.Forms.TextBox();
            this._tbNpc_textEm4_0 = new System.Windows.Forms.TextBox();
            this._cbNpc_textLang3 = new System.Windows.Forms.ComboBox();
            this._tbNpc_text3_1 = new System.Windows.Forms.TextBox();
            this.label87 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this._tbNpc_textEm3_1 = new System.Windows.Forms.TextBox();
            this._tbNpc_text3_0 = new System.Windows.Forms.TextBox();
            this.label89 = new System.Windows.Forms.Label();
            this._tbNpc_textEm3_5 = new System.Windows.Forms.TextBox();
            this.label90 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this._tbNpc_textEm3_2 = new System.Windows.Forms.TextBox();
            this.label92 = new System.Windows.Forms.Label();
            this._tbNpc_textProb3 = new System.Windows.Forms.TextBox();
            this._tbNpc_textEm3_4 = new System.Windows.Forms.TextBox();
            this.label93 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this._tbNpc_textEm3_3 = new System.Windows.Forms.TextBox();
            this._tbNpc_textEm3_0 = new System.Windows.Forms.TextBox();
            this._tbNpc_textEm2_5 = new System.Windows.Forms.TextBox();
            this._cbNpc_textLang2 = new System.Windows.Forms.ComboBox();
            this._tbNpc_text2_1 = new System.Windows.Forms.TextBox();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this._tbNpc_textEm2_1 = new System.Windows.Forms.TextBox();
            this._tbNpc_text2_0 = new System.Windows.Forms.TextBox();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this._tbNpc_textEm2_2 = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this._tbNpc_textProb2 = new System.Windows.Forms.TextBox();
            this._tbNpc_textEm2_4 = new System.Windows.Forms.TextBox();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this._tbNpc_textEm2_3 = new System.Windows.Forms.TextBox();
            this._tbNpc_textEm2_0 = new System.Windows.Forms.TextBox();
            this._tbNpc_textEm1_5 = new System.Windows.Forms.TextBox();
            this._cbNpc_textLang1 = new System.Windows.Forms.ComboBox();
            this._tbNpc_text1_1 = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this._tbNpc_textEm1_1 = new System.Windows.Forms.TextBox();
            this._tbNpc_text1_0 = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this._tbNpc_textEm1_2 = new System.Windows.Forms.TextBox();
            this.label52 = new System.Windows.Forms.Label();
            this._tbNpc_textProb1 = new System.Windows.Forms.TextBox();
            this._tbNpc_textEm1_4 = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this._tbNpc_textEm1_3 = new System.Windows.Forms.TextBox();
            this._tbNpc_textEm1_0 = new System.Windows.Forms.TextBox();
            this._cbNpc_textLang0 = new System.Windows.Forms.ComboBox();
            this.label36 = new System.Windows.Forms.Label();
            this.bNpcTextCreate = new System.Windows.Forms.Button();
            this._tbNpc_textID = new System.Windows.Forms.TextBox();
            this._tbNpc_text0_1 = new System.Windows.Forms.TextBox();
            this.bNpcTextRecord = new System.Windows.Forms.Button();
            this.label37 = new System.Windows.Forms.Label();
            this.rtbNpcTextOut = new System.Windows.Forms.RichTextBox();
            this.label46 = new System.Windows.Forms.Label();
            this._tbNpc_textEm0_1 = new System.Windows.Forms.TextBox();
            this._tbNpc_text0_0 = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this._tbNpc_textEm0_5 = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this._tbNpc_textEm0_2 = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this._tbNpc_textProb0 = new System.Windows.Forms.TextBox();
            this._tbNpc_textEm0_4 = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this._tbNpc_textEm0_3 = new System.Windows.Forms.TextBox();
            this._tbNpc_textEm0_0 = new System.Windows.Forms.TextBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this._lvNpcText = new System.Windows.Forms.ListView();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this._bFilterNpcText = new System.Windows.Forms.Button();
            this._tbFilterNpcText = new System.Windows.Forms.TextBox();
            this.menuStrip1.SuspendLayout();
            this._cmFlag.SuspendLayout();
            this._cmPhase.SuspendLayout();
            this._tpScript.SuspendLayout();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.pMain.SuspendLayout();
            this._gbPhase.SuspendLayout();
            this._gbEventFlag.SuspendLayout();
            this._gbEventType.SuspendLayout();
            this._gbAction2.SuspendLayout();
            this._gbAction1.SuspendLayout();
            this._gbAction3.SuspendLayout();
            this._tPanel.SuspendLayout();
            this._tpText.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this._tpSummon.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this._tpGossip.SuspendLayout();
            this._gbGossipMenu.SuspendLayout();
            this._gbGossipCondtion2.SuspendLayout();
            this._gbGossipCondtion1.SuspendLayout();
            this._panelGossip_menu.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this._tpGossipOption.SuspendLayout();
            this._gbGossipMenuOption.SuspendLayout();
            this._gbGossipOptionCondtion3.SuspendLayout();
            this._gbGossipOptionCondtion2.SuspendLayout();
            this._gbGossipOptionCondtion1.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this._tbNpcText.SuspendLayout();
            this._gpText.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.toolStripMenuItem2,
            this.помощьToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1056, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.новыйСкриптToolStripMenuItem,
            this.сохранитьСкриптToolStripMenuItem});
            this.toolStripMenuItem1.Enabled = false;
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(49, 20);
            this.toolStripMenuItem1.Text = "Script";
            // 
            // новыйСкриптToolStripMenuItem
            // 
            this.новыйСкриптToolStripMenuItem.Name = "новыйСкриптToolStripMenuItem";
            this.новыйСкриптToolStripMenuItem.Size = new System.Drawing.Size(131, 22);
            this.новыйСкриптToolStripMenuItem.Text = "View script";
            // 
            // сохранитьСкриптToolStripMenuItem
            // 
            this.сохранитьСкриптToolStripMenuItem.Name = "сохранитьСкриптToolStripMenuItem";
            this.сохранитьСкриптToolStripMenuItem.Size = new System.Drawing.Size(131, 22);
            this.сохранитьСкриптToolStripMenuItem.Text = "Save Script";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.настройкиToolStripMenuItem});
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(61, 20);
            this.toolStripMenuItem2.Text = "Settings";
            // 
            // настройкиToolStripMenuItem
            // 
            this.настройкиToolStripMenuItem.Name = "настройкиToolStripMenuItem";
            this.настройкиToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.настройкиToolStripMenuItem.Text = "Options";
            this.настройкиToolStripMenuItem.Click += new System.EventHandler(this.ToolStripMenuItem_Click);
            // 
            // помощьToolStripMenuItem
            // 
            this.помощьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.оПрограммеToolStripMenuItem});
            this.помощьToolStripMenuItem.Name = "помощьToolStripMenuItem";
            this.помощьToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.помощьToolStripMenuItem.Text = "Help";
            // 
            // оПрограммеToolStripMenuItem
            // 
            this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
            this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.оПрограммеToolStripMenuItem.Text = "About";
            this.оПрограммеToolStripMenuItem.Click += new System.EventHandler(this.AboutToolStripMenuItem_Click);
            // 
            // HelpEntry
            // 
            this.HelpEntry.AutoPopDelay = 10000;
            this.HelpEntry.ForeColor = System.Drawing.Color.MediumBlue;
            this.HelpEntry.InitialDelay = 100;
            this.HelpEntry.IsBalloon = true;
            this.HelpEntry.ReshowDelay = 2000;
            this.HelpEntry.ShowAlways = true;
            // 
            // _tbComment
            // 
            this._tbComment.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this._tbComment.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this._tbComment.Location = new System.Drawing.Point(91, 347);
            this._tbComment.MaxLength = 150;
            this._tbComment.Name = "_tbComment";
            this._tbComment.Size = new System.Drawing.Size(833, 20);
            this._tbComment.TabIndex = 26;
            this._tbComment.Text = "ytdb";
            this.HelpEntry.SetToolTip(this._tbComment, "Always leave a comment\r\nIt will be simpler, and this will make it easier where ot" +
                    "hers\r\ncould get confuse");
            // 
            // _cbActionType2
            // 
            this._cbActionType2.DropDownHeight = 400;
            this._cbActionType2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._cbActionType2.ForeColor = System.Drawing.Color.Blue;
            this._cbActionType2.FormattingEnabled = true;
            this._cbActionType2.IntegralHeight = false;
            this._cbActionType2.Location = new System.Drawing.Point(6, 19);
            this._cbActionType2.Name = "_cbActionType2";
            this._cbActionType2.Size = new System.Drawing.Size(238, 21);
            this._cbActionType2.TabIndex = 18;
            this.HelpEntry.SetToolTip(this._cbActionType2, "Choose the type of action");
            this._cbActionType2.SelectedIndexChanged += new System.EventHandler(this.ActionType_SelectedIndexChanged_2);
            // 
            // _cbActionType3
            // 
            this._cbActionType3.DropDownHeight = 400;
            this._cbActionType3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._cbActionType3.ForeColor = System.Drawing.Color.Blue;
            this._cbActionType3.FormattingEnabled = true;
            this._cbActionType3.IntegralHeight = false;
            this._cbActionType3.Location = new System.Drawing.Point(6, 18);
            this._cbActionType3.Name = "_cbActionType3";
            this._cbActionType3.Size = new System.Drawing.Size(238, 21);
            this._cbActionType3.TabIndex = 22;
            this.HelpEntry.SetToolTip(this._cbActionType3, "Choose the type of action");
            this._cbActionType3.SelectedIndexChanged += new System.EventHandler(this.ActionType_SelectedIndexChanged_3);
            // 
            // _cbActionType1
            // 
            this._cbActionType1.DropDownHeight = 400;
            this._cbActionType1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._cbActionType1.ForeColor = System.Drawing.Color.Blue;
            this._cbActionType1.FormattingEnabled = true;
            this._cbActionType1.IntegralHeight = false;
            this._cbActionType1.Location = new System.Drawing.Point(6, 19);
            this._cbActionType1.Name = "_cbActionType1";
            this._cbActionType1.Size = new System.Drawing.Size(238, 21);
            this._cbActionType1.TabIndex = 14;
            this.HelpEntry.SetToolTip(this._cbActionType1, "Choose the type of action");
            this._cbActionType1.SelectedIndexChanged += new System.EventHandler(this.ActionType_SelectedIndexChanged_1);
            // 
            // _cbEventType
            // 
            this._cbEventType.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this._cbEventType.DropDownHeight = 400;
            this._cbEventType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._cbEventType.DropDownWidth = 200;
            this._cbEventType.ForeColor = System.Drawing.Color.Blue;
            this._cbEventType.FormattingEnabled = true;
            this._cbEventType.IntegralHeight = false;
            this._cbEventType.Location = new System.Drawing.Point(6, 18);
            this._cbEventType.Name = "_cbEventType";
            this._cbEventType.Size = new System.Drawing.Size(238, 21);
            this._cbEventType.TabIndex = 9;
            this._cbEventType.Tag = "0-TIMER";
            this.HelpEntry.SetToolTip(this._cbEventType, "Specify the type of event");
            this._cbEventType.SelectedIndexChanged += new System.EventHandler(this.EventType_SelectedIndexChanged);
            // 
            // _tbEntryNpc
            // 
            this._tbEntryNpc.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this._tbEntryNpc.Location = new System.Drawing.Point(151, 291);
            this._tbEntryNpc.MaxLength = 10;
            this._tbEntryNpc.Name = "_tbEntryNpc";
            this._tbEntryNpc.Size = new System.Drawing.Size(114, 20);
            this._tbEntryNpc.TabIndex = 2;
            this._tbEntryNpc.Text = "1";
            this.HelpEntry.SetToolTip(this._tbEntryNpc, "Enter creatureID use creature_template");
            this._tbEntryNpc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.NumberScripts_KeyPress);
            // 
            // _tbShance
            // 
            this._tbShance.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this._tbShance.Location = new System.Drawing.Point(151, 316);
            this._tbShance.MaxLength = 3;
            this._tbShance.Name = "_tbShance";
            this._tbShance.Size = new System.Drawing.Size(114, 20);
            this._tbShance.TabIndex = 4;
            this._tbShance.Text = "100";
            this.HelpEntry.SetToolTip(this._tbShance, "Enter proc");
            this._tbShance.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.NumberScripts_KeyPress);
            // 
            // _tbTextContentDefault
            // 
            this._tbTextContentDefault.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this._tbTextContentDefault.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this._tbTextContentDefault.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this._tbTextContentDefault.Location = new System.Drawing.Point(285, 19);
            this._tbTextContentDefault.Multiline = true;
            this._tbTextContentDefault.Name = "_tbTextContentDefault";
            this._tbTextContentDefault.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this._tbTextContentDefault.Size = new System.Drawing.Size(745, 99);
            this._tbTextContentDefault.TabIndex = 3;
            this.HelpEntry.SetToolTip(this._tbTextContentDefault, "Here we must enter\r\n originaly text messages\r\nThe English");
            // 
            // _cbLocale
            // 
            this._cbLocale.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._cbLocale.ForeColor = System.Drawing.Color.Navy;
            this._cbLocale.FormattingEnabled = true;
            this._cbLocale.Location = new System.Drawing.Point(417, 121);
            this._cbLocale.Name = "_cbLocale";
            this._cbLocale.Size = new System.Drawing.Size(216, 21);
            this._cbLocale.TabIndex = 6;
            this.HelpEntry.SetToolTip(this._cbLocale, "Enter the localization language, \r\n npo default Russian (8)");
            // 
            // _tbTextID
            // 
            this._tbTextID.ForeColor = System.Drawing.Color.Red;
            this._tbTextID.Location = new System.Drawing.Point(85, 20);
            this._tbTextID.MaxLength = 7;
            this._tbTextID.Name = "_tbTextID";
            this._tbTextID.Size = new System.Drawing.Size(99, 20);
            this._tbTextID.TabIndex = 4;
            this._tbTextID.Text = "1";
            this.HelpEntry.SetToolTip(this._tbTextID, "ID который укзыветься в скриптах\r\n\"-\" ставиться автоматически");
            this._tbTextID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.NumberScripts_KeyPress);
            // 
            // _cbLenguage
            // 
            this._cbLenguage.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._cbLenguage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this._cbLenguage.FormattingEnabled = true;
            this._cbLenguage.Location = new System.Drawing.Point(6, 202);
            this._cbLenguage.Name = "_cbLenguage";
            this._cbLenguage.Size = new System.Drawing.Size(254, 21);
            this._cbLenguage.TabIndex = 7;
            this.HelpEntry.SetToolTip(this._cbLenguage, "Specify in what language\r\nbudet clear message");
            // 
            // _tbCommentAITexts
            // 
            this._tbCommentAITexts.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this._tbCommentAITexts.Location = new System.Drawing.Point(92, 255);
            this._tbCommentAITexts.Name = "_tbCommentAITexts";
            this._tbCommentAITexts.Size = new System.Drawing.Size(938, 20);
            this._tbCommentAITexts.TabIndex = 13;
            this._tbCommentAITexts.Text = "ytdb";
            this.HelpEntry.SetToolTip(this._tbCommentAITexts, "Do not forget about your comment");
            // 
            // _tbTextContentLocales
            // 
            this._tbTextContentLocales.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this._tbTextContentLocales.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this._tbTextContentLocales.ForeColor = System.Drawing.Color.Navy;
            this._tbTextContentLocales.Location = new System.Drawing.Point(285, 146);
            this._tbTextContentLocales.Multiline = true;
            this._tbTextContentLocales.Name = "_tbTextContentLocales";
            this._tbTextContentLocales.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this._tbTextContentLocales.Size = new System.Drawing.Size(745, 103);
            this._tbTextContentLocales.TabIndex = 14;
            this.HelpEntry.SetToolTip(this._tbTextContentLocales, "Then enter the text localization");
            // 
            // _clbEventFlag
            // 
            this._clbEventFlag.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this._clbEventFlag.CheckOnClick = true;
            this._clbEventFlag.ContextMenuStrip = this._cmFlag;
            this._clbEventFlag.Dock = System.Windows.Forms.DockStyle.Fill;
            this._clbEventFlag.FormattingEnabled = true;
            this._clbEventFlag.Items.AddRange(new object[] {
            "1-REPEATABLE",
            "2-DIFFICULTY(Normal Mode 10)",
            "4-DIFFICULTY(Normal Mode 25)",
            "8-DIFFICULTY(Heroic Mode 10)",
            "16-DIFFICULTY(Heroic Mode 25)",
            "32-RANDOM ACTION",
            "64-Reserved (not used)",
            "128-DEBUG_ONLY"});
            this._clbEventFlag.Location = new System.Drawing.Point(3, 16);
            this._clbEventFlag.Name = "_clbEventFlag";
            this._clbEventFlag.Size = new System.Drawing.Size(244, 124);
            this._clbEventFlag.TabIndex = 33;
            this.HelpEntry.SetToolTip(this._clbEventFlag, resources.GetString("_clbEventFlag.ToolTip"));
            this._clbEventFlag.SelectedIndexChanged += new System.EventHandler(this.clbEventFlag_SelectedIndexChanged);
            this._clbEventFlag.SelectedValueChanged += new System.EventHandler(this._clbEventFlag_SelectedValueChanged);
            // 
            // _cmFlag
            // 
            this._cmFlag.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.UnselectALL1,
            this.SelectAll1,
            this.Revert1});
            this._cmFlag.Name = "_cmFlag";
            this._cmFlag.Size = new System.Drawing.Size(135, 70);
            // 
            // UnselectALL1
            // 
            this.UnselectALL1.Name = "UnselectALL1";
            this.UnselectALL1.Size = new System.Drawing.Size(134, 22);
            this.UnselectALL1.Text = "Unselect all";
            this.UnselectALL1.Click += new System.EventHandler(this.Revert1_Click);
            // 
            // SelectAll1
            // 
            this.SelectAll1.Name = "SelectAll1";
            this.SelectAll1.Size = new System.Drawing.Size(134, 22);
            this.SelectAll1.Text = "Select all";
            this.SelectAll1.Click += new System.EventHandler(this.Revert1_Click);
            // 
            // Revert1
            // 
            this.Revert1.Name = "Revert1";
            this.Revert1.Size = new System.Drawing.Size(134, 22);
            this.Revert1.Text = "Revert";
            this.Revert1.Click += new System.EventHandler(this.Revert1_Click);
            // 
            // _tbSummonY
            // 
            this._tbSummonY.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this._tbSummonY.Location = new System.Drawing.Point(89, 52);
            this._tbSummonY.MaxLength = 3;
            this._tbSummonY.Name = "_tbSummonY";
            this._tbSummonY.Size = new System.Drawing.Size(186, 20);
            this._tbSummonY.TabIndex = 16;
            this._tbSummonY.Text = "0";
            this.HelpEntry.SetToolTip(this._tbSummonY, "The data from the DBC");
            // 
            // _tbSummonX
            // 
            this._tbSummonX.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this._tbSummonX.Location = new System.Drawing.Point(89, 19);
            this._tbSummonX.MaxLength = 5;
            this._tbSummonX.Name = "_tbSummonX";
            this._tbSummonX.Size = new System.Drawing.Size(186, 20);
            this._tbSummonX.TabIndex = 15;
            this._tbSummonX.Text = "0";
            this.HelpEntry.SetToolTip(this._tbSummonX, "The data from the DBC\r\n");
            // 
            // _tbSummonID
            // 
            this._tbSummonID.ForeColor = System.Drawing.Color.Red;
            this._tbSummonID.Location = new System.Drawing.Point(99, 25);
            this._tbSummonID.MaxLength = 6;
            this._tbSummonID.Name = "_tbSummonID";
            this._tbSummonID.Size = new System.Drawing.Size(185, 20);
            this._tbSummonID.TabIndex = 14;
            this._tbSummonID.Text = "1";
            this.HelpEntry.SetToolTip(this._tbSummonID, "ID который укзыветься в скриптах\r\n\"-\" ставиться автоматически");
            // 
            // _cbGossipCondtion_1
            // 
            this._cbGossipCondtion_1.DropDownHeight = 400;
            this._cbGossipCondtion_1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._cbGossipCondtion_1.ForeColor = System.Drawing.Color.Blue;
            this._cbGossipCondtion_1.FormattingEnabled = true;
            this._cbGossipCondtion_1.IntegralHeight = false;
            this._cbGossipCondtion_1.Location = new System.Drawing.Point(8, 32);
            this._cbGossipCondtion_1.Name = "_cbGossipCondtion_1";
            this._cbGossipCondtion_1.Size = new System.Drawing.Size(237, 21);
            this._cbGossipCondtion_1.TabIndex = 14;
            this.HelpEntry.SetToolTip(this._cbGossipCondtion_1, "Choose the type of action");
            this._cbGossipCondtion_1.SelectedIndexChanged += new System.EventHandler(this._cbGossipCondtion_1_SelectedIndexChanged);
            // 
            // _cbGossipCondtion_2
            // 
            this._cbGossipCondtion_2.DropDownHeight = 400;
            this._cbGossipCondtion_2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._cbGossipCondtion_2.ForeColor = System.Drawing.Color.Blue;
            this._cbGossipCondtion_2.FormattingEnabled = true;
            this._cbGossipCondtion_2.IntegralHeight = false;
            this._cbGossipCondtion_2.Location = new System.Drawing.Point(13, 32);
            this._cbGossipCondtion_2.Name = "_cbGossipCondtion_2";
            this._cbGossipCondtion_2.Size = new System.Drawing.Size(236, 21);
            this._cbGossipCondtion_2.TabIndex = 56;
            this.HelpEntry.SetToolTip(this._cbGossipCondtion_2, "Choose the type of action");
            this._cbGossipCondtion_2.SelectedIndexChanged += new System.EventHandler(this._cbGossipCondtion_2_SelectedIndexChanged);
            // 
            // _tbCreatureGossip
            // 
            this._tbCreatureGossip.Location = new System.Drawing.Point(278, 19);
            this._tbCreatureGossip.Name = "_tbCreatureGossip";
            this._tbCreatureGossip.Size = new System.Drawing.Size(234, 20);
            this._tbCreatureGossip.TabIndex = 64;
            this.HelpEntry.SetToolTip(this._tbCreatureGossip, "Split more that one creature with a \',\'");
            // 
            // _cbGossipOptionIcon
            // 
            this._cbGossipOptionIcon.DropDownHeight = 400;
            this._cbGossipOptionIcon.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._cbGossipOptionIcon.ForeColor = System.Drawing.Color.Blue;
            this._cbGossipOptionIcon.FormattingEnabled = true;
            this._cbGossipOptionIcon.IntegralHeight = false;
            this._cbGossipOptionIcon.Location = new System.Drawing.Point(382, 19);
            this._cbGossipOptionIcon.Name = "_cbGossipOptionIcon";
            this._cbGossipOptionIcon.Size = new System.Drawing.Size(255, 21);
            this._cbGossipOptionIcon.TabIndex = 15;
            this.HelpEntry.SetToolTip(this._cbGossipOptionIcon, "Choose the type of action");
            // 
            // _cbGossipOptionID
            // 
            this._cbGossipOptionID.DropDownHeight = 400;
            this._cbGossipOptionID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._cbGossipOptionID.ForeColor = System.Drawing.Color.Blue;
            this._cbGossipOptionID.FormattingEnabled = true;
            this._cbGossipOptionID.IntegralHeight = false;
            this._cbGossipOptionID.Location = new System.Drawing.Point(382, 46);
            this._cbGossipOptionID.Name = "_cbGossipOptionID";
            this._cbGossipOptionID.Size = new System.Drawing.Size(255, 21);
            this._cbGossipOptionID.TabIndex = 18;
            this.HelpEntry.SetToolTip(this._cbGossipOptionID, "Choose the type of action");
            // 
            // _cbGossipOptionNpcFlag
            // 
            this._cbGossipOptionNpcFlag.DropDownHeight = 400;
            this._cbGossipOptionNpcFlag.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._cbGossipOptionNpcFlag.ForeColor = System.Drawing.Color.Blue;
            this._cbGossipOptionNpcFlag.FormattingEnabled = true;
            this._cbGossipOptionNpcFlag.IntegralHeight = false;
            this._cbGossipOptionNpcFlag.Location = new System.Drawing.Point(382, 73);
            this._cbGossipOptionNpcFlag.Name = "_cbGossipOptionNpcFlag";
            this._cbGossipOptionNpcFlag.Size = new System.Drawing.Size(255, 21);
            this._cbGossipOptionNpcFlag.TabIndex = 19;
            this.HelpEntry.SetToolTip(this._cbGossipOptionNpcFlag, "Choose the type of action");
            // 
            // _cbGossipOptionCondtion_2
            // 
            this._cbGossipOptionCondtion_2.DropDownHeight = 400;
            this._cbGossipOptionCondtion_2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._cbGossipOptionCondtion_2.ForeColor = System.Drawing.Color.Blue;
            this._cbGossipOptionCondtion_2.FormattingEnabled = true;
            this._cbGossipOptionCondtion_2.IntegralHeight = false;
            this._cbGossipOptionCondtion_2.Location = new System.Drawing.Point(13, 32);
            this._cbGossipOptionCondtion_2.Name = "_cbGossipOptionCondtion_2";
            this._cbGossipOptionCondtion_2.Size = new System.Drawing.Size(236, 21);
            this._cbGossipOptionCondtion_2.TabIndex = 56;
            this.HelpEntry.SetToolTip(this._cbGossipOptionCondtion_2, "Choose the type of action");
            this._cbGossipOptionCondtion_2.SelectedIndexChanged += new System.EventHandler(this._cbGossipOptionCondtion_2_SelectedIndexChanged);
            // 
            // _cbGossipOptionCondtion_1
            // 
            this._cbGossipOptionCondtion_1.DropDownHeight = 400;
            this._cbGossipOptionCondtion_1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._cbGossipOptionCondtion_1.ForeColor = System.Drawing.Color.Blue;
            this._cbGossipOptionCondtion_1.FormattingEnabled = true;
            this._cbGossipOptionCondtion_1.IntegralHeight = false;
            this._cbGossipOptionCondtion_1.Location = new System.Drawing.Point(8, 32);
            this._cbGossipOptionCondtion_1.Name = "_cbGossipOptionCondtion_1";
            this._cbGossipOptionCondtion_1.Size = new System.Drawing.Size(237, 21);
            this._cbGossipOptionCondtion_1.TabIndex = 14;
            this.HelpEntry.SetToolTip(this._cbGossipOptionCondtion_1, "Choose the type of action");
            this._cbGossipOptionCondtion_1.SelectedIndexChanged += new System.EventHandler(this._cbGossipOptionCondtion_1_SelectedIndexChanged);
            // 
            // _cbGossipOptionCondtion_3
            // 
            this._cbGossipOptionCondtion_3.DropDownHeight = 400;
            this._cbGossipOptionCondtion_3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._cbGossipOptionCondtion_3.ForeColor = System.Drawing.Color.Blue;
            this._cbGossipOptionCondtion_3.FormattingEnabled = true;
            this._cbGossipOptionCondtion_3.IntegralHeight = false;
            this._cbGossipOptionCondtion_3.Location = new System.Drawing.Point(13, 32);
            this._cbGossipOptionCondtion_3.Name = "_cbGossipOptionCondtion_3";
            this._cbGossipOptionCondtion_3.Size = new System.Drawing.Size(236, 21);
            this._cbGossipOptionCondtion_3.TabIndex = 56;
            this.HelpEntry.SetToolTip(this._cbGossipOptionCondtion_3, "Choose the type of action");
            this._cbGossipOptionCondtion_3.SelectedIndexChanged += new System.EventHandler(this._cbGossipOptionCondtion_3_SelectedIndexChanged);
            // 
            // _tbScriptID
            // 
            this._tbScriptID.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this._tbScriptID.ForeColor = System.Drawing.Color.Red;
            this._tbScriptID.Location = new System.Drawing.Point(151, 265);
            this._tbScriptID.MaxLength = 11;
            this._tbScriptID.Name = "_tbScriptID";
            this._tbScriptID.Size = new System.Drawing.Size(114, 20);
            this._tbScriptID.TabIndex = 1;
            this._tbScriptID.Text = "1";
            this._tbScriptID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.NumberScripts_KeyPress);
            // 
            // _clbPhase
            // 
            this._clbPhase.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this._clbPhase.CheckOnClick = true;
            this._clbPhase.ColumnWidth = 60;
            this._clbPhase.ContextMenuStrip = this._cmPhase;
            this._clbPhase.Dock = System.Windows.Forms.DockStyle.Fill;
            this._clbPhase.FormattingEnabled = true;
            this._clbPhase.IntegralHeight = false;
            this._clbPhase.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30"});
            this._clbPhase.Location = new System.Drawing.Point(3, 16);
            this._clbPhase.MultiColumn = true;
            this._clbPhase.Name = "_clbPhase";
            this._clbPhase.Size = new System.Drawing.Size(502, 124);
            this._clbPhase.TabIndex = 33;
            this._clbPhase.SelectedIndexChanged += new System.EventHandler(this.clbEventFlag_SelectedIndexChanged);
            this._clbPhase.SelectedValueChanged += new System.EventHandler(this._clbPhase_SelectedValueChanged);
            // 
            // _cmPhase
            // 
            this._cmPhase.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.UnselectALL,
            this.SelectAll,
            this.Revert});
            this._cmPhase.Name = "_cmPhase";
            this._cmPhase.Size = new System.Drawing.Size(135, 70);
            // 
            // UnselectALL
            // 
            this.UnselectALL.Name = "UnselectALL";
            this.UnselectALL.Size = new System.Drawing.Size(134, 22);
            this.UnselectALL.Text = "Unselect all";
            this.UnselectALL.Click += new System.EventHandler(this.UnselectALL_Click);
            // 
            // SelectAll
            // 
            this.SelectAll.Name = "SelectAll";
            this.SelectAll.Size = new System.Drawing.Size(134, 22);
            this.SelectAll.Text = "Select all";
            this.SelectAll.Click += new System.EventHandler(this.UnselectALL_Click);
            // 
            // Revert
            // 
            this.Revert.Name = "Revert";
            this.Revert.Size = new System.Drawing.Size(134, 22);
            this.Revert.Text = "Revert";
            this.Revert.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.Revert.Click += new System.EventHandler(this.UnselectALL_Click);
            // 
            // _tpScript
            // 
            this._tpScript.Controls.Add(this.splitContainer1);
            this._tpScript.Controls.Add(this.lDateTime);
            this._tpScript.Location = new System.Drawing.Point(4, 22);
            this._tpScript.Name = "_tpScript";
            this._tpScript.Padding = new System.Windows.Forms.Padding(3);
            this._tpScript.Size = new System.Drawing.Size(1048, 604);
            this._tpScript.TabIndex = 0;
            this._tpScript.Text = "Scripts";
            this._tpScript.UseVisualStyleBackColor = true;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer1.Location = new System.Drawing.Point(3, 3);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.splitContainer1.Panel1.Controls.Add(this._bFind);
            this.splitContainer1.Panel1.Controls.Add(this.label14);
            this.splitContainer1.Panel1.Controls.Add(this.label3);
            this.splitContainer1.Panel1.Controls.Add(this._tbFilterCreat);
            this.splitContainer1.Panel1.Controls.Add(this._tbFilterNum);
            this.splitContainer1.Panel1.Controls.Add(this._cbFilteActionType);
            this.splitContainer1.Panel1.Controls.Add(this._cbFilteEventType);
            this.splitContainer1.Panel1.Controls.Add(this._lvScripts);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.splitContainer1.Panel2.Controls.Add(this.pMain);
            this.splitContainer1.Panel2.Controls.Add(this._gbPhase);
            this.splitContainer1.Panel2.Controls.Add(this._gbEventFlag);
            this.splitContainer1.Panel2.Controls.Add(this.label1);
            this.splitContainer1.Panel2.Controls.Add(this.label2);
            this.splitContainer1.Panel2.Controls.Add(this._tbEntryNpc);
            this.splitContainer1.Panel2.Controls.Add(this._tbScriptID);
            this.splitContainer1.Panel2.Controls.Add(this._gbEventType);
            this.splitContainer1.Panel2.Controls.Add(this._tbComment);
            this.splitContainer1.Panel2.Controls.Add(this._gbAction2);
            this.splitContainer1.Panel2.Controls.Add(this.label5);
            this.splitContainer1.Panel2.Controls.Add(this._gbAction1);
            this.splitContainer1.Panel2.Controls.Add(this._gbAction3);
            this.splitContainer1.Panel2.Controls.Add(this.label4);
            this.splitContainer1.Panel2.Controls.Add(this._tbShance);
            this.splitContainer1.Size = new System.Drawing.Size(1042, 598);
            this.splitContainer1.SplitterDistance = 124;
            this.splitContainer1.TabIndex = 36;
            // 
            // _bFind
            // 
            this._bFind.Location = new System.Drawing.Point(3, 98);
            this._bFind.Name = "_bFind";
            this._bFind.Size = new System.Drawing.Size(158, 23);
            this._bFind.TabIndex = 38;
            this._bFind.Text = "Find";
            this._bFind.UseVisualStyleBackColor = true;
            this._bFind.Click += new System.EventHandler(this._bFind_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label14.Location = new System.Drawing.Point(5, 6);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(40, 13);
            this.label14.TabIndex = 37;
            this.label14.Text = "Script";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.ForeColor = System.Drawing.Color.MediumBlue;
            this.label3.Location = new System.Drawing.Point(5, 28);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Entry";
            // 
            // _tbFilterCreat
            // 
            this._tbFilterCreat.ForeColor = System.Drawing.Color.Black;
            this._tbFilterCreat.Location = new System.Drawing.Point(74, 25);
            this._tbFilterCreat.MaxLength = 10;
            this._tbFilterCreat.Name = "_tbFilterCreat";
            this._tbFilterCreat.Size = new System.Drawing.Size(87, 20);
            this._tbFilterCreat.TabIndex = 2;
            // 
            // _tbFilterNum
            // 
            this._tbFilterNum.ForeColor = System.Drawing.Color.Red;
            this._tbFilterNum.Location = new System.Drawing.Point(74, 3);
            this._tbFilterNum.MaxLength = 10;
            this._tbFilterNum.Name = "_tbFilterNum";
            this._tbFilterNum.Size = new System.Drawing.Size(87, 20);
            this._tbFilterNum.TabIndex = 2;
            this._tbFilterNum.KeyDown += new System.Windows.Forms.KeyEventHandler(this._tbFilterNum_KeyDown);
            // 
            // _cbFilteActionType
            // 
            this._cbFilteActionType.DropDownHeight = 500;
            this._cbFilteActionType.DropDownWidth = 250;
            this._cbFilteActionType.FormattingEnabled = true;
            this._cbFilteActionType.IntegralHeight = false;
            this._cbFilteActionType.Location = new System.Drawing.Point(3, 72);
            this._cbFilteActionType.Name = "_cbFilteActionType";
            this._cbFilteActionType.Size = new System.Drawing.Size(158, 21);
            this._cbFilteActionType.TabIndex = 1;
            this._cbFilteActionType.SelectedIndexChanged += new System.EventHandler(this._cbFilteEventType_SelectedIndexChanged);
            // 
            // _cbFilteEventType
            // 
            this._cbFilteEventType.DropDownHeight = 500;
            this._cbFilteEventType.DropDownWidth = 250;
            this._cbFilteEventType.FormattingEnabled = true;
            this._cbFilteEventType.IntegralHeight = false;
            this._cbFilteEventType.Location = new System.Drawing.Point(3, 48);
            this._cbFilteEventType.Name = "_cbFilteEventType";
            this._cbFilteEventType.Size = new System.Drawing.Size(158, 21);
            this._cbFilteEventType.TabIndex = 1;
            this._cbFilteEventType.SelectedIndexChanged += new System.EventHandler(this._cbFilteEventType_SelectedIndexChanged);
            // 
            // _lvScripts
            // 
            this._lvScripts.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this._lvScripts.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this._lvScripts.FullRowSelect = true;
            this._lvScripts.GridLines = true;
            this._lvScripts.HideSelection = false;
            this._lvScripts.Location = new System.Drawing.Point(167, 0);
            this._lvScripts.MultiSelect = false;
            this._lvScripts.Name = "_lvScripts";
            this._lvScripts.Size = new System.Drawing.Size(875, 125);
            this._lvScripts.TabIndex = 0;
            this._lvScripts.UseCompatibleStateImageBehavior = false;
            this._lvScripts.View = System.Windows.Forms.View.Details;
            this._lvScripts.VirtualMode = true;
            this._lvScripts.RetrieveVirtualItem += new System.Windows.Forms.RetrieveVirtualItemEventHandler(this._lvScripts_RetrieveVirtualItem);
            this._lvScripts.SelectedIndexChanged += new System.EventHandler(this._lvScripts_SelectedIndexChanged);
            // 
            // pMain
            // 
            this.pMain.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.pMain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pMain.Controls.Add(this.rtbScriptOut);
            this.pMain.Controls.Add(this._bCreateAIScript);
            this.pMain.Controls.Add(this._bWriteFiles);
            this.pMain.Location = new System.Drawing.Point(7, 373);
            this.pMain.Name = "pMain";
            this.pMain.Size = new System.Drawing.Size(1030, 100);
            this.pMain.TabIndex = 37;
            // 
            // rtbScriptOut
            // 
            this.rtbScriptOut.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.rtbScriptOut.Location = new System.Drawing.Point(3, 5);
            this.rtbScriptOut.Name = "rtbScriptOut";
            this.rtbScriptOut.Size = new System.Drawing.Size(917, 87);
            this.rtbScriptOut.TabIndex = 35;
            this.rtbScriptOut.Text = "";
            // 
            // _bCreateAIScript
            // 
            this._bCreateAIScript.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this._bCreateAIScript.AutoEllipsis = true;
            this._bCreateAIScript.Location = new System.Drawing.Point(937, 16);
            this._bCreateAIScript.Name = "_bCreateAIScript";
            this._bCreateAIScript.Size = new System.Drawing.Size(85, 25);
            this._bCreateAIScript.TabIndex = 27;
            this._bCreateAIScript.Text = "Create";
            this._bCreateAIScript.UseVisualStyleBackColor = true;
            this._bCreateAIScript.Click += new System.EventHandler(this.CreateAIScript_Click);
            // 
            // _bWriteFiles
            // 
            this._bWriteFiles.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this._bWriteFiles.Enabled = false;
            this._bWriteFiles.Location = new System.Drawing.Point(938, 47);
            this._bWriteFiles.Name = "_bWriteFiles";
            this._bWriteFiles.Size = new System.Drawing.Size(85, 25);
            this._bWriteFiles.TabIndex = 28;
            this._bWriteFiles.Text = "Record";
            this._bWriteFiles.UseVisualStyleBackColor = true;
            this._bWriteFiles.Click += new System.EventHandler(this.WriteFiles_Click);
            // 
            // _gbPhase
            // 
            this._gbPhase.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this._gbPhase.Controls.Add(this._clbPhase);
            this._gbPhase.Location = new System.Drawing.Point(276, 193);
            this._gbPhase.Name = "_gbPhase";
            this._gbPhase.Size = new System.Drawing.Size(508, 143);
            this._gbPhase.TabIndex = 36;
            this._gbPhase.TabStop = false;
            this._gbPhase.Text = "phase";
            // 
            // _gbEventFlag
            // 
            this._gbEventFlag.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this._gbEventFlag.Controls.Add(this._clbEventFlag);
            this._gbEventFlag.Location = new System.Drawing.Point(787, 193);
            this._gbEventFlag.Name = "_gbEventFlag";
            this._gbEventFlag.Size = new System.Drawing.Size(250, 143);
            this._gbEventFlag.TabIndex = 36;
            this._gbEventFlag.TabStop = false;
            this._gbEventFlag.Text = "EventFlag";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label1.Location = new System.Drawing.Point(9, 268);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "ScriptNumber";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 294);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "CreatureID";
            // 
            // _gbEventType
            // 
            this._gbEventType.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this._gbEventType.Controls.Add(this.lEventType4);
            this._gbEventType.Controls.Add(this.lEventType3);
            this._gbEventType.Controls.Add(this.lEventType2);
            this._gbEventType.Controls.Add(this.lEventType1);
            this._gbEventType.Controls.Add(this._cbEventParametr4);
            this._gbEventType.Controls.Add(this._cbEventParametr3);
            this._gbEventType.Controls.Add(this._cbEventParametr1);
            this._gbEventType.Controls.Add(this._cbEventParametr2);
            this._gbEventType.Controls.Add(this._cbEventType);
            this._gbEventType.Location = new System.Drawing.Point(7, 5);
            this._gbEventType.Name = "_gbEventType";
            this._gbEventType.Size = new System.Drawing.Size(258, 245);
            this._gbEventType.TabIndex = 29;
            this._gbEventType.TabStop = false;
            this._gbEventType.Text = "EventType";
            // 
            // lEventType4
            // 
            this.lEventType4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lEventType4.AutoSize = true;
            this.lEventType4.Location = new System.Drawing.Point(10, 192);
            this.lEventType4.Name = "lEventType4";
            this.lEventType4.Size = new System.Drawing.Size(0, 13);
            this.lEventType4.TabIndex = 55;
            // 
            // lEventType3
            // 
            this.lEventType3.AutoSize = true;
            this.lEventType3.Location = new System.Drawing.Point(8, 144);
            this.lEventType3.Name = "lEventType3";
            this.lEventType3.Size = new System.Drawing.Size(0, 13);
            this.lEventType3.TabIndex = 54;
            // 
            // lEventType2
            // 
            this.lEventType2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lEventType2.AutoSize = true;
            this.lEventType2.Location = new System.Drawing.Point(9, 97);
            this.lEventType2.Name = "lEventType2";
            this.lEventType2.Size = new System.Drawing.Size(0, 13);
            this.lEventType2.TabIndex = 53;
            // 
            // lEventType1
            // 
            this.lEventType1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lEventType1.AutoSize = true;
            this.lEventType1.Location = new System.Drawing.Point(11, 50);
            this.lEventType1.Name = "lEventType1";
            this.lEventType1.Size = new System.Drawing.Size(0, 13);
            this.lEventType1.TabIndex = 52;
            // 
            // _cbEventParametr4
            // 
            this._cbEventParametr4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this._cbEventParametr4.DropDownHeight = 400;
            this._cbEventParametr4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this._cbEventParametr4.FormattingEnabled = true;
            this._cbEventParametr4.IntegralHeight = false;
            this._cbEventParametr4.Location = new System.Drawing.Point(6, 210);
            this._cbEventParametr4.Name = "_cbEventParametr4";
            this._cbEventParametr4.Size = new System.Drawing.Size(175, 21);
            this._cbEventParametr4.TabIndex = 23;
            // 
            // _cbEventParametr3
            // 
            this._cbEventParametr3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this._cbEventParametr3.DropDownHeight = 400;
            this._cbEventParametr3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this._cbEventParametr3.FormattingEnabled = true;
            this._cbEventParametr3.IntegralHeight = false;
            this._cbEventParametr3.Location = new System.Drawing.Point(5, 161);
            this._cbEventParametr3.Name = "_cbEventParametr3";
            this._cbEventParametr3.Size = new System.Drawing.Size(175, 21);
            this._cbEventParametr3.TabIndex = 23;
            // 
            // _cbEventParametr1
            // 
            this._cbEventParametr1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this._cbEventParametr1.DropDownHeight = 400;
            this._cbEventParametr1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this._cbEventParametr1.FormattingEnabled = true;
            this._cbEventParametr1.IntegralHeight = false;
            this._cbEventParametr1.Location = new System.Drawing.Point(5, 68);
            this._cbEventParametr1.Name = "_cbEventParametr1";
            this._cbEventParametr1.Size = new System.Drawing.Size(175, 21);
            this._cbEventParametr1.TabIndex = 23;
            this._cbEventParametr1.SelectedIndexChanged += new System.EventHandler(this.ActionTyteCondition_SelectedIndexChanged);
            // 
            // _cbEventParametr2
            // 
            this._cbEventParametr2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this._cbEventParametr2.DropDownHeight = 400;
            this._cbEventParametr2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this._cbEventParametr2.FormattingEnabled = true;
            this._cbEventParametr2.IntegralHeight = false;
            this._cbEventParametr2.Location = new System.Drawing.Point(5, 115);
            this._cbEventParametr2.Name = "_cbEventParametr2";
            this._cbEventParametr2.Size = new System.Drawing.Size(175, 21);
            this._cbEventParametr2.TabIndex = 23;
            this._cbEventParametr2.SelectedIndexChanged += new System.EventHandler(this.ActionTyteCondition_SelectedIndexChanged);
            // 
            // _gbAction2
            // 
            this._gbAction2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this._gbAction2.Controls.Add(this._cbActionParam2_1);
            this._gbAction2.Controls.Add(this.lActionParam2_1);
            this._gbAction2.Controls.Add(this.lActionParam2_3);
            this._gbAction2.Controls.Add(this.lActionParam2_2);
            this._gbAction2.Controls.Add(this._cbActionParam2_2);
            this._gbAction2.Controls.Add(this._cbActionParam2_3);
            this._gbAction2.Controls.Add(this._cbActionType2);
            this._gbAction2.Location = new System.Drawing.Point(532, 5);
            this._gbAction2.Name = "_gbAction2";
            this._gbAction2.Size = new System.Drawing.Size(250, 182);
            this._gbAction2.TabIndex = 27;
            this._gbAction2.TabStop = false;
            this._gbAction2.Text = "Action Type 2 in the event";
            // 
            // _cbActionParam2_1
            // 
            this._cbActionParam2_1.DropDownHeight = 400;
            this._cbActionParam2_1.ForeColor = System.Drawing.Color.Blue;
            this._cbActionParam2_1.FormattingEnabled = true;
            this._cbActionParam2_1.IntegralHeight = false;
            this._cbActionParam2_1.Location = new System.Drawing.Point(6, 60);
            this._cbActionParam2_1.Name = "_cbActionParam2_1";
            this._cbActionParam2_1.Size = new System.Drawing.Size(175, 21);
            this._cbActionParam2_1.TabIndex = 51;
            this._cbActionParam2_1.Visible = false;
            // 
            // lActionParam2_1
            // 
            this.lActionParam2_1.AutoSize = true;
            this.lActionParam2_1.Location = new System.Drawing.Point(11, 44);
            this.lActionParam2_1.Name = "lActionParam2_1";
            this.lActionParam2_1.Size = new System.Drawing.Size(0, 13);
            this.lActionParam2_1.TabIndex = 50;
            // 
            // lActionParam2_3
            // 
            this.lActionParam2_3.AutoSize = true;
            this.lActionParam2_3.Location = new System.Drawing.Point(10, 133);
            this.lActionParam2_3.Name = "lActionParam2_3";
            this.lActionParam2_3.Size = new System.Drawing.Size(0, 13);
            this.lActionParam2_3.TabIndex = 52;
            // 
            // lActionParam2_2
            // 
            this.lActionParam2_2.AutoSize = true;
            this.lActionParam2_2.Location = new System.Drawing.Point(11, 86);
            this.lActionParam2_2.Name = "lActionParam2_2";
            this.lActionParam2_2.Size = new System.Drawing.Size(0, 13);
            this.lActionParam2_2.TabIndex = 51;
            // 
            // _cbActionParam2_2
            // 
            this._cbActionParam2_2.DropDownHeight = 400;
            this._cbActionParam2_2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this._cbActionParam2_2.FormattingEnabled = true;
            this._cbActionParam2_2.IntegralHeight = false;
            this._cbActionParam2_2.Location = new System.Drawing.Point(6, 104);
            this._cbActionParam2_2.Name = "_cbActionParam2_2";
            this._cbActionParam2_2.Size = new System.Drawing.Size(175, 21);
            this._cbActionParam2_2.TabIndex = 34;
            this._cbActionParam2_2.Visible = false;
            this._cbActionParam2_2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ComboBox_KeyPress);
            // 
            // _cbActionParam2_3
            // 
            this._cbActionParam2_3.DropDownHeight = 400;
            this._cbActionParam2_3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this._cbActionParam2_3.FormattingEnabled = true;
            this._cbActionParam2_3.IntegralHeight = false;
            this._cbActionParam2_3.Location = new System.Drawing.Point(5, 148);
            this._cbActionParam2_3.Name = "_cbActionParam2_3";
            this._cbActionParam2_3.Size = new System.Drawing.Size(176, 21);
            this._cbActionParam2_3.TabIndex = 33;
            this._cbActionParam2_3.Visible = false;
            this._cbActionParam2_3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ComboBox_KeyPress);
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(5, 350);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 13);
            this.label5.TabIndex = 28;
            this.label5.Text = "Comment:";
            // 
            // _gbAction1
            // 
            this._gbAction1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this._gbAction1.Controls.Add(this._cbActionParam1_1);
            this._gbAction1.Controls.Add(this.lActionParam1_3);
            this._gbAction1.Controls.Add(this.lActionParam1_2);
            this._gbAction1.Controls.Add(this.lActionParam1_1);
            this._gbAction1.Controls.Add(this._cbActionParam1_3);
            this._gbAction1.Controls.Add(this._cbActionParam1_2);
            this._gbAction1.Controls.Add(this._cbActionType1);
            this._gbAction1.Location = new System.Drawing.Point(276, 5);
            this._gbAction1.Name = "_gbAction1";
            this._gbAction1.Size = new System.Drawing.Size(250, 182);
            this._gbAction1.TabIndex = 27;
            this._gbAction1.TabStop = false;
            this._gbAction1.Text = "Action Type 1 at the event";
            // 
            // _cbActionParam1_1
            // 
            this._cbActionParam1_1.DropDownHeight = 400;
            this._cbActionParam1_1.ForeColor = System.Drawing.Color.Blue;
            this._cbActionParam1_1.FormatString = "N0";
            this._cbActionParam1_1.FormattingEnabled = true;
            this._cbActionParam1_1.IntegralHeight = false;
            this._cbActionParam1_1.Location = new System.Drawing.Point(6, 60);
            this._cbActionParam1_1.Name = "_cbActionParam1_1";
            this._cbActionParam1_1.Size = new System.Drawing.Size(175, 21);
            this._cbActionParam1_1.TabIndex = 50;
            this._cbActionParam1_1.Visible = false;
            // 
            // lActionParam1_3
            // 
            this.lActionParam1_3.AutoSize = true;
            this.lActionParam1_3.Location = new System.Drawing.Point(10, 131);
            this.lActionParam1_3.Name = "lActionParam1_3";
            this.lActionParam1_3.Size = new System.Drawing.Size(0, 13);
            this.lActionParam1_3.TabIndex = 49;
            // 
            // lActionParam1_2
            // 
            this.lActionParam1_2.AutoSize = true;
            this.lActionParam1_2.Location = new System.Drawing.Point(9, 87);
            this.lActionParam1_2.Name = "lActionParam1_2";
            this.lActionParam1_2.Size = new System.Drawing.Size(0, 13);
            this.lActionParam1_2.TabIndex = 48;
            // 
            // lActionParam1_1
            // 
            this.lActionParam1_1.AutoSize = true;
            this.lActionParam1_1.Location = new System.Drawing.Point(9, 46);
            this.lActionParam1_1.Name = "lActionParam1_1";
            this.lActionParam1_1.Size = new System.Drawing.Size(0, 13);
            this.lActionParam1_1.TabIndex = 47;
            // 
            // _cbActionParam1_3
            // 
            this._cbActionParam1_3.DropDownHeight = 400;
            this._cbActionParam1_3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this._cbActionParam1_3.FormattingEnabled = true;
            this._cbActionParam1_3.IntegralHeight = false;
            this._cbActionParam1_3.Location = new System.Drawing.Point(6, 148);
            this._cbActionParam1_3.Name = "_cbActionParam1_3";
            this._cbActionParam1_3.Size = new System.Drawing.Size(175, 21);
            this._cbActionParam1_3.TabIndex = 42;
            this._cbActionParam1_3.Visible = false;
            this._cbActionParam1_3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ComboBox_KeyPress);
            // 
            // _cbActionParam1_2
            // 
            this._cbActionParam1_2.DropDownHeight = 400;
            this._cbActionParam1_2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this._cbActionParam1_2.FormattingEnabled = true;
            this._cbActionParam1_2.IntegralHeight = false;
            this._cbActionParam1_2.Location = new System.Drawing.Point(6, 104);
            this._cbActionParam1_2.Name = "_cbActionParam1_2";
            this._cbActionParam1_2.Size = new System.Drawing.Size(175, 21);
            this._cbActionParam1_2.TabIndex = 37;
            this._cbActionParam1_2.Visible = false;
            // 
            // _gbAction3
            // 
            this._gbAction3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this._gbAction3.Controls.Add(this._cbActionParam3_1);
            this._gbAction3.Controls.Add(this.lActionParam3_3);
            this._gbAction3.Controls.Add(this.lActionParam3_2);
            this._gbAction3.Controls.Add(this.lActionParam3_1);
            this._gbAction3.Controls.Add(this._cbActionParam3_3);
            this._gbAction3.Controls.Add(this._cbActionParam3_2);
            this._gbAction3.Controls.Add(this._cbActionType3);
            this._gbAction3.Location = new System.Drawing.Point(787, 5);
            this._gbAction3.Name = "_gbAction3";
            this._gbAction3.Size = new System.Drawing.Size(250, 182);
            this._gbAction3.TabIndex = 27;
            this._gbAction3.TabStop = false;
            this._gbAction3.Text = "The type of action 3 at event";
            // 
            // _cbActionParam3_1
            // 
            this._cbActionParam3_1.DropDownHeight = 400;
            this._cbActionParam3_1.ForeColor = System.Drawing.Color.Blue;
            this._cbActionParam3_1.FormattingEnabled = true;
            this._cbActionParam3_1.IntegralHeight = false;
            this._cbActionParam3_1.Location = new System.Drawing.Point(6, 60);
            this._cbActionParam3_1.Name = "_cbActionParam3_1";
            this._cbActionParam3_1.Size = new System.Drawing.Size(175, 21);
            this._cbActionParam3_1.TabIndex = 53;
            this._cbActionParam3_1.Visible = false;
            // 
            // lActionParam3_3
            // 
            this.lActionParam3_3.AutoSize = true;
            this.lActionParam3_3.Location = new System.Drawing.Point(10, 132);
            this.lActionParam3_3.Name = "lActionParam3_3";
            this.lActionParam3_3.Size = new System.Drawing.Size(0, 13);
            this.lActionParam3_3.TabIndex = 47;
            // 
            // lActionParam3_2
            // 
            this.lActionParam3_2.AutoSize = true;
            this.lActionParam3_2.Location = new System.Drawing.Point(10, 86);
            this.lActionParam3_2.Name = "lActionParam3_2";
            this.lActionParam3_2.Size = new System.Drawing.Size(0, 13);
            this.lActionParam3_2.TabIndex = 46;
            // 
            // lActionParam3_1
            // 
            this.lActionParam3_1.AutoSize = true;
            this.lActionParam3_1.Location = new System.Drawing.Point(10, 44);
            this.lActionParam3_1.Name = "lActionParam3_1";
            this.lActionParam3_1.Size = new System.Drawing.Size(0, 13);
            this.lActionParam3_1.TabIndex = 45;
            // 
            // _cbActionParam3_3
            // 
            this._cbActionParam3_3.DropDownHeight = 400;
            this._cbActionParam3_3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this._cbActionParam3_3.FormattingEnabled = true;
            this._cbActionParam3_3.IntegralHeight = false;
            this._cbActionParam3_3.Location = new System.Drawing.Point(6, 148);
            this._cbActionParam3_3.Name = "_cbActionParam3_3";
            this._cbActionParam3_3.Size = new System.Drawing.Size(175, 21);
            this._cbActionParam3_3.TabIndex = 38;
            this._cbActionParam3_3.Visible = false;
            this._cbActionParam3_3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ComboBox_KeyPress);
            // 
            // _cbActionParam3_2
            // 
            this._cbActionParam3_2.DropDownHeight = 400;
            this._cbActionParam3_2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this._cbActionParam3_2.FormattingEnabled = true;
            this._cbActionParam3_2.IntegralHeight = false;
            this._cbActionParam3_2.Location = new System.Drawing.Point(6, 104);
            this._cbActionParam3_2.Name = "_cbActionParam3_2";
            this._cbActionParam3_2.Size = new System.Drawing.Size(175, 21);
            this._cbActionParam3_2.TabIndex = 37;
            this._cbActionParam3_2.Visible = false;
            this._cbActionParam3_2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ComboBox_KeyPress);
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 319);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Proc";
            // 
            // lDateTime
            // 
            this.lDateTime.AutoSize = true;
            this.lDateTime.Location = new System.Drawing.Point(850, 6);
            this.lDateTime.Name = "lDateTime";
            this.lDateTime.Size = new System.Drawing.Size(0, 13);
            this.lDateTime.TabIndex = 3;
            // 
            // _tPanel
            // 
            this._tPanel.Controls.Add(this._tpScript);
            this._tPanel.Controls.Add(this._tpText);
            this._tPanel.Controls.Add(this._tpSummon);
            this._tPanel.Controls.Add(this._tpGossip);
            this._tPanel.Controls.Add(this._tpGossipOption);
            this._tPanel.Controls.Add(this._tbNpcText);
            this._tPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this._tPanel.Location = new System.Drawing.Point(0, 24);
            this._tPanel.Name = "_tPanel";
            this._tPanel.SelectedIndex = 0;
            this._tPanel.Size = new System.Drawing.Size(1056, 630);
            this._tPanel.TabIndex = 0;
            this._tPanel.SelectedIndexChanged += new System.EventHandler(this._tPanel_SelectedIndexChanged);
            // 
            // _tpText
            // 
            this._tpText.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this._tpText.Controls.Add(this._bTextSearch);
            this._tpText.Controls.Add(this._lvText);
            this._tpText.Controls.Add(this.rtbTextOut);
            this._tpText.Controls.Add(this.lDateTime2);
            this._tpText.Controls.Add(this.bCreateTextQuery);
            this._tpText.Controls.Add(this.button5);
            this._tpText.Controls.Add(this.groupBox9);
            this._tpText.Location = new System.Drawing.Point(4, 22);
            this._tpText.Name = "_tpText";
            this._tpText.Padding = new System.Windows.Forms.Padding(3);
            this._tpText.Size = new System.Drawing.Size(1048, 604);
            this._tpText.TabIndex = 1;
            this._tpText.Text = "Тext";
            // 
            // _bTextSearch
            // 
            this._bTextSearch.Location = new System.Drawing.Point(6, 6);
            this._bTextSearch.Name = "_bTextSearch";
            this._bTextSearch.Size = new System.Drawing.Size(133, 23);
            this._bTextSearch.TabIndex = 36;
            this._bTextSearch.Text = "Find";
            this._bTextSearch.UseVisualStyleBackColor = true;
            this._bTextSearch.Click += new System.EventHandler(this._bTextSearch_Click);
            // 
            // _lvText
            // 
            this._lvText.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this._lvText.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this._lvText.FullRowSelect = true;
            this._lvText.GridLines = true;
            this._lvText.HideSelection = false;
            this._lvText.Location = new System.Drawing.Point(145, 6);
            this._lvText.MultiSelect = false;
            this._lvText.Name = "_lvText";
            this._lvText.Size = new System.Drawing.Size(897, 207);
            this._lvText.TabIndex = 35;
            this._lvText.UseCompatibleStateImageBehavior = false;
            this._lvText.View = System.Windows.Forms.View.Details;
            this._lvText.VirtualMode = true;
            this._lvText.RetrieveVirtualItem += new System.Windows.Forms.RetrieveVirtualItemEventHandler(this._lvText_RetrieveVirtualItem);
            this._lvText.SelectedIndexChanged += new System.EventHandler(this._lvText_SelectedIndexChanged);
            // 
            // rtbTextOut
            // 
            this.rtbTextOut.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.rtbTextOut.Location = new System.Drawing.Point(3, 509);
            this.rtbTextOut.Name = "rtbTextOut";
            this.rtbTextOut.Size = new System.Drawing.Size(917, 90);
            this.rtbTextOut.TabIndex = 34;
            this.rtbTextOut.Text = "";
            // 
            // lDateTime2
            // 
            this.lDateTime2.AutoSize = true;
            this.lDateTime2.Location = new System.Drawing.Point(850, 6);
            this.lDateTime2.Name = "lDateTime2";
            this.lDateTime2.Size = new System.Drawing.Size(0, 13);
            this.lDateTime2.TabIndex = 19;
            // 
            // bCreateTextQuery
            // 
            this.bCreateTextQuery.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.bCreateTextQuery.Location = new System.Drawing.Point(926, 507);
            this.bCreateTextQuery.Name = "bCreateTextQuery";
            this.bCreateTextQuery.Size = new System.Drawing.Size(110, 26);
            this.bCreateTextQuery.TabIndex = 16;
            this.bCreateTextQuery.Text = "Create";
            this.bCreateTextQuery.UseVisualStyleBackColor = true;
            this.bCreateTextQuery.Click += new System.EventHandler(this.CreateTextQuery_Click);
            // 
            // button5
            // 
            this.button5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button5.Location = new System.Drawing.Point(926, 536);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(110, 26);
            this.button5.TabIndex = 15;
            this.button5.Text = "Record";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // groupBox9
            // 
            this.groupBox9.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox9.Controls.Add(this._bSoundSearch);
            this.groupBox9.Controls.Add(this._cbTextEmote);
            this.groupBox9.Controls.Add(this._cbSoundEntry);
            this.groupBox9.Controls.Add(this._tbTextContentLocales);
            this.groupBox9.Controls.Add(this._tbCommentAITexts);
            this.groupBox9.Controls.Add(this.label13);
            this.groupBox9.Controls.Add(this._cbLocale);
            this.groupBox9.Controls.Add(this.label12);
            this.groupBox9.Controls.Add(this.label7);
            this.groupBox9.Controls.Add(this.label11);
            this.groupBox9.Controls.Add(this.label8);
            this.groupBox9.Controls.Add(this._tbTextContentDefault);
            this.groupBox9.Controls.Add(this.label10);
            this.groupBox9.Controls.Add(this.label9);
            this.groupBox9.Controls.Add(this._tbTextID);
            this.groupBox9.Controls.Add(this._cbMessageType);
            this.groupBox9.Controls.Add(this._cbLenguage);
            this.groupBox9.Location = new System.Drawing.Point(6, 219);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(1036, 282);
            this.groupBox9.TabIndex = 3;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Text";
            // 
            // _bSoundSearch
            // 
            this._bSoundSearch.Location = new System.Drawing.Point(200, 77);
            this._bSoundSearch.Name = "_bSoundSearch";
            this._bSoundSearch.Size = new System.Drawing.Size(60, 22);
            this._bSoundSearch.TabIndex = 16;
            this._bSoundSearch.Text = "Find";
            this._bSoundSearch.UseVisualStyleBackColor = true;
            // 
            // _cbTextEmote
            // 
            this._cbTextEmote.FormattingEnabled = true;
            this._cbTextEmote.Location = new System.Drawing.Point(6, 117);
            this._cbTextEmote.Name = "_cbTextEmote";
            this._cbTextEmote.Size = new System.Drawing.Size(254, 21);
            this._cbTextEmote.TabIndex = 15;
            // 
            // _cbSoundEntry
            // 
            this._cbSoundEntry.DropDownHeight = 1;
            this._cbSoundEntry.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple;
            this._cbSoundEntry.FormattingEnabled = true;
            this._cbSoundEntry.IntegralHeight = false;
            this._cbSoundEntry.Location = new System.Drawing.Point(6, 77);
            this._cbSoundEntry.MaxDropDownItems = 1;
            this._cbSoundEntry.Name = "_cbSoundEntry";
            this._cbSoundEntry.Size = new System.Drawing.Size(188, 21);
            this._cbSoundEntry.TabIndex = 15;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(9, 258);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(51, 13);
            this.label13.TabIndex = 12;
            this.label13.Text = "Comment";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label12.Location = new System.Drawing.Point(9, 23);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(45, 13);
            this.label12.TabIndex = 13;
            this.label12.Text = "TextID";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(282, 125);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(88, 13);
            this.label7.TabIndex = 5;
            this.label7.Text = "Localization тext:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(9, 61);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(49, 13);
            this.label11.TabIndex = 12;
            this.label11.Text = "SoundID";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(9, 101);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(48, 13);
            this.label8.TabIndex = 9;
            this.label8.Text = "EmoteID";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(9, 146);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(55, 13);
            this.label10.TabIndex = 11;
            this.label10.Text = "TextType:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(9, 186);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(55, 13);
            this.label9.TabIndex = 10;
            this.label9.Text = "Language";
            // 
            // _cbMessageType
            // 
            this._cbMessageType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._cbMessageType.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this._cbMessageType.FormattingEnabled = true;
            this._cbMessageType.Location = new System.Drawing.Point(6, 162);
            this._cbMessageType.Name = "_cbMessageType";
            this._cbMessageType.Size = new System.Drawing.Size(254, 21);
            this._cbMessageType.TabIndex = 6;
            // 
            // _tpSummon
            // 
            this._tpSummon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this._tpSummon.Controls.Add(this._bCreateSummon);
            this._tpSummon.Controls.Add(this._bWriteSummon);
            this._tpSummon.Controls.Add(this._bSummonSearch);
            this._tpSummon.Controls.Add(this.groupBox1);
            this._tpSummon.Controls.Add(this._rtbSummon);
            this._tpSummon.Controls.Add(this._lvSummon);
            this._tpSummon.Location = new System.Drawing.Point(4, 22);
            this._tpSummon.Name = "_tpSummon";
            this._tpSummon.Padding = new System.Windows.Forms.Padding(3);
            this._tpSummon.Size = new System.Drawing.Size(1048, 604);
            this._tpSummon.TabIndex = 2;
            this._tpSummon.Text = "Summon";
            // 
            // _bCreateSummon
            // 
            this._bCreateSummon.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this._bCreateSummon.AutoEllipsis = true;
            this._bCreateSummon.Location = new System.Drawing.Point(929, 509);
            this._bCreateSummon.Name = "_bCreateSummon";
            this._bCreateSummon.Size = new System.Drawing.Size(107, 25);
            this._bCreateSummon.TabIndex = 29;
            this._bCreateSummon.Text = "Create";
            this._bCreateSummon.UseVisualStyleBackColor = true;
            this._bCreateSummon.Click += new System.EventHandler(this._bCreateSummon_Click);
            // 
            // _bWriteSummon
            // 
            this._bWriteSummon.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this._bWriteSummon.Location = new System.Drawing.Point(929, 540);
            this._bWriteSummon.Name = "_bWriteSummon";
            this._bWriteSummon.Size = new System.Drawing.Size(107, 25);
            this._bWriteSummon.TabIndex = 30;
            this._bWriteSummon.Text = "Record";
            this._bWriteSummon.UseVisualStyleBackColor = true;
            this._bWriteSummon.Click += new System.EventHandler(this._bWriteSummon_Click);
            // 
            // _bSummonSearch
            // 
            this._bSummonSearch.Location = new System.Drawing.Point(6, 6);
            this._bSummonSearch.Name = "_bSummonSearch";
            this._bSummonSearch.Size = new System.Drawing.Size(133, 23);
            this._bSummonSearch.TabIndex = 3;
            this._bSummonSearch.Text = "Find";
            this._bSummonSearch.UseVisualStyleBackColor = true;
            this._bSummonSearch.Click += new System.EventHandler(this._bSummonSearch_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox1.Controls.Add(this._tbSummonSps);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this._tbSummonComment);
            this.groupBox1.Controls.Add(this._tbSummonID);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Location = new System.Drawing.Point(8, 193);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(554, 287);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "creature_ai_summon";
            // 
            // _tbSummonSps
            // 
            this._tbSummonSps.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this._tbSummonSps.Location = new System.Drawing.Point(99, 57);
            this._tbSummonSps.MaxLength = 3;
            this._tbSummonSps.Name = "_tbSummonSps";
            this._tbSummonSps.Size = new System.Drawing.Size(185, 20);
            this._tbSummonSps.TabIndex = 16;
            this._tbSummonSps.Text = "0";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this._tbSummonX);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this._tbSummonO);
            this.groupBox2.Controls.Add(this._tbSummonZ);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this._tbSummonY);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Location = new System.Drawing.Point(9, 83);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(294, 158);
            this.groupBox2.TabIndex = 20;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Coordinates";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(13, 130);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(58, 13);
            this.label20.TabIndex = 18;
            this.label20.Text = "Orientation";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(13, 93);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(14, 13);
            this.label18.TabIndex = 18;
            this.label18.Text = "Z";
            // 
            // _tbSummonO
            // 
            this._tbSummonO.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this._tbSummonO.Location = new System.Drawing.Point(89, 127);
            this._tbSummonO.MaxLength = 5;
            this._tbSummonO.Name = "_tbSummonO";
            this._tbSummonO.Size = new System.Drawing.Size(186, 20);
            this._tbSummonO.TabIndex = 15;
            this._tbSummonO.Text = "0";
            // 
            // _tbSummonZ
            // 
            this._tbSummonZ.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this._tbSummonZ.Location = new System.Drawing.Point(89, 90);
            this._tbSummonZ.MaxLength = 5;
            this._tbSummonZ.Name = "_tbSummonZ";
            this._tbSummonZ.Size = new System.Drawing.Size(186, 20);
            this._tbSummonZ.TabIndex = 15;
            this._tbSummonZ.Text = "0";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(13, 22);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(14, 13);
            this.label15.TabIndex = 18;
            this.label15.Text = "Х";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(13, 55);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(14, 13);
            this.label16.TabIndex = 17;
            this.label16.Text = "Y";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label6.Location = new System.Drawing.Point(6, 28);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(20, 13);
            this.label6.TabIndex = 19;
            this.label6.Text = "ID";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(6, 264);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(51, 13);
            this.label19.TabIndex = 17;
            this.label19.Text = "Comment";
            // 
            // _tbSummonComment
            // 
            this._tbSummonComment.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this._tbSummonComment.Location = new System.Drawing.Point(99, 261);
            this._tbSummonComment.MaxLength = 3;
            this._tbSummonComment.Name = "_tbSummonComment";
            this._tbSummonComment.Size = new System.Drawing.Size(442, 20);
            this._tbSummonComment.TabIndex = 16;
            this._tbSummonComment.Text = "0";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(6, 60);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(79, 13);
            this.label17.TabIndex = 17;
            this.label17.Text = "spawntimesecs";
            // 
            // _rtbSummon
            // 
            this._rtbSummon.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this._rtbSummon.Location = new System.Drawing.Point(6, 509);
            this._rtbSummon.Name = "_rtbSummon";
            this._rtbSummon.Size = new System.Drawing.Size(917, 87);
            this._rtbSummon.TabIndex = 1;
            this._rtbSummon.Text = "";
            // 
            // _lvSummon
            // 
            this._lvSummon.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this._lvSummon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this._lvSummon.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader39,
            this.columnHeader40,
            this.columnHeader41,
            this.columnHeader42,
            this.columnHeader43,
            this.columnHeader44,
            this.columnHeader45});
            this._lvSummon.FullRowSelect = true;
            this._lvSummon.GridLines = true;
            this._lvSummon.HideSelection = false;
            this._lvSummon.Location = new System.Drawing.Point(145, 6);
            this._lvSummon.MultiSelect = false;
            this._lvSummon.Name = "_lvSummon";
            this._lvSummon.Size = new System.Drawing.Size(897, 181);
            this._lvSummon.TabIndex = 0;
            this._lvSummon.UseCompatibleStateImageBehavior = false;
            this._lvSummon.View = System.Windows.Forms.View.Details;
            this._lvSummon.VirtualMode = true;
            this._lvSummon.RetrieveVirtualItem += new System.Windows.Forms.RetrieveVirtualItemEventHandler(this._lvSummon_RetrieveVirtualItem);
            this._lvSummon.SelectedIndexChanged += new System.EventHandler(this._lvSummon_SelectedIndexChanged);
            // 
            // columnHeader39
            // 
            this.columnHeader39.Text = "ID";
            this.columnHeader39.Width = 87;
            // 
            // columnHeader40
            // 
            this.columnHeader40.Text = "X";
            this.columnHeader40.Width = 103;
            // 
            // columnHeader41
            // 
            this.columnHeader41.Text = "Y";
            this.columnHeader41.Width = 108;
            // 
            // columnHeader42
            // 
            this.columnHeader42.Text = "Z";
            this.columnHeader42.Width = 122;
            // 
            // columnHeader43
            // 
            this.columnHeader43.Text = "Orientation";
            this.columnHeader43.Width = 115;
            // 
            // columnHeader44
            // 
            this.columnHeader44.Text = "SpawnTimeSecs";
            this.columnHeader44.Width = 109;
            // 
            // columnHeader45
            // 
            this.columnHeader45.Text = "Comment";
            this.columnHeader45.Width = 240;
            // 
            // _tpGossip
            // 
            this._tpGossip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this._tpGossip.Controls.Add(this.rtbGossipMenuOut);
            this._tpGossip.Controls.Add(this._gbGossipMenu);
            this._tpGossip.Controls.Add(this._panelGossip_menu);
            this._tpGossip.Location = new System.Drawing.Point(4, 22);
            this._tpGossip.Name = "_tpGossip";
            this._tpGossip.Padding = new System.Windows.Forms.Padding(3);
            this._tpGossip.Size = new System.Drawing.Size(1048, 604);
            this._tpGossip.TabIndex = 3;
            this._tpGossip.Text = "Gossip_menu";
            // 
            // rtbGossipMenuOut
            // 
            this.rtbGossipMenuOut.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.rtbGossipMenuOut.Location = new System.Drawing.Point(539, 368);
            this.rtbGossipMenuOut.Name = "rtbGossipMenuOut";
            this.rtbGossipMenuOut.Size = new System.Drawing.Size(501, 230);
            this.rtbGossipMenuOut.TabIndex = 29;
            this.rtbGossipMenuOut.Text = "";
            // 
            // _gbGossipMenu
            // 
            this._gbGossipMenu.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this._gbGossipMenu.Controls.Add(this.label23);
            this._gbGossipMenu.Controls.Add(this._tbCreatureGossip);
            this._gbGossipMenu.Controls.Add(this._bWriteFilesGossip);
            this._gbGossipMenu.Controls.Add(this._gbGossipCondtion2);
            this._gbGossipMenu.Controls.Add(this._bCreateGossip);
            this._gbGossipMenu.Controls.Add(this.label21);
            this._gbGossipMenu.Controls.Add(this._gbGossipCondtion1);
            this._gbGossipMenu.Controls.Add(this._tbGossipEntry);
            this._gbGossipMenu.Controls.Add(this._GossipTextID);
            this._gbGossipMenu.Controls.Add(this.label22);
            this._gbGossipMenu.Location = new System.Drawing.Point(6, 363);
            this._gbGossipMenu.Name = "_gbGossipMenu";
            this._gbGossipMenu.Size = new System.Drawing.Size(527, 235);
            this._gbGossipMenu.TabIndex = 28;
            this._gbGossipMenu.TabStop = false;
            this._gbGossipMenu.Text = "Gossip_menu";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(214, 22);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(58, 13);
            this.label23.TabIndex = 65;
            this.label23.Text = "Creature(s)";
            // 
            // _bWriteFilesGossip
            // 
            this._bWriteFilesGossip.Enabled = false;
            this._bWriteFilesGossip.Location = new System.Drawing.Point(408, 45);
            this._bWriteFilesGossip.Name = "_bWriteFilesGossip";
            this._bWriteFilesGossip.Size = new System.Drawing.Size(104, 30);
            this._bWriteFilesGossip.TabIndex = 30;
            this._bWriteFilesGossip.Text = "Record";
            this._bWriteFilesGossip.UseVisualStyleBackColor = true;
            this._bWriteFilesGossip.Click += new System.EventHandler(this._bWriteFilesGossip_Click);
            // 
            // _gbGossipCondtion2
            // 
            this._gbGossipCondtion2.Controls.Add(this._cbCondtion2Value_1);
            this._gbGossipCondtion2.Controls.Add(this._cbGossipCondtion_2);
            this._gbGossipCondtion2.Controls.Add(this._cbCondtion2Value_2);
            this._gbGossipCondtion2.Controls.Add(this.lCondition2Val1);
            this._gbGossipCondtion2.Controls.Add(this.lCondition2Val2);
            this._gbGossipCondtion2.Location = new System.Drawing.Point(263, 85);
            this._gbGossipCondtion2.Name = "_gbGossipCondtion2";
            this._gbGossipCondtion2.Size = new System.Drawing.Size(255, 144);
            this._gbGossipCondtion2.TabIndex = 63;
            this._gbGossipCondtion2.TabStop = false;
            this._gbGossipCondtion2.Text = "Condition 2";
            // 
            // _cbCondtion2Value_1
            // 
            this._cbCondtion2Value_1.DropDownHeight = 400;
            this._cbCondtion2Value_1.ForeColor = System.Drawing.Color.Blue;
            this._cbCondtion2Value_1.FormatString = "N0";
            this._cbCondtion2Value_1.FormattingEnabled = true;
            this._cbCondtion2Value_1.IntegralHeight = false;
            this._cbCondtion2Value_1.Location = new System.Drawing.Point(13, 73);
            this._cbCondtion2Value_1.Name = "_cbCondtion2Value_1";
            this._cbCondtion2Value_1.Size = new System.Drawing.Size(236, 21);
            this._cbCondtion2Value_1.TabIndex = 60;
            this._cbCondtion2Value_1.Visible = false;
            // 
            // _cbCondtion2Value_2
            // 
            this._cbCondtion2Value_2.DropDownHeight = 400;
            this._cbCondtion2Value_2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this._cbCondtion2Value_2.FormattingEnabled = true;
            this._cbCondtion2Value_2.IntegralHeight = false;
            this._cbCondtion2Value_2.Location = new System.Drawing.Point(13, 117);
            this._cbCondtion2Value_2.Name = "_cbCondtion2Value_2";
            this._cbCondtion2Value_2.Size = new System.Drawing.Size(236, 21);
            this._cbCondtion2Value_2.TabIndex = 57;
            this._cbCondtion2Value_2.Visible = false;
            // 
            // lCondition2Val1
            // 
            this.lCondition2Val1.AutoSize = true;
            this.lCondition2Val1.Location = new System.Drawing.Point(10, 59);
            this.lCondition2Val1.Name = "lCondition2Val1";
            this.lCondition2Val1.Size = new System.Drawing.Size(0, 13);
            this.lCondition2Val1.TabIndex = 58;
            // 
            // lCondition2Val2
            // 
            this.lCondition2Val2.AutoSize = true;
            this.lCondition2Val2.Location = new System.Drawing.Point(10, 100);
            this.lCondition2Val2.Name = "lCondition2Val2";
            this.lCondition2Val2.Size = new System.Drawing.Size(0, 13);
            this.lCondition2Val2.TabIndex = 59;
            // 
            // _bCreateGossip
            // 
            this._bCreateGossip.Location = new System.Drawing.Point(296, 45);
            this._bCreateGossip.Name = "_bCreateGossip";
            this._bCreateGossip.Size = new System.Drawing.Size(106, 30);
            this._bCreateGossip.TabIndex = 29;
            this._bCreateGossip.Text = "Create";
            this._bCreateGossip.UseVisualStyleBackColor = true;
            this._bCreateGossip.Click += new System.EventHandler(this._bCreateGossip_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(8, 22);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(31, 13);
            this.label21.TabIndex = 52;
            this.label21.Text = "Entry";
            // 
            // _gbGossipCondtion1
            // 
            this._gbGossipCondtion1.Controls.Add(this._cbGossipCondtion_1);
            this._gbGossipCondtion1.Controls.Add(this._cbCondtion1Value_2);
            this._gbGossipCondtion1.Controls.Add(this.lCondition1Val1);
            this._gbGossipCondtion1.Controls.Add(this.lCondition1Val2);
            this._gbGossipCondtion1.Controls.Add(this._cbCondtion1Value_1);
            this._gbGossipCondtion1.Location = new System.Drawing.Point(6, 85);
            this._gbGossipCondtion1.Name = "_gbGossipCondtion1";
            this._gbGossipCondtion1.Size = new System.Drawing.Size(251, 144);
            this._gbGossipCondtion1.TabIndex = 62;
            this._gbGossipCondtion1.TabStop = false;
            this._gbGossipCondtion1.Text = "Condition 1";
            // 
            // _cbCondtion1Value_2
            // 
            this._cbCondtion1Value_2.DropDownHeight = 400;
            this._cbCondtion1Value_2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this._cbCondtion1Value_2.FormattingEnabled = true;
            this._cbCondtion1Value_2.IntegralHeight = false;
            this._cbCondtion1Value_2.Location = new System.Drawing.Point(8, 117);
            this._cbCondtion1Value_2.Name = "_cbCondtion1Value_2";
            this._cbCondtion1Value_2.Size = new System.Drawing.Size(237, 21);
            this._cbCondtion1Value_2.TabIndex = 37;
            this._cbCondtion1Value_2.Visible = false;
            // 
            // lCondition1Val1
            // 
            this.lCondition1Val1.AutoSize = true;
            this.lCondition1Val1.Location = new System.Drawing.Point(11, 59);
            this.lCondition1Val1.Name = "lCondition1Val1";
            this.lCondition1Val1.Size = new System.Drawing.Size(0, 13);
            this.lCondition1Val1.TabIndex = 47;
            // 
            // lCondition1Val2
            // 
            this.lCondition1Val2.AutoSize = true;
            this.lCondition1Val2.Location = new System.Drawing.Point(11, 100);
            this.lCondition1Val2.Name = "lCondition1Val2";
            this.lCondition1Val2.Size = new System.Drawing.Size(0, 13);
            this.lCondition1Val2.TabIndex = 48;
            // 
            // _cbCondtion1Value_1
            // 
            this._cbCondtion1Value_1.DropDownHeight = 400;
            this._cbCondtion1Value_1.ForeColor = System.Drawing.Color.Blue;
            this._cbCondtion1Value_1.FormatString = "N0";
            this._cbCondtion1Value_1.FormattingEnabled = true;
            this._cbCondtion1Value_1.IntegralHeight = false;
            this._cbCondtion1Value_1.Location = new System.Drawing.Point(8, 73);
            this._cbCondtion1Value_1.Name = "_cbCondtion1Value_1";
            this._cbCondtion1Value_1.Size = new System.Drawing.Size(237, 21);
            this._cbCondtion1Value_1.TabIndex = 50;
            this._cbCondtion1Value_1.Visible = false;
            // 
            // _tbGossipEntry
            // 
            this._tbGossipEntry.Location = new System.Drawing.Point(55, 19);
            this._tbGossipEntry.Name = "_tbGossipEntry";
            this._tbGossipEntry.Size = new System.Drawing.Size(153, 20);
            this._tbGossipEntry.TabIndex = 51;
            // 
            // _GossipTextID
            // 
            this._GossipTextID.Location = new System.Drawing.Point(55, 45);
            this._GossipTextID.Name = "_GossipTextID";
            this._GossipTextID.Size = new System.Drawing.Size(153, 20);
            this._GossipTextID.TabIndex = 53;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(8, 48);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(39, 13);
            this.label22.TabIndex = 54;
            this.label22.Text = "TextID";
            // 
            // _panelGossip_menu
            // 
            this._panelGossip_menu.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this._panelGossip_menu.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this._panelGossip_menu.Controls.Add(this.groupBox6);
            this._panelGossip_menu.Controls.Add(this.groupBox5);
            this._panelGossip_menu.Controls.Add(this.groupBox4);
            this._panelGossip_menu.Controls.Add(this.groupBox3);
            this._panelGossip_menu.Location = new System.Drawing.Point(6, 6);
            this._panelGossip_menu.Name = "_panelGossip_menu";
            this._panelGossip_menu.Size = new System.Drawing.Size(1034, 351);
            this._panelGossip_menu.TabIndex = 5;
            // 
            // groupBox6
            // 
            this.groupBox6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox6.Controls.Add(this._lvNpc_text);
            this.groupBox6.Location = new System.Drawing.Point(3, 176);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(1024, 167);
            this.groupBox6.TabIndex = 29;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "npc_text";
            // 
            // _lvNpc_text
            // 
            this._lvNpc_text.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this._lvNpc_text.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this._lvNpc_text.GridLines = true;
            this._lvNpc_text.Location = new System.Drawing.Point(9, 19);
            this._lvNpc_text.Name = "_lvNpc_text";
            this._lvNpc_text.Size = new System.Drawing.Size(1012, 142);
            this._lvNpc_text.TabIndex = 0;
            this._lvNpc_text.UseCompatibleStateImageBehavior = false;
            this._lvNpc_text.View = System.Windows.Forms.View.Details;
            this._lvNpc_text.VirtualMode = true;
            this._lvNpc_text.RetrieveVirtualItem += new System.Windows.Forms.RetrieveVirtualItemEventHandler(this._lvNpc_text_RetrieveVirtualItem);
            this._lvNpc_text.SelectedIndexChanged += new System.EventHandler(this._lvNpc_text_SelectedIndexChanged);
            // 
            // groupBox5
            // 
            this.groupBox5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox5.Controls.Add(this._lblnpctext);
            this.groupBox5.Controls.Add(this._lvGossip_Creature);
            this.groupBox5.Location = new System.Drawing.Point(808, 3);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(219, 167);
            this.groupBox5.TabIndex = 28;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Creature";
            // 
            // _lblnpctext
            // 
            this._lblnpctext.AutoSize = true;
            this._lblnpctext.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._lblnpctext.Location = new System.Drawing.Point(35, 63);
            this._lblnpctext.Name = "_lblnpctext";
            this._lblnpctext.Size = new System.Drawing.Size(158, 40);
            this._lblnpctext.TabIndex = 1;
            this._lblnpctext.Text = "Gossip not assigned \r\nto creature";
            this._lblnpctext.Visible = false;
            // 
            // _lvGossip_Creature
            // 
            this._lvGossip_Creature.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this._lvGossip_Creature.AutoArrange = false;
            this._lvGossip_Creature.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this._lvGossip_Creature.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader54,
            this.columnHeader55});
            this._lvGossip_Creature.GridLines = true;
            this._lvGossip_Creature.Location = new System.Drawing.Point(6, 18);
            this._lvGossip_Creature.Name = "_lvGossip_Creature";
            this._lvGossip_Creature.Size = new System.Drawing.Size(207, 143);
            this._lvGossip_Creature.TabIndex = 0;
            this._lvGossip_Creature.UseCompatibleStateImageBehavior = false;
            this._lvGossip_Creature.View = System.Windows.Forms.View.Details;
            this._lvGossip_Creature.VirtualMode = true;
            this._lvGossip_Creature.RetrieveVirtualItem += new System.Windows.Forms.RetrieveVirtualItemEventHandler(this._lvGossip_Creature_RetrieveVirtualItem);
            // 
            // columnHeader54
            // 
            this.columnHeader54.Text = "ID";
            this.columnHeader54.Width = 80;
            // 
            // columnHeader55
            // 
            this.columnHeader55.Text = "Name";
            this.columnHeader55.Width = 119;
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox4.Controls.Add(this._lvGossip_menu);
            this.groupBox4.Location = new System.Drawing.Point(207, 3);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(595, 167);
            this.groupBox4.TabIndex = 27;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Gossip_menu";
            // 
            // _lvGossip_menu
            // 
            this._lvGossip_menu.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this._lvGossip_menu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this._lvGossip_menu.FullRowSelect = true;
            this._lvGossip_menu.GridLines = true;
            this._lvGossip_menu.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this._lvGossip_menu.Location = new System.Drawing.Point(6, 18);
            this._lvGossip_menu.Name = "_lvGossip_menu";
            this._lvGossip_menu.Size = new System.Drawing.Size(584, 143);
            this._lvGossip_menu.TabIndex = 5;
            this._lvGossip_menu.UseCompatibleStateImageBehavior = false;
            this._lvGossip_menu.View = System.Windows.Forms.View.Details;
            this._lvGossip_menu.VirtualMode = true;
            this._lvGossip_menu.RetrieveVirtualItem += new System.Windows.Forms.RetrieveVirtualItemEventHandler(this._lvGossip_menu_RetrieveVirtualItem);
            this._lvGossip_menu.SelectedIndexChanged += new System.EventHandler(this._lvGossip_menu_SelectedIndexChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this._tbFilterGossip);
            this.groupBox3.Controls.Add(this._rbGossip);
            this.groupBox3.Controls.Add(this._rbCreaure);
            this.groupBox3.Controls.Add(this._rbTextID);
            this.groupBox3.Controls.Add(this._bGossipSearch);
            this.groupBox3.Location = new System.Drawing.Point(3, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(198, 167);
            this.groupBox3.TabIndex = 26;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Filter";
            // 
            // _tbFilterGossip
            // 
            this._tbFilterGossip.Location = new System.Drawing.Point(6, 65);
            this._tbFilterGossip.Name = "_tbFilterGossip";
            this._tbFilterGossip.Size = new System.Drawing.Size(186, 20);
            this._tbFilterGossip.TabIndex = 2;
            // 
            // _rbGossip
            // 
            this._rbGossip.AutoSize = true;
            this._rbGossip.Location = new System.Drawing.Point(9, 41);
            this._rbGossip.Name = "_rbGossip";
            this._rbGossip.Size = new System.Drawing.Size(57, 17);
            this._rbGossip.TabIndex = 32;
            this._rbGossip.Text = "Gossip";
            this._rbGossip.UseVisualStyleBackColor = true;
            // 
            // _rbCreaure
            // 
            this._rbCreaure.AutoSize = true;
            this._rbCreaure.Location = new System.Drawing.Point(72, 19);
            this._rbCreaure.Name = "_rbCreaure";
            this._rbCreaure.Size = new System.Drawing.Size(65, 17);
            this._rbCreaure.TabIndex = 31;
            this._rbCreaure.Text = "Creature";
            this._rbCreaure.UseVisualStyleBackColor = true;
            // 
            // _rbTextID
            // 
            this._rbTextID.AutoSize = true;
            this._rbTextID.Checked = true;
            this._rbTextID.Location = new System.Drawing.Point(9, 18);
            this._rbTextID.Name = "_rbTextID";
            this._rbTextID.Size = new System.Drawing.Size(57, 17);
            this._rbTextID.TabIndex = 30;
            this._rbTextID.TabStop = true;
            this._rbTextID.Text = "TextID";
            this._rbTextID.UseVisualStyleBackColor = true;
            // 
            // _bGossipSearch
            // 
            this._bGossipSearch.Location = new System.Drawing.Point(33, 111);
            this._bGossipSearch.Name = "_bGossipSearch";
            this._bGossipSearch.Size = new System.Drawing.Size(133, 23);
            this._bGossipSearch.TabIndex = 4;
            this._bGossipSearch.Text = "Find";
            this._bGossipSearch.UseVisualStyleBackColor = true;
            this._bGossipSearch.Click += new System.EventHandler(this._bGossipSearch_Click);
            // 
            // _tpGossipOption
            // 
            this._tpGossipOption.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this._tpGossipOption.Controls.Add(this._gbGossipMenuOption);
            this._tpGossipOption.Controls.Add(this.groupBox8);
            this._tpGossipOption.Controls.Add(this.groupBox7);
            this._tpGossipOption.Location = new System.Drawing.Point(4, 22);
            this._tpGossipOption.Name = "_tpGossipOption";
            this._tpGossipOption.Padding = new System.Windows.Forms.Padding(3);
            this._tpGossipOption.Size = new System.Drawing.Size(1048, 604);
            this._tpGossipOption.TabIndex = 4;
            this._tpGossipOption.Text = "Gossip_Menu_Option";
            // 
            // _gbGossipMenuOption
            // 
            this._gbGossipMenuOption.Controls.Add(this.label33);
            this._gbGossipMenuOption.Controls.Add(this.label34);
            this._gbGossipMenuOption.Controls.Add(this.label35);
            this._gbGossipMenuOption.Controls.Add(this._bGossipOptionCreate);
            this._gbGossipMenuOption.Controls.Add(this._bGossipOptionRecord);
            this._gbGossipMenuOption.Controls.Add(this.rtbGossipOptionMenuOut);
            this._gbGossipMenuOption.Controls.Add(this._gbGossipOptionCondtion3);
            this._gbGossipMenuOption.Controls.Add(this._gbGossipOptionCondtion2);
            this._gbGossipMenuOption.Controls.Add(this._gbGossipOptionCondtion1);
            this._gbGossipMenuOption.Controls.Add(this.label32);
            this._gbGossipMenuOption.Controls.Add(this._tbGossipBoxText);
            this._gbGossipMenuOption.Controls.Add(this.label31);
            this._gbGossipMenuOption.Controls.Add(this._tbGossipBoxMoney);
            this._gbGossipMenuOption.Controls.Add(this.label30);
            this._gbGossipMenuOption.Controls.Add(this._tbGossipBoxCoded);
            this._gbGossipMenuOption.Controls.Add(this.label29);
            this._gbGossipMenuOption.Controls.Add(this._tbGossipAction);
            this._gbGossipMenuOption.Controls.Add(this.label28);
            this._gbGossipMenuOption.Controls.Add(this._tbGossipPOI_id);
            this._gbGossipMenuOption.Controls.Add(this.label27);
            this._gbGossipMenuOption.Controls.Add(this._tbGossipNpcMenu);
            this._gbGossipMenuOption.Controls.Add(this._cbGossipOptionNpcFlag);
            this._gbGossipMenuOption.Controls.Add(this._cbGossipOptionID);
            this._gbGossipMenuOption.Controls.Add(this.label26);
            this._gbGossipMenuOption.Controls.Add(this._tbGossipOptionText);
            this._gbGossipMenuOption.Controls.Add(this._cbGossipOptionIcon);
            this._gbGossipMenuOption.Controls.Add(this.label25);
            this._gbGossipMenuOption.Controls.Add(this._tbGossipID);
            this._gbGossipMenuOption.Controls.Add(this.label24);
            this._gbGossipMenuOption.Controls.Add(this._tbGossipMenuID);
            this._gbGossipMenuOption.Location = new System.Drawing.Point(6, 175);
            this._gbGossipMenuOption.Name = "_gbGossipMenuOption";
            this._gbGossipMenuOption.Size = new System.Drawing.Size(1036, 423);
            this._gbGossipMenuOption.TabIndex = 9;
            this._gbGossipMenuOption.TabStop = false;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(317, 73);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(47, 13);
            this.label33.TabIndex = 71;
            this.label33.Text = "NpcFlag";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(317, 49);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(49, 13);
            this.label34.TabIndex = 70;
            this.label34.Text = "OptionID";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(317, 22);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(59, 13);
            this.label35.TabIndex = 69;
            this.label35.Text = "OptionIcon";
            // 
            // _bGossipOptionCreate
            // 
            this._bGossipOptionCreate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this._bGossipOptionCreate.AutoEllipsis = true;
            this._bGossipOptionCreate.Location = new System.Drawing.Point(887, 258);
            this._bGossipOptionCreate.Name = "_bGossipOptionCreate";
            this._bGossipOptionCreate.Size = new System.Drawing.Size(143, 37);
            this._bGossipOptionCreate.TabIndex = 67;
            this._bGossipOptionCreate.Text = "Create";
            this._bGossipOptionCreate.UseVisualStyleBackColor = true;
            this._bGossipOptionCreate.Click += new System.EventHandler(this._bGossipOptionCreate_Click);
            // 
            // _bGossipOptionRecord
            // 
            this._bGossipOptionRecord.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this._bGossipOptionRecord.Location = new System.Drawing.Point(887, 301);
            this._bGossipOptionRecord.Name = "_bGossipOptionRecord";
            this._bGossipOptionRecord.Size = new System.Drawing.Size(143, 38);
            this._bGossipOptionRecord.TabIndex = 68;
            this._bGossipOptionRecord.Text = "Record";
            this._bGossipOptionRecord.UseVisualStyleBackColor = true;
            this._bGossipOptionRecord.Click += new System.EventHandler(this._bGossipOptionRecord_Click);
            // 
            // rtbGossipOptionMenuOut
            // 
            this.rtbGossipOptionMenuOut.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.rtbGossipOptionMenuOut.Location = new System.Drawing.Point(6, 258);
            this.rtbGossipOptionMenuOut.Name = "rtbGossipOptionMenuOut";
            this.rtbGossipOptionMenuOut.Size = new System.Drawing.Size(875, 81);
            this.rtbGossipOptionMenuOut.TabIndex = 10;
            this.rtbGossipOptionMenuOut.Text = "";
            // 
            // _gbGossipOptionCondtion3
            // 
            this._gbGossipOptionCondtion3.Controls.Add(this._cbOptionCondtion3Value_1);
            this._gbGossipOptionCondtion3.Controls.Add(this._cbGossipOptionCondtion_3);
            this._gbGossipOptionCondtion3.Controls.Add(this._cbOptionCondtion3Value_2);
            this._gbGossipOptionCondtion3.Controls.Add(this.lGossipOptionCondtion3Val1);
            this._gbGossipOptionCondtion3.Controls.Add(this.lGossipOptionCondtion3Val2);
            this._gbGossipOptionCondtion3.Location = new System.Drawing.Point(775, 108);
            this._gbGossipOptionCondtion3.Name = "_gbGossipOptionCondtion3";
            this._gbGossipOptionCondtion3.Size = new System.Drawing.Size(255, 144);
            this._gbGossipOptionCondtion3.TabIndex = 66;
            this._gbGossipOptionCondtion3.TabStop = false;
            this._gbGossipOptionCondtion3.Text = "Condition 3";
            // 
            // _cbOptionCondtion3Value_1
            // 
            this._cbOptionCondtion3Value_1.DropDownHeight = 400;
            this._cbOptionCondtion3Value_1.ForeColor = System.Drawing.Color.Blue;
            this._cbOptionCondtion3Value_1.FormatString = "N0";
            this._cbOptionCondtion3Value_1.FormattingEnabled = true;
            this._cbOptionCondtion3Value_1.IntegralHeight = false;
            this._cbOptionCondtion3Value_1.Location = new System.Drawing.Point(13, 73);
            this._cbOptionCondtion3Value_1.Name = "_cbOptionCondtion3Value_1";
            this._cbOptionCondtion3Value_1.Size = new System.Drawing.Size(236, 21);
            this._cbOptionCondtion3Value_1.TabIndex = 60;
            this._cbOptionCondtion3Value_1.Visible = false;
            // 
            // _cbOptionCondtion3Value_2
            // 
            this._cbOptionCondtion3Value_2.DropDownHeight = 400;
            this._cbOptionCondtion3Value_2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this._cbOptionCondtion3Value_2.FormattingEnabled = true;
            this._cbOptionCondtion3Value_2.IntegralHeight = false;
            this._cbOptionCondtion3Value_2.Location = new System.Drawing.Point(13, 117);
            this._cbOptionCondtion3Value_2.Name = "_cbOptionCondtion3Value_2";
            this._cbOptionCondtion3Value_2.Size = new System.Drawing.Size(236, 21);
            this._cbOptionCondtion3Value_2.TabIndex = 57;
            this._cbOptionCondtion3Value_2.Visible = false;
            // 
            // lGossipOptionCondtion3Val1
            // 
            this.lGossipOptionCondtion3Val1.AutoSize = true;
            this.lGossipOptionCondtion3Val1.Location = new System.Drawing.Point(10, 59);
            this.lGossipOptionCondtion3Val1.Name = "lGossipOptionCondtion3Val1";
            this.lGossipOptionCondtion3Val1.Size = new System.Drawing.Size(0, 13);
            this.lGossipOptionCondtion3Val1.TabIndex = 58;
            // 
            // lGossipOptionCondtion3Val2
            // 
            this.lGossipOptionCondtion3Val2.AutoSize = true;
            this.lGossipOptionCondtion3Val2.Location = new System.Drawing.Point(10, 100);
            this.lGossipOptionCondtion3Val2.Name = "lGossipOptionCondtion3Val2";
            this.lGossipOptionCondtion3Val2.Size = new System.Drawing.Size(0, 13);
            this.lGossipOptionCondtion3Val2.TabIndex = 59;
            // 
            // _gbGossipOptionCondtion2
            // 
            this._gbGossipOptionCondtion2.Controls.Add(this._cbOptionCondtion2Value_1);
            this._gbGossipOptionCondtion2.Controls.Add(this._cbGossipOptionCondtion_2);
            this._gbGossipOptionCondtion2.Controls.Add(this._cbOptionCondtion2Value_2);
            this._gbGossipOptionCondtion2.Controls.Add(this.lGossipOptionCondtion2Val1);
            this._gbGossipOptionCondtion2.Controls.Add(this.lGossipOptionCondtion2Val2);
            this._gbGossipOptionCondtion2.Location = new System.Drawing.Point(382, 108);
            this._gbGossipOptionCondtion2.Name = "_gbGossipOptionCondtion2";
            this._gbGossipOptionCondtion2.Size = new System.Drawing.Size(255, 144);
            this._gbGossipOptionCondtion2.TabIndex = 65;
            this._gbGossipOptionCondtion2.TabStop = false;
            this._gbGossipOptionCondtion2.Text = "Condition 2";
            // 
            // _cbOptionCondtion2Value_1
            // 
            this._cbOptionCondtion2Value_1.DropDownHeight = 400;
            this._cbOptionCondtion2Value_1.ForeColor = System.Drawing.Color.Blue;
            this._cbOptionCondtion2Value_1.FormatString = "N0";
            this._cbOptionCondtion2Value_1.FormattingEnabled = true;
            this._cbOptionCondtion2Value_1.IntegralHeight = false;
            this._cbOptionCondtion2Value_1.Location = new System.Drawing.Point(13, 73);
            this._cbOptionCondtion2Value_1.Name = "_cbOptionCondtion2Value_1";
            this._cbOptionCondtion2Value_1.Size = new System.Drawing.Size(236, 21);
            this._cbOptionCondtion2Value_1.TabIndex = 60;
            this._cbOptionCondtion2Value_1.Visible = false;
            // 
            // _cbOptionCondtion2Value_2
            // 
            this._cbOptionCondtion2Value_2.DropDownHeight = 400;
            this._cbOptionCondtion2Value_2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this._cbOptionCondtion2Value_2.FormattingEnabled = true;
            this._cbOptionCondtion2Value_2.IntegralHeight = false;
            this._cbOptionCondtion2Value_2.Location = new System.Drawing.Point(13, 117);
            this._cbOptionCondtion2Value_2.Name = "_cbOptionCondtion2Value_2";
            this._cbOptionCondtion2Value_2.Size = new System.Drawing.Size(236, 21);
            this._cbOptionCondtion2Value_2.TabIndex = 57;
            this._cbOptionCondtion2Value_2.Visible = false;
            // 
            // lGossipOptionCondtion2Val1
            // 
            this.lGossipOptionCondtion2Val1.AutoSize = true;
            this.lGossipOptionCondtion2Val1.Location = new System.Drawing.Point(10, 59);
            this.lGossipOptionCondtion2Val1.Name = "lGossipOptionCondtion2Val1";
            this.lGossipOptionCondtion2Val1.Size = new System.Drawing.Size(0, 13);
            this.lGossipOptionCondtion2Val1.TabIndex = 58;
            // 
            // lGossipOptionCondtion2Val2
            // 
            this.lGossipOptionCondtion2Val2.AutoSize = true;
            this.lGossipOptionCondtion2Val2.Location = new System.Drawing.Point(10, 100);
            this.lGossipOptionCondtion2Val2.Name = "lGossipOptionCondtion2Val2";
            this.lGossipOptionCondtion2Val2.Size = new System.Drawing.Size(0, 13);
            this.lGossipOptionCondtion2Val2.TabIndex = 59;
            // 
            // _gbGossipOptionCondtion1
            // 
            this._gbGossipOptionCondtion1.Controls.Add(this._cbGossipOptionCondtion_1);
            this._gbGossipOptionCondtion1.Controls.Add(this._cbOptionCondtion1Value_2);
            this._gbGossipOptionCondtion1.Controls.Add(this.lGossipOptionCondtion1Val1);
            this._gbGossipOptionCondtion1.Controls.Add(this.lGossipOptionCondtion1Val2);
            this._gbGossipOptionCondtion1.Controls.Add(this._cbOptionCondtion1Value_1);
            this._gbGossipOptionCondtion1.Location = new System.Drawing.Point(9, 108);
            this._gbGossipOptionCondtion1.Name = "_gbGossipOptionCondtion1";
            this._gbGossipOptionCondtion1.Size = new System.Drawing.Size(251, 144);
            this._gbGossipOptionCondtion1.TabIndex = 64;
            this._gbGossipOptionCondtion1.TabStop = false;
            this._gbGossipOptionCondtion1.Text = "Condition 1";
            // 
            // _cbOptionCondtion1Value_2
            // 
            this._cbOptionCondtion1Value_2.DropDownHeight = 400;
            this._cbOptionCondtion1Value_2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this._cbOptionCondtion1Value_2.FormattingEnabled = true;
            this._cbOptionCondtion1Value_2.IntegralHeight = false;
            this._cbOptionCondtion1Value_2.Location = new System.Drawing.Point(8, 117);
            this._cbOptionCondtion1Value_2.Name = "_cbOptionCondtion1Value_2";
            this._cbOptionCondtion1Value_2.Size = new System.Drawing.Size(237, 21);
            this._cbOptionCondtion1Value_2.TabIndex = 37;
            this._cbOptionCondtion1Value_2.Visible = false;
            // 
            // lGossipOptionCondtion1Val1
            // 
            this.lGossipOptionCondtion1Val1.AutoSize = true;
            this.lGossipOptionCondtion1Val1.Location = new System.Drawing.Point(11, 59);
            this.lGossipOptionCondtion1Val1.Name = "lGossipOptionCondtion1Val1";
            this.lGossipOptionCondtion1Val1.Size = new System.Drawing.Size(0, 13);
            this.lGossipOptionCondtion1Val1.TabIndex = 47;
            // 
            // lGossipOptionCondtion1Val2
            // 
            this.lGossipOptionCondtion1Val2.AutoSize = true;
            this.lGossipOptionCondtion1Val2.Location = new System.Drawing.Point(11, 100);
            this.lGossipOptionCondtion1Val2.Name = "lGossipOptionCondtion1Val2";
            this.lGossipOptionCondtion1Val2.Size = new System.Drawing.Size(0, 13);
            this.lGossipOptionCondtion1Val2.TabIndex = 48;
            // 
            // _cbOptionCondtion1Value_1
            // 
            this._cbOptionCondtion1Value_1.DropDownHeight = 400;
            this._cbOptionCondtion1Value_1.ForeColor = System.Drawing.Color.Blue;
            this._cbOptionCondtion1Value_1.FormatString = "N0";
            this._cbOptionCondtion1Value_1.FormattingEnabled = true;
            this._cbOptionCondtion1Value_1.IntegralHeight = false;
            this._cbOptionCondtion1Value_1.Location = new System.Drawing.Point(8, 73);
            this._cbOptionCondtion1Value_1.Name = "_cbOptionCondtion1Value_1";
            this._cbOptionCondtion1Value_1.Size = new System.Drawing.Size(237, 21);
            this._cbOptionCondtion1Value_1.TabIndex = 50;
            this._cbOptionCondtion1Value_1.Visible = false;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(857, 73);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(48, 13);
            this.label32.TabIndex = 31;
            this.label32.Text = "Box_text";
            // 
            // _tbGossipBoxText
            // 
            this._tbGossipBoxText.Location = new System.Drawing.Point(924, 70);
            this._tbGossipBoxText.Name = "_tbGossipBoxText";
            this._tbGossipBoxText.Size = new System.Drawing.Size(105, 20);
            this._tbGossipBoxText.TabIndex = 30;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(857, 47);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(62, 13);
            this.label31.TabIndex = 29;
            this.label31.Text = "Box_money";
            // 
            // _tbGossipBoxMoney
            // 
            this._tbGossipBoxMoney.Location = new System.Drawing.Point(924, 44);
            this._tbGossipBoxMoney.Name = "_tbGossipBoxMoney";
            this._tbGossipBoxMoney.Size = new System.Drawing.Size(105, 20);
            this._tbGossipBoxMoney.TabIndex = 28;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(857, 21);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(61, 13);
            this.label30.TabIndex = 27;
            this.label30.Text = "Box_coded";
            // 
            // _tbGossipBoxCoded
            // 
            this._tbGossipBoxCoded.Location = new System.Drawing.Point(924, 18);
            this._tbGossipBoxCoded.Name = "_tbGossipBoxCoded";
            this._tbGossipBoxCoded.Size = new System.Drawing.Size(105, 20);
            this._tbGossipBoxCoded.TabIndex = 26;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(664, 74);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(76, 13);
            this.label29.TabIndex = 25;
            this.label29.Text = "Action script id";
            // 
            // _tbGossipAction
            // 
            this._tbGossipAction.Location = new System.Drawing.Point(746, 69);
            this._tbGossipAction.Name = "_tbGossipAction";
            this._tbGossipAction.Size = new System.Drawing.Size(105, 20);
            this._tbGossipAction.TabIndex = 24;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(664, 48);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(69, 13);
            this.label28.TabIndex = 23;
            this.label28.Text = "Action POI id";
            // 
            // _tbGossipPOI_id
            // 
            this._tbGossipPOI_id.Location = new System.Drawing.Point(746, 44);
            this._tbGossipPOI_id.Name = "_tbGossipPOI_id";
            this._tbGossipPOI_id.Size = new System.Drawing.Size(105, 20);
            this._tbGossipPOI_id.TabIndex = 22;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(664, 22);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(77, 13);
            this.label27.TabIndex = 21;
            this.label27.Text = "Action menu id";
            // 
            // _tbGossipNpcMenu
            // 
            this._tbGossipNpcMenu.Location = new System.Drawing.Point(746, 18);
            this._tbGossipNpcMenu.Name = "_tbGossipNpcMenu";
            this._tbGossipNpcMenu.Size = new System.Drawing.Size(105, 20);
            this._tbGossipNpcMenu.TabIndex = 20;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(6, 74);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(28, 13);
            this.label26.TabIndex = 17;
            this.label26.Text = "Text";
            // 
            // _tbGossipOptionText
            // 
            this._tbGossipOptionText.Location = new System.Drawing.Point(60, 71);
            this._tbGossipOptionText.Name = "_tbGossipOptionText";
            this._tbGossipOptionText.Size = new System.Drawing.Size(237, 20);
            this._tbGossipOptionText.TabIndex = 16;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(6, 47);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(21, 13);
            this.label25.TabIndex = 3;
            this.label25.Text = " ID";
            // 
            // _tbGossipID
            // 
            this._tbGossipID.Location = new System.Drawing.Point(60, 44);
            this._tbGossipID.Name = "_tbGossipID";
            this._tbGossipID.Size = new System.Drawing.Size(105, 20);
            this._tbGossipID.TabIndex = 2;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(6, 21);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(48, 13);
            this.label24.TabIndex = 1;
            this.label24.Text = "Menu ID";
            // 
            // _tbGossipMenuID
            // 
            this._tbGossipMenuID.Location = new System.Drawing.Point(60, 18);
            this._tbGossipMenuID.Name = "_tbGossipMenuID";
            this._tbGossipMenuID.Size = new System.Drawing.Size(105, 20);
            this._tbGossipMenuID.TabIndex = 0;
            // 
            // groupBox8
            // 
            this.groupBox8.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox8.Controls.Add(this._lvGossip_Option);
            this.groupBox8.Location = new System.Drawing.Point(155, 6);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(887, 163);
            this.groupBox8.TabIndex = 8;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Gossip_menu_options";
            // 
            // _lvGossip_Option
            // 
            this._lvGossip_Option.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this._lvGossip_Option.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this._lvGossip_Option.FullRowSelect = true;
            this._lvGossip_Option.GridLines = true;
            this._lvGossip_Option.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this._lvGossip_Option.Location = new System.Drawing.Point(6, 14);
            this._lvGossip_Option.Name = "_lvGossip_Option";
            this._lvGossip_Option.Size = new System.Drawing.Size(875, 143);
            this._lvGossip_Option.TabIndex = 6;
            this._lvGossip_Option.UseCompatibleStateImageBehavior = false;
            this._lvGossip_Option.View = System.Windows.Forms.View.Details;
            this._lvGossip_Option.VirtualMode = true;
            this._lvGossip_Option.RetrieveVirtualItem += new System.Windows.Forms.RetrieveVirtualItemEventHandler(this._lvGossip_Option_RetrieveVirtualItem_1);
            this._lvGossip_Option.SelectedIndexChanged += new System.EventHandler(this._lvGossip_Option_SelectedIndexChanged);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this._bFilterMenuOption);
            this.groupBox7.Controls.Add(this._tbfilterGossipMenu);
            this.groupBox7.Controls.Add(this._rbGossipMenuOption);
            this.groupBox7.Location = new System.Drawing.Point(6, 6);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(143, 163);
            this.groupBox7.TabIndex = 7;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Filter";
            // 
            // _bFilterMenuOption
            // 
            this._bFilterMenuOption.Location = new System.Drawing.Point(13, 132);
            this._bFilterMenuOption.Name = "_bFilterMenuOption";
            this._bFilterMenuOption.Size = new System.Drawing.Size(108, 23);
            this._bFilterMenuOption.TabIndex = 10;
            this._bFilterMenuOption.Text = "Find";
            this._bFilterMenuOption.UseVisualStyleBackColor = true;
            this._bFilterMenuOption.Click += new System.EventHandler(this._bFilterMenuOption_Click);
            // 
            // _tbfilterGossipMenu
            // 
            this._tbfilterGossipMenu.Location = new System.Drawing.Point(6, 106);
            this._tbfilterGossipMenu.Name = "_tbfilterGossipMenu";
            this._tbfilterGossipMenu.Size = new System.Drawing.Size(131, 20);
            this._tbfilterGossipMenu.TabIndex = 9;
            // 
            // _rbGossipMenuOption
            // 
            this._rbGossipMenuOption.AutoSize = true;
            this._rbGossipMenuOption.Checked = true;
            this._rbGossipMenuOption.Location = new System.Drawing.Point(6, 19);
            this._rbGossipMenuOption.Name = "_rbGossipMenuOption";
            this._rbGossipMenuOption.Size = new System.Drawing.Size(115, 17);
            this._rbGossipMenuOption.TabIndex = 9;
            this._rbGossipMenuOption.TabStop = true;
            this._rbGossipMenuOption.Text = "GossipMenuOption";
            this._rbGossipMenuOption.UseVisualStyleBackColor = true;
            // 
            // _tbNpcText
            // 
            this._tbNpcText.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this._tbNpcText.Controls.Add(this._gpText);
            this._tbNpcText.Controls.Add(this.groupBox11);
            this._tbNpcText.Controls.Add(this.groupBox10);
            this._tbNpcText.Location = new System.Drawing.Point(4, 22);
            this._tbNpcText.Name = "_tbNpcText";
            this._tbNpcText.Size = new System.Drawing.Size(1048, 604);
            this._tbNpcText.TabIndex = 5;
            this._tbNpcText.Text = "npc_text";
            // 
            // _gpText
            // 
            this._gpText.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this._gpText.Controls.Add(this._tbNpc_textEm7_5);
            this._gpText.Controls.Add(this._cbNpc_textLang7);
            this._gpText.Controls.Add(this._tbNpc_text7_1);
            this._gpText.Controls.Add(this.label107);
            this._gpText.Controls.Add(this.label108);
            this._gpText.Controls.Add(this._tbNpc_textEm7_1);
            this._gpText.Controls.Add(this._tbNpc_text7_0);
            this._gpText.Controls.Add(this.label109);
            this._gpText.Controls.Add(this.label110);
            this._gpText.Controls.Add(this.label111);
            this._gpText.Controls.Add(this._tbNpc_textEm7_2);
            this._gpText.Controls.Add(this.label112);
            this._gpText.Controls.Add(this._tbNpc_textProb7);
            this._gpText.Controls.Add(this._tbNpc_textEm7_4);
            this._gpText.Controls.Add(this.label113);
            this._gpText.Controls.Add(this.label114);
            this._gpText.Controls.Add(this.label115);
            this._gpText.Controls.Add(this.label116);
            this._gpText.Controls.Add(this._tbNpc_textEm7_3);
            this._gpText.Controls.Add(this._tbNpc_textEm7_0);
            this._gpText.Controls.Add(this._tbNpc_textEm6_5);
            this._gpText.Controls.Add(this._cbNpc_textLang6);
            this._gpText.Controls.Add(this._tbNpc_text6_1);
            this._gpText.Controls.Add(this.label97);
            this._gpText.Controls.Add(this.label98);
            this._gpText.Controls.Add(this._tbNpc_textEm6_1);
            this._gpText.Controls.Add(this._tbNpc_text6_0);
            this._gpText.Controls.Add(this.label99);
            this._gpText.Controls.Add(this.label100);
            this._gpText.Controls.Add(this.label101);
            this._gpText.Controls.Add(this._tbNpc_textEm6_2);
            this._gpText.Controls.Add(this.label102);
            this._gpText.Controls.Add(this._tbNpc_textProb6);
            this._gpText.Controls.Add(this._tbNpc_textEm6_4);
            this._gpText.Controls.Add(this.label103);
            this._gpText.Controls.Add(this.label104);
            this._gpText.Controls.Add(this.label105);
            this._gpText.Controls.Add(this.label106);
            this._gpText.Controls.Add(this._tbNpc_textEm6_3);
            this._gpText.Controls.Add(this._tbNpc_textEm6_0);
            this._gpText.Controls.Add(this._tbNpc_textEm5_5);
            this._gpText.Controls.Add(this._cbNpc_textLang5);
            this._gpText.Controls.Add(this._tbNpc_text5_1);
            this._gpText.Controls.Add(this.label67);
            this._gpText.Controls.Add(this.label68);
            this._gpText.Controls.Add(this._tbNpc_textEm5_1);
            this._gpText.Controls.Add(this._tbNpc_text5_0);
            this._gpText.Controls.Add(this.label69);
            this._gpText.Controls.Add(this.label70);
            this._gpText.Controls.Add(this.label71);
            this._gpText.Controls.Add(this._tbNpc_textEm5_2);
            this._gpText.Controls.Add(this.label72);
            this._gpText.Controls.Add(this._tbNpc_textProb5);
            this._gpText.Controls.Add(this._tbNpc_textEm5_4);
            this._gpText.Controls.Add(this.label73);
            this._gpText.Controls.Add(this.label74);
            this._gpText.Controls.Add(this.label75);
            this._gpText.Controls.Add(this.label76);
            this._gpText.Controls.Add(this._tbNpc_textEm5_3);
            this._gpText.Controls.Add(this._tbNpc_textEm5_0);
            this._gpText.Controls.Add(this._tbNpc_textEm4_5);
            this._gpText.Controls.Add(this._cbNpc_textLang4);
            this._gpText.Controls.Add(this._tbNpc_text4_1);
            this._gpText.Controls.Add(this.label77);
            this._gpText.Controls.Add(this.label78);
            this._gpText.Controls.Add(this._tbNpc_textEm4_1);
            this._gpText.Controls.Add(this._tbNpc_text4_0);
            this._gpText.Controls.Add(this.label79);
            this._gpText.Controls.Add(this.label80);
            this._gpText.Controls.Add(this.label81);
            this._gpText.Controls.Add(this._tbNpc_textEm4_2);
            this._gpText.Controls.Add(this.label82);
            this._gpText.Controls.Add(this._tbNpc_textProb4);
            this._gpText.Controls.Add(this._tbNpc_textEm4_4);
            this._gpText.Controls.Add(this.label83);
            this._gpText.Controls.Add(this.label84);
            this._gpText.Controls.Add(this.label85);
            this._gpText.Controls.Add(this.label86);
            this._gpText.Controls.Add(this._tbNpc_textEm4_3);
            this._gpText.Controls.Add(this._tbNpc_textEm4_0);
            this._gpText.Controls.Add(this._cbNpc_textLang3);
            this._gpText.Controls.Add(this._tbNpc_text3_1);
            this._gpText.Controls.Add(this.label87);
            this._gpText.Controls.Add(this.label88);
            this._gpText.Controls.Add(this._tbNpc_textEm3_1);
            this._gpText.Controls.Add(this._tbNpc_text3_0);
            this._gpText.Controls.Add(this.label89);
            this._gpText.Controls.Add(this._tbNpc_textEm3_5);
            this._gpText.Controls.Add(this.label90);
            this._gpText.Controls.Add(this.label91);
            this._gpText.Controls.Add(this._tbNpc_textEm3_2);
            this._gpText.Controls.Add(this.label92);
            this._gpText.Controls.Add(this._tbNpc_textProb3);
            this._gpText.Controls.Add(this._tbNpc_textEm3_4);
            this._gpText.Controls.Add(this.label93);
            this._gpText.Controls.Add(this.label94);
            this._gpText.Controls.Add(this.label95);
            this._gpText.Controls.Add(this.label96);
            this._gpText.Controls.Add(this._tbNpc_textEm3_3);
            this._gpText.Controls.Add(this._tbNpc_textEm3_0);
            this._gpText.Controls.Add(this._tbNpc_textEm2_5);
            this._gpText.Controls.Add(this._cbNpc_textLang2);
            this._gpText.Controls.Add(this._tbNpc_text2_1);
            this._gpText.Controls.Add(this.label57);
            this._gpText.Controls.Add(this.label58);
            this._gpText.Controls.Add(this._tbNpc_textEm2_1);
            this._gpText.Controls.Add(this._tbNpc_text2_0);
            this._gpText.Controls.Add(this.label59);
            this._gpText.Controls.Add(this.label60);
            this._gpText.Controls.Add(this.label61);
            this._gpText.Controls.Add(this._tbNpc_textEm2_2);
            this._gpText.Controls.Add(this.label62);
            this._gpText.Controls.Add(this._tbNpc_textProb2);
            this._gpText.Controls.Add(this._tbNpc_textEm2_4);
            this._gpText.Controls.Add(this.label63);
            this._gpText.Controls.Add(this.label64);
            this._gpText.Controls.Add(this.label65);
            this._gpText.Controls.Add(this.label66);
            this._gpText.Controls.Add(this._tbNpc_textEm2_3);
            this._gpText.Controls.Add(this._tbNpc_textEm2_0);
            this._gpText.Controls.Add(this._tbNpc_textEm1_5);
            this._gpText.Controls.Add(this._cbNpc_textLang1);
            this._gpText.Controls.Add(this._tbNpc_text1_1);
            this._gpText.Controls.Add(this.label47);
            this._gpText.Controls.Add(this.label48);
            this._gpText.Controls.Add(this._tbNpc_textEm1_1);
            this._gpText.Controls.Add(this._tbNpc_text1_0);
            this._gpText.Controls.Add(this.label49);
            this._gpText.Controls.Add(this.label50);
            this._gpText.Controls.Add(this.label51);
            this._gpText.Controls.Add(this._tbNpc_textEm1_2);
            this._gpText.Controls.Add(this.label52);
            this._gpText.Controls.Add(this._tbNpc_textProb1);
            this._gpText.Controls.Add(this._tbNpc_textEm1_4);
            this._gpText.Controls.Add(this.label53);
            this._gpText.Controls.Add(this.label54);
            this._gpText.Controls.Add(this.label55);
            this._gpText.Controls.Add(this.label56);
            this._gpText.Controls.Add(this._tbNpc_textEm1_3);
            this._gpText.Controls.Add(this._tbNpc_textEm1_0);
            this._gpText.Controls.Add(this._cbNpc_textLang0);
            this._gpText.Controls.Add(this.label36);
            this._gpText.Controls.Add(this.bNpcTextCreate);
            this._gpText.Controls.Add(this._tbNpc_textID);
            this._gpText.Controls.Add(this._tbNpc_text0_1);
            this._gpText.Controls.Add(this.bNpcTextRecord);
            this._gpText.Controls.Add(this.label37);
            this._gpText.Controls.Add(this.rtbNpcTextOut);
            this._gpText.Controls.Add(this.label46);
            this._gpText.Controls.Add(this._tbNpc_textEm0_1);
            this._gpText.Controls.Add(this._tbNpc_text0_0);
            this._gpText.Controls.Add(this.label42);
            this._gpText.Controls.Add(this._tbNpc_textEm0_5);
            this._gpText.Controls.Add(this.label41);
            this._gpText.Controls.Add(this.label38);
            this._gpText.Controls.Add(this._tbNpc_textEm0_2);
            this._gpText.Controls.Add(this.label45);
            this._gpText.Controls.Add(this._tbNpc_textProb0);
            this._gpText.Controls.Add(this._tbNpc_textEm0_4);
            this._gpText.Controls.Add(this.label43);
            this._gpText.Controls.Add(this.label39);
            this._gpText.Controls.Add(this.label40);
            this._gpText.Controls.Add(this.label44);
            this._gpText.Controls.Add(this._tbNpc_textEm0_3);
            this._gpText.Controls.Add(this._tbNpc_textEm0_0);
            this._gpText.Location = new System.Drawing.Point(8, 115);
            this._gpText.Name = "_gpText";
            this._gpText.Size = new System.Drawing.Size(1037, 486);
            this._gpText.TabIndex = 31;
            this._gpText.TabStop = false;
            // 
            // _tbNpc_textEm7_5
            // 
            this._tbNpc_textEm7_5.Location = new System.Drawing.Point(977, 377);
            this._tbNpc_textEm7_5.Name = "_tbNpc_textEm7_5";
            this._tbNpc_textEm7_5.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm7_5.TabIndex = 210;
            // 
            // _cbNpc_textLang7
            // 
            this._cbNpc_textLang7.FormattingEnabled = true;
            this._cbNpc_textLang7.Location = new System.Drawing.Point(598, 403);
            this._cbNpc_textLang7.Name = "_cbNpc_textLang7";
            this._cbNpc_textLang7.Size = new System.Drawing.Size(253, 21);
            this._cbNpc_textLang7.TabIndex = 209;
            // 
            // _tbNpc_text7_1
            // 
            this._tbNpc_text7_1.Location = new System.Drawing.Point(253, 403);
            this._tbNpc_text7_1.Name = "_tbNpc_text7_1";
            this._tbNpc_text7_1.Size = new System.Drawing.Size(284, 20);
            this._tbNpc_text7_1.TabIndex = 191;
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Location = new System.Drawing.Point(206, 406);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(46, 13);
            this.label107.TabIndex = 192;
            this.label107.Text = "Text7_1";
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Location = new System.Drawing.Point(932, 381);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(39, 13);
            this.label108.TabIndex = 208;
            this.label108.Text = "em7_5";
            // 
            // _tbNpc_textEm7_1
            // 
            this._tbNpc_textEm7_1.Location = new System.Drawing.Point(677, 377);
            this._tbNpc_textEm7_1.Name = "_tbNpc_textEm7_1";
            this._tbNpc_textEm7_1.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm7_1.TabIndex = 200;
            // 
            // _tbNpc_text7_0
            // 
            this._tbNpc_text7_0.Location = new System.Drawing.Point(253, 377);
            this._tbNpc_text7_0.Name = "_tbNpc_text7_0";
            this._tbNpc_text7_0.Size = new System.Drawing.Size(284, 20);
            this._tbNpc_text7_0.TabIndex = 193;
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Location = new System.Drawing.Point(632, 381);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(39, 13);
            this.label109.TabIndex = 201;
            this.label109.Text = "em7_1";
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Location = new System.Drawing.Point(857, 406);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(35, 13);
            this.label110.TabIndex = 199;
            this.label110.Text = "Prob7";
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Location = new System.Drawing.Point(206, 380);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(46, 13);
            this.label111.TabIndex = 194;
            this.label111.Text = "Text7_0";
            this.label111.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // _tbNpc_textEm7_2
            // 
            this._tbNpc_textEm7_2.Location = new System.Drawing.Point(752, 378);
            this._tbNpc_textEm7_2.Name = "_tbNpc_textEm7_2";
            this._tbNpc_textEm7_2.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm7_2.TabIndex = 202;
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.Location = new System.Drawing.Point(857, 381);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(39, 13);
            this.label112.TabIndex = 207;
            this.label112.Text = "em7_4";
            // 
            // _tbNpc_textProb7
            // 
            this._tbNpc_textProb7.Location = new System.Drawing.Point(902, 403);
            this._tbNpc_textProb7.Name = "_tbNpc_textProb7";
            this._tbNpc_textProb7.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textProb7.TabIndex = 198;
            // 
            // _tbNpc_textEm7_4
            // 
            this._tbNpc_textEm7_4.Location = new System.Drawing.Point(902, 378);
            this._tbNpc_textEm7_4.Name = "_tbNpc_textEm7_4";
            this._tbNpc_textEm7_4.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm7_4.TabIndex = 206;
            // 
            // label113
            // 
            this.label113.AutoSize = true;
            this.label113.Location = new System.Drawing.Point(707, 381);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(39, 13);
            this.label113.TabIndex = 203;
            this.label113.Text = "em7_2";
            // 
            // label114
            // 
            this.label114.AutoSize = true;
            this.label114.Location = new System.Drawing.Point(555, 406);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(37, 13);
            this.label114.TabIndex = 195;
            this.label114.Text = "Lang7";
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.Location = new System.Drawing.Point(557, 380);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(39, 13);
            this.label115.TabIndex = 197;
            this.label115.Text = "em7_0";
            // 
            // label116
            // 
            this.label116.AutoSize = true;
            this.label116.Location = new System.Drawing.Point(782, 381);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(39, 13);
            this.label116.TabIndex = 205;
            this.label116.Text = "em7_3";
            // 
            // _tbNpc_textEm7_3
            // 
            this._tbNpc_textEm7_3.Location = new System.Drawing.Point(827, 377);
            this._tbNpc_textEm7_3.Name = "_tbNpc_textEm7_3";
            this._tbNpc_textEm7_3.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm7_3.TabIndex = 204;
            // 
            // _tbNpc_textEm7_0
            // 
            this._tbNpc_textEm7_0.Location = new System.Drawing.Point(598, 377);
            this._tbNpc_textEm7_0.Name = "_tbNpc_textEm7_0";
            this._tbNpc_textEm7_0.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm7_0.TabIndex = 196;
            // 
            // _tbNpc_textEm6_5
            // 
            this._tbNpc_textEm6_5.Location = new System.Drawing.Point(977, 325);
            this._tbNpc_textEm6_5.Name = "_tbNpc_textEm6_5";
            this._tbNpc_textEm6_5.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm6_5.TabIndex = 190;
            // 
            // _cbNpc_textLang6
            // 
            this._cbNpc_textLang6.FormattingEnabled = true;
            this._cbNpc_textLang6.Location = new System.Drawing.Point(598, 351);
            this._cbNpc_textLang6.Name = "_cbNpc_textLang6";
            this._cbNpc_textLang6.Size = new System.Drawing.Size(253, 21);
            this._cbNpc_textLang6.TabIndex = 189;
            // 
            // _tbNpc_text6_1
            // 
            this._tbNpc_text6_1.Location = new System.Drawing.Point(253, 351);
            this._tbNpc_text6_1.Name = "_tbNpc_text6_1";
            this._tbNpc_text6_1.Size = new System.Drawing.Size(284, 20);
            this._tbNpc_text6_1.TabIndex = 171;
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Location = new System.Drawing.Point(206, 354);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(46, 13);
            this.label97.TabIndex = 172;
            this.label97.Text = "Text6_1";
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Location = new System.Drawing.Point(932, 329);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(39, 13);
            this.label98.TabIndex = 188;
            this.label98.Text = "em6_5";
            // 
            // _tbNpc_textEm6_1
            // 
            this._tbNpc_textEm6_1.Location = new System.Drawing.Point(677, 325);
            this._tbNpc_textEm6_1.Name = "_tbNpc_textEm6_1";
            this._tbNpc_textEm6_1.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm6_1.TabIndex = 180;
            // 
            // _tbNpc_text6_0
            // 
            this._tbNpc_text6_0.Location = new System.Drawing.Point(253, 325);
            this._tbNpc_text6_0.Name = "_tbNpc_text6_0";
            this._tbNpc_text6_0.Size = new System.Drawing.Size(284, 20);
            this._tbNpc_text6_0.TabIndex = 173;
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Location = new System.Drawing.Point(632, 329);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(39, 13);
            this.label99.TabIndex = 181;
            this.label99.Text = "em6_1";
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Location = new System.Drawing.Point(857, 354);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(35, 13);
            this.label100.TabIndex = 179;
            this.label100.Text = "Prob6";
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Location = new System.Drawing.Point(206, 328);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(46, 13);
            this.label101.TabIndex = 174;
            this.label101.Text = "Text6_0";
            this.label101.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // _tbNpc_textEm6_2
            // 
            this._tbNpc_textEm6_2.Location = new System.Drawing.Point(752, 326);
            this._tbNpc_textEm6_2.Name = "_tbNpc_textEm6_2";
            this._tbNpc_textEm6_2.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm6_2.TabIndex = 182;
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Location = new System.Drawing.Point(857, 329);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(39, 13);
            this.label102.TabIndex = 187;
            this.label102.Text = "em6_4";
            // 
            // _tbNpc_textProb6
            // 
            this._tbNpc_textProb6.Location = new System.Drawing.Point(902, 351);
            this._tbNpc_textProb6.Name = "_tbNpc_textProb6";
            this._tbNpc_textProb6.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textProb6.TabIndex = 178;
            // 
            // _tbNpc_textEm6_4
            // 
            this._tbNpc_textEm6_4.Location = new System.Drawing.Point(902, 326);
            this._tbNpc_textEm6_4.Name = "_tbNpc_textEm6_4";
            this._tbNpc_textEm6_4.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm6_4.TabIndex = 186;
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Location = new System.Drawing.Point(707, 329);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(39, 13);
            this.label103.TabIndex = 183;
            this.label103.Text = "em6_2";
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Location = new System.Drawing.Point(555, 354);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(37, 13);
            this.label104.TabIndex = 175;
            this.label104.Text = "Lang6";
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Location = new System.Drawing.Point(557, 328);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(39, 13);
            this.label105.TabIndex = 177;
            this.label105.Text = "em6_0";
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Location = new System.Drawing.Point(782, 329);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(39, 13);
            this.label106.TabIndex = 185;
            this.label106.Text = "em6_3";
            // 
            // _tbNpc_textEm6_3
            // 
            this._tbNpc_textEm6_3.Location = new System.Drawing.Point(827, 325);
            this._tbNpc_textEm6_3.Name = "_tbNpc_textEm6_3";
            this._tbNpc_textEm6_3.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm6_3.TabIndex = 184;
            // 
            // _tbNpc_textEm6_0
            // 
            this._tbNpc_textEm6_0.Location = new System.Drawing.Point(598, 325);
            this._tbNpc_textEm6_0.Name = "_tbNpc_textEm6_0";
            this._tbNpc_textEm6_0.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm6_0.TabIndex = 176;
            // 
            // _tbNpc_textEm5_5
            // 
            this._tbNpc_textEm5_5.Location = new System.Drawing.Point(977, 273);
            this._tbNpc_textEm5_5.Name = "_tbNpc_textEm5_5";
            this._tbNpc_textEm5_5.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm5_5.TabIndex = 170;
            // 
            // _cbNpc_textLang5
            // 
            this._cbNpc_textLang5.FormattingEnabled = true;
            this._cbNpc_textLang5.Location = new System.Drawing.Point(598, 299);
            this._cbNpc_textLang5.Name = "_cbNpc_textLang5";
            this._cbNpc_textLang5.Size = new System.Drawing.Size(253, 21);
            this._cbNpc_textLang5.TabIndex = 169;
            // 
            // _tbNpc_text5_1
            // 
            this._tbNpc_text5_1.Location = new System.Drawing.Point(253, 299);
            this._tbNpc_text5_1.Name = "_tbNpc_text5_1";
            this._tbNpc_text5_1.Size = new System.Drawing.Size(284, 20);
            this._tbNpc_text5_1.TabIndex = 151;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(206, 302);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(46, 13);
            this.label67.TabIndex = 152;
            this.label67.Text = "Text5_1";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(932, 277);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(39, 13);
            this.label68.TabIndex = 168;
            this.label68.Text = "em5_5";
            // 
            // _tbNpc_textEm5_1
            // 
            this._tbNpc_textEm5_1.Location = new System.Drawing.Point(677, 273);
            this._tbNpc_textEm5_1.Name = "_tbNpc_textEm5_1";
            this._tbNpc_textEm5_1.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm5_1.TabIndex = 160;
            // 
            // _tbNpc_text5_0
            // 
            this._tbNpc_text5_0.Location = new System.Drawing.Point(253, 273);
            this._tbNpc_text5_0.Name = "_tbNpc_text5_0";
            this._tbNpc_text5_0.Size = new System.Drawing.Size(284, 20);
            this._tbNpc_text5_0.TabIndex = 153;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(632, 277);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(39, 13);
            this.label69.TabIndex = 161;
            this.label69.Text = "em5_1";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(857, 302);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(35, 13);
            this.label70.TabIndex = 159;
            this.label70.Text = "Prob2";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(206, 276);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(46, 13);
            this.label71.TabIndex = 154;
            this.label71.Text = "Text5_0";
            this.label71.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // _tbNpc_textEm5_2
            // 
            this._tbNpc_textEm5_2.Location = new System.Drawing.Point(752, 274);
            this._tbNpc_textEm5_2.Name = "_tbNpc_textEm5_2";
            this._tbNpc_textEm5_2.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm5_2.TabIndex = 162;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(857, 277);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(39, 13);
            this.label72.TabIndex = 167;
            this.label72.Text = "em5_4";
            // 
            // _tbNpc_textProb5
            // 
            this._tbNpc_textProb5.Location = new System.Drawing.Point(902, 299);
            this._tbNpc_textProb5.Name = "_tbNpc_textProb5";
            this._tbNpc_textProb5.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textProb5.TabIndex = 158;
            // 
            // _tbNpc_textEm5_4
            // 
            this._tbNpc_textEm5_4.Location = new System.Drawing.Point(902, 274);
            this._tbNpc_textEm5_4.Name = "_tbNpc_textEm5_4";
            this._tbNpc_textEm5_4.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm5_4.TabIndex = 166;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(707, 277);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(39, 13);
            this.label73.TabIndex = 163;
            this.label73.Text = "em5_2";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(555, 302);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(37, 13);
            this.label74.TabIndex = 155;
            this.label74.Text = "Lang5";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(557, 276);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(39, 13);
            this.label75.TabIndex = 157;
            this.label75.Text = "em5_0";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(782, 277);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(39, 13);
            this.label76.TabIndex = 165;
            this.label76.Text = "em5_3";
            // 
            // _tbNpc_textEm5_3
            // 
            this._tbNpc_textEm5_3.Location = new System.Drawing.Point(827, 273);
            this._tbNpc_textEm5_3.Name = "_tbNpc_textEm5_3";
            this._tbNpc_textEm5_3.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm5_3.TabIndex = 164;
            // 
            // _tbNpc_textEm5_0
            // 
            this._tbNpc_textEm5_0.Location = new System.Drawing.Point(598, 273);
            this._tbNpc_textEm5_0.Name = "_tbNpc_textEm5_0";
            this._tbNpc_textEm5_0.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm5_0.TabIndex = 156;
            // 
            // _tbNpc_textEm4_5
            // 
            this._tbNpc_textEm4_5.Location = new System.Drawing.Point(977, 221);
            this._tbNpc_textEm4_5.Name = "_tbNpc_textEm4_5";
            this._tbNpc_textEm4_5.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm4_5.TabIndex = 150;
            // 
            // _cbNpc_textLang4
            // 
            this._cbNpc_textLang4.FormattingEnabled = true;
            this._cbNpc_textLang4.Location = new System.Drawing.Point(598, 247);
            this._cbNpc_textLang4.Name = "_cbNpc_textLang4";
            this._cbNpc_textLang4.Size = new System.Drawing.Size(253, 21);
            this._cbNpc_textLang4.TabIndex = 149;
            // 
            // _tbNpc_text4_1
            // 
            this._tbNpc_text4_1.Location = new System.Drawing.Point(253, 247);
            this._tbNpc_text4_1.Name = "_tbNpc_text4_1";
            this._tbNpc_text4_1.Size = new System.Drawing.Size(284, 20);
            this._tbNpc_text4_1.TabIndex = 131;
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(206, 250);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(46, 13);
            this.label77.TabIndex = 132;
            this.label77.Text = "Text4_1";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(932, 225);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(39, 13);
            this.label78.TabIndex = 148;
            this.label78.Text = "em4_5";
            // 
            // _tbNpc_textEm4_1
            // 
            this._tbNpc_textEm4_1.Location = new System.Drawing.Point(677, 221);
            this._tbNpc_textEm4_1.Name = "_tbNpc_textEm4_1";
            this._tbNpc_textEm4_1.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm4_1.TabIndex = 140;
            // 
            // _tbNpc_text4_0
            // 
            this._tbNpc_text4_0.Location = new System.Drawing.Point(253, 221);
            this._tbNpc_text4_0.Name = "_tbNpc_text4_0";
            this._tbNpc_text4_0.Size = new System.Drawing.Size(284, 20);
            this._tbNpc_text4_0.TabIndex = 133;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(632, 225);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(39, 13);
            this.label79.TabIndex = 141;
            this.label79.Text = "em4_1";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(857, 250);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(35, 13);
            this.label80.TabIndex = 139;
            this.label80.Text = "Prob4";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(206, 224);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(46, 13);
            this.label81.TabIndex = 134;
            this.label81.Text = "Text4_0";
            this.label81.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // _tbNpc_textEm4_2
            // 
            this._tbNpc_textEm4_2.Location = new System.Drawing.Point(752, 222);
            this._tbNpc_textEm4_2.Name = "_tbNpc_textEm4_2";
            this._tbNpc_textEm4_2.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm4_2.TabIndex = 142;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(857, 225);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(39, 13);
            this.label82.TabIndex = 147;
            this.label82.Text = "em4_4";
            // 
            // _tbNpc_textProb4
            // 
            this._tbNpc_textProb4.Location = new System.Drawing.Point(902, 247);
            this._tbNpc_textProb4.Name = "_tbNpc_textProb4";
            this._tbNpc_textProb4.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textProb4.TabIndex = 138;
            // 
            // _tbNpc_textEm4_4
            // 
            this._tbNpc_textEm4_4.Location = new System.Drawing.Point(902, 222);
            this._tbNpc_textEm4_4.Name = "_tbNpc_textEm4_4";
            this._tbNpc_textEm4_4.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm4_4.TabIndex = 146;
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(707, 225);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(39, 13);
            this.label83.TabIndex = 143;
            this.label83.Text = "em4_2";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(555, 250);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(37, 13);
            this.label84.TabIndex = 135;
            this.label84.Text = "Lang4";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Location = new System.Drawing.Point(557, 224);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(39, 13);
            this.label85.TabIndex = 137;
            this.label85.Text = "em4_0";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Location = new System.Drawing.Point(782, 225);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(39, 13);
            this.label86.TabIndex = 145;
            this.label86.Text = "em4_3";
            // 
            // _tbNpc_textEm4_3
            // 
            this._tbNpc_textEm4_3.Location = new System.Drawing.Point(827, 221);
            this._tbNpc_textEm4_3.Name = "_tbNpc_textEm4_3";
            this._tbNpc_textEm4_3.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm4_3.TabIndex = 144;
            // 
            // _tbNpc_textEm4_0
            // 
            this._tbNpc_textEm4_0.Location = new System.Drawing.Point(598, 221);
            this._tbNpc_textEm4_0.Name = "_tbNpc_textEm4_0";
            this._tbNpc_textEm4_0.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm4_0.TabIndex = 136;
            // 
            // _cbNpc_textLang3
            // 
            this._cbNpc_textLang3.FormattingEnabled = true;
            this._cbNpc_textLang3.Location = new System.Drawing.Point(598, 195);
            this._cbNpc_textLang3.Name = "_cbNpc_textLang3";
            this._cbNpc_textLang3.Size = new System.Drawing.Size(253, 21);
            this._cbNpc_textLang3.TabIndex = 130;
            // 
            // _tbNpc_text3_1
            // 
            this._tbNpc_text3_1.Location = new System.Drawing.Point(253, 195);
            this._tbNpc_text3_1.Name = "_tbNpc_text3_1";
            this._tbNpc_text3_1.Size = new System.Drawing.Size(284, 20);
            this._tbNpc_text3_1.TabIndex = 111;
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Location = new System.Drawing.Point(206, 198);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(46, 13);
            this.label87.TabIndex = 112;
            this.label87.Text = "Text3_1";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Location = new System.Drawing.Point(932, 173);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(39, 13);
            this.label88.TabIndex = 129;
            this.label88.Text = "em3_5";
            // 
            // _tbNpc_textEm3_1
            // 
            this._tbNpc_textEm3_1.Location = new System.Drawing.Point(677, 169);
            this._tbNpc_textEm3_1.Name = "_tbNpc_textEm3_1";
            this._tbNpc_textEm3_1.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm3_1.TabIndex = 120;
            // 
            // _tbNpc_text3_0
            // 
            this._tbNpc_text3_0.Location = new System.Drawing.Point(253, 169);
            this._tbNpc_text3_0.Name = "_tbNpc_text3_0";
            this._tbNpc_text3_0.Size = new System.Drawing.Size(284, 20);
            this._tbNpc_text3_0.TabIndex = 113;
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Location = new System.Drawing.Point(632, 173);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(39, 13);
            this.label89.TabIndex = 121;
            this.label89.Text = "em3_1";
            // 
            // _tbNpc_textEm3_5
            // 
            this._tbNpc_textEm3_5.Location = new System.Drawing.Point(977, 170);
            this._tbNpc_textEm3_5.Name = "_tbNpc_textEm3_5";
            this._tbNpc_textEm3_5.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm3_5.TabIndex = 128;
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Location = new System.Drawing.Point(857, 198);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(35, 13);
            this.label90.TabIndex = 119;
            this.label90.Text = "Prob3";
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Location = new System.Drawing.Point(206, 172);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(46, 13);
            this.label91.TabIndex = 114;
            this.label91.Text = "Text3_0";
            this.label91.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // _tbNpc_textEm3_2
            // 
            this._tbNpc_textEm3_2.Location = new System.Drawing.Point(752, 170);
            this._tbNpc_textEm3_2.Name = "_tbNpc_textEm3_2";
            this._tbNpc_textEm3_2.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm3_2.TabIndex = 122;
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Location = new System.Drawing.Point(857, 173);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(39, 13);
            this.label92.TabIndex = 127;
            this.label92.Text = "em3_4";
            // 
            // _tbNpc_textProb3
            // 
            this._tbNpc_textProb3.Location = new System.Drawing.Point(902, 195);
            this._tbNpc_textProb3.Name = "_tbNpc_textProb3";
            this._tbNpc_textProb3.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textProb3.TabIndex = 118;
            // 
            // _tbNpc_textEm3_4
            // 
            this._tbNpc_textEm3_4.Location = new System.Drawing.Point(902, 170);
            this._tbNpc_textEm3_4.Name = "_tbNpc_textEm3_4";
            this._tbNpc_textEm3_4.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm3_4.TabIndex = 126;
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Location = new System.Drawing.Point(707, 173);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(39, 13);
            this.label93.TabIndex = 123;
            this.label93.Text = "em3_2";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Location = new System.Drawing.Point(555, 198);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(37, 13);
            this.label94.TabIndex = 115;
            this.label94.Text = "Lang3";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Location = new System.Drawing.Point(557, 172);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(39, 13);
            this.label95.TabIndex = 117;
            this.label95.Text = "em3_0";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Location = new System.Drawing.Point(782, 173);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(39, 13);
            this.label96.TabIndex = 125;
            this.label96.Text = "em3_3";
            // 
            // _tbNpc_textEm3_3
            // 
            this._tbNpc_textEm3_3.Location = new System.Drawing.Point(827, 169);
            this._tbNpc_textEm3_3.Name = "_tbNpc_textEm3_3";
            this._tbNpc_textEm3_3.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm3_3.TabIndex = 124;
            // 
            // _tbNpc_textEm3_0
            // 
            this._tbNpc_textEm3_0.Location = new System.Drawing.Point(598, 170);
            this._tbNpc_textEm3_0.Name = "_tbNpc_textEm3_0";
            this._tbNpc_textEm3_0.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm3_0.TabIndex = 116;
            // 
            // _tbNpc_textEm2_5
            // 
            this._tbNpc_textEm2_5.Location = new System.Drawing.Point(977, 117);
            this._tbNpc_textEm2_5.Name = "_tbNpc_textEm2_5";
            this._tbNpc_textEm2_5.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm2_5.TabIndex = 110;
            // 
            // _cbNpc_textLang2
            // 
            this._cbNpc_textLang2.FormattingEnabled = true;
            this._cbNpc_textLang2.Location = new System.Drawing.Point(598, 143);
            this._cbNpc_textLang2.Name = "_cbNpc_textLang2";
            this._cbNpc_textLang2.Size = new System.Drawing.Size(253, 21);
            this._cbNpc_textLang2.TabIndex = 109;
            // 
            // _tbNpc_text2_1
            // 
            this._tbNpc_text2_1.Location = new System.Drawing.Point(253, 143);
            this._tbNpc_text2_1.Name = "_tbNpc_text2_1";
            this._tbNpc_text2_1.Size = new System.Drawing.Size(284, 20);
            this._tbNpc_text2_1.TabIndex = 91;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(206, 146);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(46, 13);
            this.label57.TabIndex = 92;
            this.label57.Text = "Text2_1";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(932, 121);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(39, 13);
            this.label58.TabIndex = 108;
            this.label58.Text = "em2_5";
            // 
            // _tbNpc_textEm2_1
            // 
            this._tbNpc_textEm2_1.Location = new System.Drawing.Point(677, 117);
            this._tbNpc_textEm2_1.Name = "_tbNpc_textEm2_1";
            this._tbNpc_textEm2_1.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm2_1.TabIndex = 100;
            // 
            // _tbNpc_text2_0
            // 
            this._tbNpc_text2_0.Location = new System.Drawing.Point(253, 117);
            this._tbNpc_text2_0.Name = "_tbNpc_text2_0";
            this._tbNpc_text2_0.Size = new System.Drawing.Size(284, 20);
            this._tbNpc_text2_0.TabIndex = 93;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(632, 121);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(39, 13);
            this.label59.TabIndex = 101;
            this.label59.Text = "em2_1";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(857, 146);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(35, 13);
            this.label60.TabIndex = 99;
            this.label60.Text = "Prob2";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(206, 120);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(46, 13);
            this.label61.TabIndex = 94;
            this.label61.Text = "Text2_0";
            this.label61.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // _tbNpc_textEm2_2
            // 
            this._tbNpc_textEm2_2.Location = new System.Drawing.Point(752, 118);
            this._tbNpc_textEm2_2.Name = "_tbNpc_textEm2_2";
            this._tbNpc_textEm2_2.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm2_2.TabIndex = 102;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(857, 121);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(39, 13);
            this.label62.TabIndex = 107;
            this.label62.Text = "em2_4";
            // 
            // _tbNpc_textProb2
            // 
            this._tbNpc_textProb2.Location = new System.Drawing.Point(902, 143);
            this._tbNpc_textProb2.Name = "_tbNpc_textProb2";
            this._tbNpc_textProb2.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textProb2.TabIndex = 98;
            // 
            // _tbNpc_textEm2_4
            // 
            this._tbNpc_textEm2_4.Location = new System.Drawing.Point(902, 118);
            this._tbNpc_textEm2_4.Name = "_tbNpc_textEm2_4";
            this._tbNpc_textEm2_4.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm2_4.TabIndex = 106;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(707, 121);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(39, 13);
            this.label63.TabIndex = 103;
            this.label63.Text = "em2_2";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(555, 146);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(37, 13);
            this.label64.TabIndex = 95;
            this.label64.Text = "Lang2";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(557, 120);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(39, 13);
            this.label65.TabIndex = 97;
            this.label65.Text = "em2_0";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(782, 121);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(39, 13);
            this.label66.TabIndex = 105;
            this.label66.Text = "em2_3";
            // 
            // _tbNpc_textEm2_3
            // 
            this._tbNpc_textEm2_3.Location = new System.Drawing.Point(827, 117);
            this._tbNpc_textEm2_3.Name = "_tbNpc_textEm2_3";
            this._tbNpc_textEm2_3.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm2_3.TabIndex = 104;
            // 
            // _tbNpc_textEm2_0
            // 
            this._tbNpc_textEm2_0.Location = new System.Drawing.Point(598, 117);
            this._tbNpc_textEm2_0.Name = "_tbNpc_textEm2_0";
            this._tbNpc_textEm2_0.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm2_0.TabIndex = 96;
            // 
            // _tbNpc_textEm1_5
            // 
            this._tbNpc_textEm1_5.Location = new System.Drawing.Point(977, 65);
            this._tbNpc_textEm1_5.Name = "_tbNpc_textEm1_5";
            this._tbNpc_textEm1_5.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm1_5.TabIndex = 90;
            // 
            // _cbNpc_textLang1
            // 
            this._cbNpc_textLang1.FormattingEnabled = true;
            this._cbNpc_textLang1.Location = new System.Drawing.Point(598, 91);
            this._cbNpc_textLang1.Name = "_cbNpc_textLang1";
            this._cbNpc_textLang1.Size = new System.Drawing.Size(253, 21);
            this._cbNpc_textLang1.TabIndex = 89;
            // 
            // _tbNpc_text1_1
            // 
            this._tbNpc_text1_1.Location = new System.Drawing.Point(253, 91);
            this._tbNpc_text1_1.Name = "_tbNpc_text1_1";
            this._tbNpc_text1_1.Size = new System.Drawing.Size(284, 20);
            this._tbNpc_text1_1.TabIndex = 71;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(206, 94);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(46, 13);
            this.label47.TabIndex = 72;
            this.label47.Text = "Text1_1";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(932, 69);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(39, 13);
            this.label48.TabIndex = 88;
            this.label48.Text = "em1_5";
            // 
            // _tbNpc_textEm1_1
            // 
            this._tbNpc_textEm1_1.Location = new System.Drawing.Point(677, 65);
            this._tbNpc_textEm1_1.Name = "_tbNpc_textEm1_1";
            this._tbNpc_textEm1_1.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm1_1.TabIndex = 80;
            // 
            // _tbNpc_text1_0
            // 
            this._tbNpc_text1_0.Location = new System.Drawing.Point(253, 65);
            this._tbNpc_text1_0.Name = "_tbNpc_text1_0";
            this._tbNpc_text1_0.Size = new System.Drawing.Size(284, 20);
            this._tbNpc_text1_0.TabIndex = 73;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(632, 69);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(39, 13);
            this.label49.TabIndex = 81;
            this.label49.Text = "em1_1";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(857, 94);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(35, 13);
            this.label50.TabIndex = 79;
            this.label50.Text = "Prob1";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(206, 68);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(46, 13);
            this.label51.TabIndex = 74;
            this.label51.Text = "Text1_0";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // _tbNpc_textEm1_2
            // 
            this._tbNpc_textEm1_2.Location = new System.Drawing.Point(752, 66);
            this._tbNpc_textEm1_2.Name = "_tbNpc_textEm1_2";
            this._tbNpc_textEm1_2.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm1_2.TabIndex = 82;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(857, 69);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(39, 13);
            this.label52.TabIndex = 87;
            this.label52.Text = "em1_4";
            // 
            // _tbNpc_textProb1
            // 
            this._tbNpc_textProb1.Location = new System.Drawing.Point(902, 91);
            this._tbNpc_textProb1.Name = "_tbNpc_textProb1";
            this._tbNpc_textProb1.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textProb1.TabIndex = 78;
            // 
            // _tbNpc_textEm1_4
            // 
            this._tbNpc_textEm1_4.Location = new System.Drawing.Point(902, 66);
            this._tbNpc_textEm1_4.Name = "_tbNpc_textEm1_4";
            this._tbNpc_textEm1_4.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm1_4.TabIndex = 86;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(707, 69);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(39, 13);
            this.label53.TabIndex = 83;
            this.label53.Text = "em1_2";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(555, 94);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(37, 13);
            this.label54.TabIndex = 75;
            this.label54.Text = "Lang1";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(557, 68);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(39, 13);
            this.label55.TabIndex = 77;
            this.label55.Text = "em1_0";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(782, 69);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(39, 13);
            this.label56.TabIndex = 85;
            this.label56.Text = "em1_3";
            // 
            // _tbNpc_textEm1_3
            // 
            this._tbNpc_textEm1_3.Location = new System.Drawing.Point(827, 65);
            this._tbNpc_textEm1_3.Name = "_tbNpc_textEm1_3";
            this._tbNpc_textEm1_3.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm1_3.TabIndex = 84;
            // 
            // _tbNpc_textEm1_0
            // 
            this._tbNpc_textEm1_0.Location = new System.Drawing.Point(598, 65);
            this._tbNpc_textEm1_0.Name = "_tbNpc_textEm1_0";
            this._tbNpc_textEm1_0.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm1_0.TabIndex = 76;
            // 
            // _cbNpc_textLang0
            // 
            this._cbNpc_textLang0.FormattingEnabled = true;
            this._cbNpc_textLang0.Location = new System.Drawing.Point(598, 39);
            this._cbNpc_textLang0.Name = "_cbNpc_textLang0";
            this._cbNpc_textLang0.Size = new System.Drawing.Size(253, 21);
            this._cbNpc_textLang0.TabIndex = 22;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(6, 16);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(18, 13);
            this.label36.TabIndex = 1;
            this.label36.Text = "ID";
            // 
            // bNpcTextCreate
            // 
            this.bNpcTextCreate.AutoEllipsis = true;
            this.bNpcTextCreate.Location = new System.Drawing.Point(24, 342);
            this.bNpcTextCreate.Name = "bNpcTextCreate";
            this.bNpcTextCreate.Size = new System.Drawing.Size(143, 37);
            this.bNpcTextCreate.TabIndex = 69;
            this.bNpcTextCreate.Text = "Create";
            this.bNpcTextCreate.UseVisualStyleBackColor = true;
            this.bNpcTextCreate.Click += new System.EventHandler(this.bNpcTextCreate_Click);
            // 
            // _tbNpc_textID
            // 
            this._tbNpc_textID.Location = new System.Drawing.Point(53, 13);
            this._tbNpc_textID.Name = "_tbNpc_textID";
            this._tbNpc_textID.Size = new System.Drawing.Size(147, 20);
            this._tbNpc_textID.TabIndex = 0;
            // 
            // _tbNpc_text0_1
            // 
            this._tbNpc_text0_1.Location = new System.Drawing.Point(253, 39);
            this._tbNpc_text0_1.Name = "_tbNpc_text0_1";
            this._tbNpc_text0_1.Size = new System.Drawing.Size(284, 20);
            this._tbNpc_text0_1.TabIndex = 2;
            // 
            // bNpcTextRecord
            // 
            this.bNpcTextRecord.Location = new System.Drawing.Point(24, 385);
            this.bNpcTextRecord.Name = "bNpcTextRecord";
            this.bNpcTextRecord.Size = new System.Drawing.Size(143, 38);
            this.bNpcTextRecord.TabIndex = 70;
            this.bNpcTextRecord.Text = "Record";
            this.bNpcTextRecord.UseVisualStyleBackColor = true;
            this.bNpcTextRecord.Click += new System.EventHandler(this.bNpcTextRecord_Click);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(206, 42);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(46, 13);
            this.label37.TabIndex = 3;
            this.label37.Text = "Text0_1";
            // 
            // rtbNpcTextOut
            // 
            this.rtbNpcTextOut.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.rtbNpcTextOut.Location = new System.Drawing.Point(6, 429);
            this.rtbNpcTextOut.Name = "rtbNpcTextOut";
            this.rtbNpcTextOut.Size = new System.Drawing.Size(1025, 52);
            this.rtbNpcTextOut.TabIndex = 22;
            this.rtbNpcTextOut.Text = "";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(932, 17);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(39, 13);
            this.label46.TabIndex = 21;
            this.label46.Text = "em0_5";
            // 
            // _tbNpc_textEm0_1
            // 
            this._tbNpc_textEm0_1.Location = new System.Drawing.Point(677, 13);
            this._tbNpc_textEm0_1.Name = "_tbNpc_textEm0_1";
            this._tbNpc_textEm0_1.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm0_1.TabIndex = 12;
            // 
            // _tbNpc_text0_0
            // 
            this._tbNpc_text0_0.Location = new System.Drawing.Point(253, 13);
            this._tbNpc_text0_0.Name = "_tbNpc_text0_0";
            this._tbNpc_text0_0.Size = new System.Drawing.Size(284, 20);
            this._tbNpc_text0_0.TabIndex = 4;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(632, 17);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(39, 13);
            this.label42.TabIndex = 13;
            this.label42.Text = "em0_1";
            // 
            // _tbNpc_textEm0_5
            // 
            this._tbNpc_textEm0_5.Location = new System.Drawing.Point(977, 14);
            this._tbNpc_textEm0_5.Name = "_tbNpc_textEm0_5";
            this._tbNpc_textEm0_5.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm0_5.TabIndex = 20;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(857, 42);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(35, 13);
            this.label41.TabIndex = 11;
            this.label41.Text = "Prob0";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(206, 16);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(46, 13);
            this.label38.TabIndex = 5;
            this.label38.Text = "Text0_0";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // _tbNpc_textEm0_2
            // 
            this._tbNpc_textEm0_2.Location = new System.Drawing.Point(752, 14);
            this._tbNpc_textEm0_2.Name = "_tbNpc_textEm0_2";
            this._tbNpc_textEm0_2.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm0_2.TabIndex = 14;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(857, 17);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(39, 13);
            this.label45.TabIndex = 19;
            this.label45.Text = "em0_4";
            // 
            // _tbNpc_textProb0
            // 
            this._tbNpc_textProb0.Location = new System.Drawing.Point(902, 39);
            this._tbNpc_textProb0.Name = "_tbNpc_textProb0";
            this._tbNpc_textProb0.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textProb0.TabIndex = 10;
            // 
            // _tbNpc_textEm0_4
            // 
            this._tbNpc_textEm0_4.Location = new System.Drawing.Point(902, 14);
            this._tbNpc_textEm0_4.Name = "_tbNpc_textEm0_4";
            this._tbNpc_textEm0_4.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm0_4.TabIndex = 18;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(707, 17);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(39, 13);
            this.label43.TabIndex = 15;
            this.label43.Text = "em0_2";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(555, 42);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(37, 13);
            this.label39.TabIndex = 7;
            this.label39.Text = "Lang0";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(557, 16);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(39, 13);
            this.label40.TabIndex = 9;
            this.label40.Text = "em0_0";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(782, 17);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(39, 13);
            this.label44.TabIndex = 17;
            this.label44.Text = "em0_3";
            // 
            // _tbNpc_textEm0_3
            // 
            this._tbNpc_textEm0_3.Location = new System.Drawing.Point(827, 13);
            this._tbNpc_textEm0_3.Name = "_tbNpc_textEm0_3";
            this._tbNpc_textEm0_3.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm0_3.TabIndex = 16;
            // 
            // _tbNpc_textEm0_0
            // 
            this._tbNpc_textEm0_0.Location = new System.Drawing.Point(598, 14);
            this._tbNpc_textEm0_0.Name = "_tbNpc_textEm0_0";
            this._tbNpc_textEm0_0.Size = new System.Drawing.Size(24, 20);
            this._tbNpc_textEm0_0.TabIndex = 8;
            // 
            // groupBox11
            // 
            this.groupBox11.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox11.Controls.Add(this._lvNpcText);
            this.groupBox11.Location = new System.Drawing.Point(214, 3);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(831, 112);
            this.groupBox11.TabIndex = 30;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "npc_text";
            // 
            // _lvNpcText
            // 
            this._lvNpcText.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this._lvNpcText.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this._lvNpcText.GridLines = true;
            this._lvNpcText.Location = new System.Drawing.Point(6, 19);
            this._lvNpcText.Name = "_lvNpcText";
            this._lvNpcText.Size = new System.Drawing.Size(819, 87);
            this._lvNpcText.TabIndex = 0;
            this._lvNpcText.UseCompatibleStateImageBehavior = false;
            this._lvNpcText.View = System.Windows.Forms.View.Details;
            this._lvNpcText.VirtualMode = true;
            this._lvNpcText.RetrieveVirtualItem += new System.Windows.Forms.RetrieveVirtualItemEventHandler(this._lvNpcText_RetrieveVirtualItem);
            this._lvNpcText.SelectedIndexChanged += new System.EventHandler(this._lvNpcText_SelectedIndexChanged);
            // 
            // groupBox10
            // 
            this.groupBox10.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox10.Controls.Add(this._bFilterNpcText);
            this.groupBox10.Controls.Add(this._tbFilterNpcText);
            this.groupBox10.Location = new System.Drawing.Point(8, 3);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(200, 112);
            this.groupBox10.TabIndex = 0;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "NPC_TEXT";
            // 
            // _bFilterNpcText
            // 
            this._bFilterNpcText.Location = new System.Drawing.Point(42, 63);
            this._bFilterNpcText.Name = "_bFilterNpcText";
            this._bFilterNpcText.Size = new System.Drawing.Size(96, 28);
            this._bFilterNpcText.TabIndex = 1;
            this._bFilterNpcText.Text = "Filter";
            this._bFilterNpcText.UseVisualStyleBackColor = true;
            this._bFilterNpcText.Click += new System.EventHandler(this._bFilterNpcText_Click);
            // 
            // _tbFilterNpcText
            // 
            this._tbFilterNpcText.Location = new System.Drawing.Point(6, 28);
            this._tbFilterNpcText.Name = "_tbFilterNpcText";
            this._tbFilterNpcText.Size = new System.Drawing.Size(188, 20);
            this._tbFilterNpcText.TabIndex = 2;
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1056, 654);
            this.Controls.Add(this._tPanel);
            this.Controls.Add(this.menuStrip1);
            this.HelpButton = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FormMain";
            this.Text = "EventAI Designer";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this._cmFlag.ResumeLayout(false);
            this._cmPhase.ResumeLayout(false);
            this._tpScript.ResumeLayout(false);
            this._tpScript.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            this.splitContainer1.ResumeLayout(false);
            this.pMain.ResumeLayout(false);
            this._gbPhase.ResumeLayout(false);
            this._gbEventFlag.ResumeLayout(false);
            this._gbEventType.ResumeLayout(false);
            this._gbEventType.PerformLayout();
            this._gbAction2.ResumeLayout(false);
            this._gbAction2.PerformLayout();
            this._gbAction1.ResumeLayout(false);
            this._gbAction1.PerformLayout();
            this._gbAction3.ResumeLayout(false);
            this._gbAction3.PerformLayout();
            this._tPanel.ResumeLayout(false);
            this._tpText.ResumeLayout(false);
            this._tpText.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this._tpSummon.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this._tpGossip.ResumeLayout(false);
            this._gbGossipMenu.ResumeLayout(false);
            this._gbGossipMenu.PerformLayout();
            this._gbGossipCondtion2.ResumeLayout(false);
            this._gbGossipCondtion2.PerformLayout();
            this._gbGossipCondtion1.ResumeLayout(false);
            this._gbGossipCondtion1.PerformLayout();
            this._panelGossip_menu.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this._tpGossipOption.ResumeLayout(false);
            this._gbGossipMenuOption.ResumeLayout(false);
            this._gbGossipMenuOption.PerformLayout();
            this._gbGossipOptionCondtion3.ResumeLayout(false);
            this._gbGossipOptionCondtion3.PerformLayout();
            this._gbGossipOptionCondtion2.ResumeLayout(false);
            this._gbGossipOptionCondtion2.PerformLayout();
            this._gbGossipOptionCondtion1.ResumeLayout(false);
            this._gbGossipOptionCondtion1.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this._tbNpcText.ResumeLayout(false);
            this._gpText.ResumeLayout(false);
            this._gpText.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem новыйСкриптToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сохранитьСкриптToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem настройкиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem помощьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
        private System.Windows.Forms.ToolTip HelpEntry;
        private System.Windows.Forms.TabPage _tpScript;
        private System.Windows.Forms.Button _bWriteFiles;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox _tbShance;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox _tbEntryNpc;
        private System.Windows.Forms.TextBox _tbScriptID;
        private System.Windows.Forms.GroupBox _gbEventType;
        private System.Windows.Forms.ComboBox _cbEventType;
        private System.Windows.Forms.GroupBox _gbAction1;
        private System.Windows.Forms.ComboBox _cbActionType1;
        private System.Windows.Forms.GroupBox _gbAction3;
        private System.Windows.Forms.ComboBox _cbActionType3;
        private System.Windows.Forms.GroupBox _gbAction2;
        private System.Windows.Forms.ComboBox _cbActionType2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox _tbComment;
        private System.Windows.Forms.Button _bCreateAIScript;
        private System.Windows.Forms.ComboBox _cbActionParam2_3;
        private System.Windows.Forms.ComboBox _cbActionParam2_2;
        private System.Windows.Forms.ComboBox _cbActionParam1_2;
        private System.Windows.Forms.ComboBox _cbActionParam3_2;
        private System.Windows.Forms.ComboBox _cbActionParam3_3;
        private System.Windows.Forms.ComboBox _cbActionParam1_3;
        private System.Windows.Forms.ComboBox _cbEventParametr2;
        private System.Windows.Forms.Label lEventType1;
        private System.Windows.Forms.Label lEventType2;
        private System.Windows.Forms.Label lEventType4;
        private System.Windows.Forms.Label lEventType3;
        private System.Windows.Forms.Label lActionParam1_3;
        private System.Windows.Forms.Label lActionParam1_2;
        private System.Windows.Forms.Label lActionParam1_1;
        private System.Windows.Forms.Label lActionParam2_3;
        private System.Windows.Forms.Label lActionParam2_2;
        private System.Windows.Forms.Label lActionParam2_1;
        private System.Windows.Forms.Label lActionParam3_1;
        private System.Windows.Forms.Label lActionParam3_3;
        private System.Windows.Forms.Label lActionParam3_2;
        private System.Windows.Forms.Label lDateTime;
        private System.Windows.Forms.TabPage _tpText;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TextBox _tbTextContentDefault;
        private System.Windows.Forms.ComboBox _cbLocale;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox _cbLenguage;
        private System.Windows.Forms.ComboBox _cbMessageType;
        private System.Windows.Forms.TextBox _tbTextID;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox _tbTextContentLocales;
        private System.Windows.Forms.TextBox _tbCommentAITexts;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button bCreateTextQuery;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label lDateTime2;
        private System.Windows.Forms.ComboBox _cbActionParam1_1;
        private System.Windows.Forms.ComboBox _cbActionParam3_1;
        private System.Windows.Forms.ComboBox _cbActionParam2_1;
        private System.Windows.Forms.CheckedListBox _clbEventFlag;
        private System.Windows.Forms.RichTextBox rtbScriptOut;
        private System.Windows.Forms.RichTextBox rtbTextOut;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.ListView _lvScripts;
        private System.Windows.Forms.GroupBox _gbEventFlag;
        private System.Windows.Forms.GroupBox _gbPhase;
        private System.Windows.Forms.ComboBox _cbEventParametr4;
        private System.Windows.Forms.ComboBox _cbEventParametr3;
        private System.Windows.Forms.ComboBox _cbEventParametr1;
        private System.Windows.Forms.CheckedListBox _clbPhase;
        private System.Windows.Forms.ContextMenuStrip _cmPhase;
        private System.Windows.Forms.ToolStripMenuItem UnselectALL;
        private System.Windows.Forms.ToolStripMenuItem SelectAll;
        private System.Windows.Forms.ToolStripMenuItem Revert;
        private System.Windows.Forms.ContextMenuStrip _cmFlag;
        private System.Windows.Forms.ToolStripMenuItem UnselectALL1;
        private System.Windows.Forms.ToolStripMenuItem SelectAll1;
        private System.Windows.Forms.ToolStripMenuItem Revert1;
        private System.Windows.Forms.TabPage _tpSummon;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox _tbFilterCreat;
        private System.Windows.Forms.TextBox _tbFilterNum;
        private System.Windows.Forms.ComboBox _cbFilteActionType;
        private System.Windows.Forms.ComboBox _cbFilteEventType;
        private System.Windows.Forms.Button _bFind;
        private System.Windows.Forms.Button _bTextSearch;
        private System.Windows.Forms.Button _bCreateSummon;
        private System.Windows.Forms.Button _bWriteSummon;
        private System.Windows.Forms.Button _bSummonSearch;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox _tbSummonSps;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox _tbSummonX;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox _tbSummonO;
        private System.Windows.Forms.TextBox _tbSummonZ;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox _tbSummonY;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox _tbSummonComment;
        private System.Windows.Forms.TextBox _tbSummonID;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.RichTextBox _rtbSummon;
        private System.Windows.Forms.ListView _lvSummon;
        private System.Windows.Forms.Button _bSoundSearch;
        private System.Windows.Forms.ComboBox _cbTextEmote;
        private System.Windows.Forms.ComboBox _cbSoundEntry;
        private System.Windows.Forms.ColumnHeader columnHeader39;
        private System.Windows.Forms.ColumnHeader columnHeader40;
        private System.Windows.Forms.ColumnHeader columnHeader41;
        private System.Windows.Forms.ColumnHeader columnHeader42;
        private System.Windows.Forms.ColumnHeader columnHeader43;
        private System.Windows.Forms.ColumnHeader columnHeader44;
        private System.Windows.Forms.ColumnHeader columnHeader45;
        public System.Windows.Forms.TabControl _tPanel;
        public System.Windows.Forms.ListView _lvText;
        private System.Windows.Forms.TabPage _tpGossip;
        private System.Windows.Forms.Button _bGossipSearch;
        private System.Windows.Forms.Panel _panelGossip_menu;
        private System.Windows.Forms.ListView _lvGossip_menu;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ListView _lvGossip_Creature;
        private System.Windows.Forms.ColumnHeader columnHeader54;
        private System.Windows.Forms.ColumnHeader columnHeader55;
        private System.Windows.Forms.Label _lblnpctext;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox _gbGossipMenu;
        private System.Windows.Forms.ComboBox _cbCondtion1Value_1;
        private System.Windows.Forms.Label lCondition1Val2;
        private System.Windows.Forms.Label lCondition1Val1;
        private System.Windows.Forms.ComboBox _cbCondtion1Value_2;
        private System.Windows.Forms.ComboBox _cbGossipCondtion_1;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox _GossipTextID;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox _tbGossipEntry;
        private System.Windows.Forms.ComboBox _cbCondtion2Value_1;
        private System.Windows.Forms.Label lCondition2Val2;
        private System.Windows.Forms.Label lCondition2Val1;
        private System.Windows.Forms.ComboBox _cbCondtion2Value_2;
        private System.Windows.Forms.ComboBox _cbGossipCondtion_2;
        private System.Windows.Forms.GroupBox _gbGossipCondtion2;
        private System.Windows.Forms.GroupBox _gbGossipCondtion1;
        private System.Windows.Forms.Button _bWriteFilesGossip;
        private System.Windows.Forms.Button _bCreateGossip;
        private System.Windows.Forms.RichTextBox rtbGossipMenuOut;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox _tbCreatureGossip;
        private System.Windows.Forms.TabPage _tpGossipOption;
        private System.Windows.Forms.ListView _lvNpc_text;
        private System.Windows.Forms.ListView _lvGossip_Option;
        private System.Windows.Forms.TextBox _tbFilterGossip;
        private System.Windows.Forms.RadioButton _rbGossip;
        private System.Windows.Forms.RadioButton _rbCreaure;
        private System.Windows.Forms.RadioButton _rbTextID;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.RadioButton _rbGossipMenuOption;
        private System.Windows.Forms.Button _bFilterMenuOption;
        private System.Windows.Forms.TextBox _tbfilterGossipMenu;
        private System.Windows.Forms.GroupBox _gbGossipMenuOption;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox _tbGossipID;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox _tbGossipMenuID;
        private System.Windows.Forms.ComboBox _cbGossipOptionIcon;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox _tbGossipOptionText;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox _tbGossipAction;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox _tbGossipPOI_id;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox _tbGossipNpcMenu;
        private System.Windows.Forms.ComboBox _cbGossipOptionNpcFlag;
        private System.Windows.Forms.ComboBox _cbGossipOptionID;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox _tbGossipBoxMoney;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox _tbGossipBoxCoded;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox _tbGossipBoxText;
        private System.Windows.Forms.GroupBox _gbGossipOptionCondtion3;
        private System.Windows.Forms.ComboBox _cbOptionCondtion3Value_1;
        private System.Windows.Forms.ComboBox _cbGossipOptionCondtion_3;
        private System.Windows.Forms.ComboBox _cbOptionCondtion3Value_2;
        private System.Windows.Forms.Label lGossipOptionCondtion3Val1;
        private System.Windows.Forms.Label lGossipOptionCondtion3Val2;
        private System.Windows.Forms.GroupBox _gbGossipOptionCondtion2;
        private System.Windows.Forms.ComboBox _cbOptionCondtion2Value_1;
        private System.Windows.Forms.ComboBox _cbGossipOptionCondtion_2;
        private System.Windows.Forms.ComboBox _cbOptionCondtion2Value_2;
        private System.Windows.Forms.Label lGossipOptionCondtion2Val1;
        private System.Windows.Forms.Label lGossipOptionCondtion2Val2;
        private System.Windows.Forms.GroupBox _gbGossipOptionCondtion1;
        private System.Windows.Forms.ComboBox _cbGossipOptionCondtion_1;
        private System.Windows.Forms.ComboBox _cbOptionCondtion1Value_2;
        private System.Windows.Forms.Label lGossipOptionCondtion1Val1;
        private System.Windows.Forms.Label lGossipOptionCondtion1Val2;
        private System.Windows.Forms.ComboBox _cbOptionCondtion1Value_1;
        private System.Windows.Forms.RichTextBox rtbGossipOptionMenuOut;
        private System.Windows.Forms.Button _bGossipOptionCreate;
        private System.Windows.Forms.Button _bGossipOptionRecord;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TabPage _tbNpcText;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Button _bFilterNpcText;
        private System.Windows.Forms.TextBox _tbFilterNpcText;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.ListView _lvNpcText;
        private System.Windows.Forms.GroupBox _gpText;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox _tbNpc_textID;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox _tbNpc_text0_0;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox _tbNpc_text0_1;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox _tbNpc_textProb0;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox _tbNpc_textEm0_0;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox _tbNpc_textEm0_5;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox _tbNpc_textEm0_4;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox _tbNpc_textEm0_3;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox _tbNpc_textEm0_2;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox _tbNpc_textEm0_1;
        private System.Windows.Forms.RichTextBox rtbNpcTextOut;
        private System.Windows.Forms.Button bNpcTextCreate;
        private System.Windows.Forms.Button bNpcTextRecord;
        private System.Windows.Forms.ComboBox _cbNpc_textLang0;
        private System.Windows.Forms.ComboBox _cbNpc_textLang1;
        private System.Windows.Forms.TextBox _tbNpc_text1_1;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox _tbNpc_textEm1_1;
        private System.Windows.Forms.TextBox _tbNpc_text1_0;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox _tbNpc_textEm1_2;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TextBox _tbNpc_textProb1;
        private System.Windows.Forms.TextBox _tbNpc_textEm1_4;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TextBox _tbNpc_textEm1_3;
        private System.Windows.Forms.TextBox _tbNpc_textEm1_0;
        private System.Windows.Forms.TextBox _tbNpc_textEm1_5;
        private System.Windows.Forms.TextBox _tbNpc_textEm2_5;
        private System.Windows.Forms.ComboBox _cbNpc_textLang2;
        private System.Windows.Forms.TextBox _tbNpc_text2_1;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.TextBox _tbNpc_textEm2_1;
        private System.Windows.Forms.TextBox _tbNpc_text2_0;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.TextBox _tbNpc_textEm2_2;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.TextBox _tbNpc_textProb2;
        private System.Windows.Forms.TextBox _tbNpc_textEm2_4;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.TextBox _tbNpc_textEm2_3;
        private System.Windows.Forms.TextBox _tbNpc_textEm2_0;
        private System.Windows.Forms.TextBox _tbNpc_textEm5_5;
        private System.Windows.Forms.ComboBox _cbNpc_textLang5;
        private System.Windows.Forms.TextBox _tbNpc_text5_1;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.TextBox _tbNpc_textEm5_1;
        private System.Windows.Forms.TextBox _tbNpc_text5_0;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.TextBox _tbNpc_textEm5_2;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.TextBox _tbNpc_textProb5;
        private System.Windows.Forms.TextBox _tbNpc_textEm5_4;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.TextBox _tbNpc_textEm5_3;
        private System.Windows.Forms.TextBox _tbNpc_textEm5_0;
        private System.Windows.Forms.TextBox _tbNpc_textEm4_5;
        private System.Windows.Forms.ComboBox _cbNpc_textLang4;
        private System.Windows.Forms.TextBox _tbNpc_text4_1;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.TextBox _tbNpc_textEm4_1;
        private System.Windows.Forms.TextBox _tbNpc_text4_0;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.TextBox _tbNpc_textEm4_2;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.TextBox _tbNpc_textProb4;
        private System.Windows.Forms.TextBox _tbNpc_textEm4_4;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.TextBox _tbNpc_textEm4_3;
        private System.Windows.Forms.TextBox _tbNpc_textEm4_0;
        private System.Windows.Forms.ComboBox _cbNpc_textLang3;
        private System.Windows.Forms.TextBox _tbNpc_text3_1;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.TextBox _tbNpc_textEm3_1;
        private System.Windows.Forms.TextBox _tbNpc_text3_0;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.TextBox _tbNpc_textEm3_5;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.TextBox _tbNpc_textEm3_2;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.TextBox _tbNpc_textProb3;
        private System.Windows.Forms.TextBox _tbNpc_textEm3_4;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.TextBox _tbNpc_textEm3_3;
        private System.Windows.Forms.TextBox _tbNpc_textEm3_0;
        private System.Windows.Forms.TextBox _tbNpc_textEm6_5;
        private System.Windows.Forms.ComboBox _cbNpc_textLang6;
        private System.Windows.Forms.TextBox _tbNpc_text6_1;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.TextBox _tbNpc_textEm6_1;
        private System.Windows.Forms.TextBox _tbNpc_text6_0;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.TextBox _tbNpc_textEm6_2;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.TextBox _tbNpc_textProb6;
        private System.Windows.Forms.TextBox _tbNpc_textEm6_4;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.TextBox _tbNpc_textEm6_3;
        private System.Windows.Forms.TextBox _tbNpc_textEm6_0;
        private System.Windows.Forms.TextBox _tbNpc_textEm7_5;
        private System.Windows.Forms.ComboBox _cbNpc_textLang7;
        private System.Windows.Forms.TextBox _tbNpc_text7_1;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.TextBox _tbNpc_textEm7_1;
        private System.Windows.Forms.TextBox _tbNpc_text7_0;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.TextBox _tbNpc_textEm7_2;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.TextBox _tbNpc_textProb7;
        private System.Windows.Forms.TextBox _tbNpc_textEm7_4;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.TextBox _tbNpc_textEm7_3;
        private System.Windows.Forms.TextBox _tbNpc_textEm7_0;
        private System.Windows.Forms.Panel pMain;
    }
}

