﻿namespace EventAI
{
    partial class FormDbSearch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormDbSearch));
            this._lvData = new System.Windows.Forms.ListView();
            this._bCansel = new System.Windows.Forms.Button();
            this._bOk = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this._cbParam4 = new System.Windows.Forms.ComboBox();
            this._cbParam3 = new System.Windows.Forms.ComboBox();
            this._cbParam8 = new System.Windows.Forms.ComboBox();
            this._cbParam2 = new System.Windows.Forms.ComboBox();
            this._cbParam7 = new System.Windows.Forms.ComboBox();
            this._cbID = new System.Windows.Forms.ComboBox();
            this._cbParam6 = new System.Windows.Forms.ComboBox();
            this._cbParam5 = new System.Windows.Forms.ComboBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // _lvData
            // 
            this._lvData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this._lvData.Location = new System.Drawing.Point(0, 134);
            this._lvData.Name = "_lvData";
            this._lvData.Size = new System.Drawing.Size(759, 257);
            this._lvData.TabIndex = 0;
            this._lvData.UseCompatibleStateImageBehavior = false;
            this._lvData.View = System.Windows.Forms.View.Details;
            // 
            // _bCansel
            // 
            this._bCansel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this._bCansel.Location = new System.Drawing.Point(591, 397);
            this._bCansel.Name = "_bCansel";
            this._bCansel.Size = new System.Drawing.Size(75, 23);
            this._bCansel.TabIndex = 1;
            this._bCansel.Text = "Cancel";
            this._bCansel.UseVisualStyleBackColor = true;
            this._bCansel.Click += new System.EventHandler(this._bCansel_Click);
            // 
            // _bOk
            // 
            this._bOk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this._bOk.Location = new System.Drawing.Point(672, 397);
            this._bOk.Name = "_bOk";
            this._bOk.Size = new System.Drawing.Size(75, 23);
            this._bOk.TabIndex = 2;
            this._bOk.Text = "Yes";
            this._bOk.UseVisualStyleBackColor = true;
            this._bOk.Click += new System.EventHandler(this._bOk_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this._cbParam4);
            this.groupBox1.Controls.Add(this._cbParam3);
            this.groupBox1.Controls.Add(this._cbParam8);
            this.groupBox1.Controls.Add(this._cbParam2);
            this.groupBox1.Controls.Add(this._cbParam7);
            this.groupBox1.Controls.Add(this._cbID);
            this.groupBox1.Controls.Add(this._cbParam6);
            this.groupBox1.Controls.Add(this._cbParam5);
            this.groupBox1.Location = new System.Drawing.Point(11, 8);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(735, 111);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(358, 87);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "Номер";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 87);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Номер";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 63);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Номер";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(358, 63);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 13);
            this.label8.TabIndex = 3;
            this.label8.Text = "Номер";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(358, 39);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 13);
            this.label7.TabIndex = 3;
            this.label7.Text = "Номер";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(358, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "Номер";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Номер";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Номер";
            // 
            // _cbParam4
            // 
            this._cbParam4.DropDownHeight = 400;
            this._cbParam4.FormattingEnabled = true;
            this._cbParam4.IntegralHeight = false;
            this._cbParam4.Location = new System.Drawing.Point(93, 84);
            this._cbParam4.Name = "_cbParam4";
            this._cbParam4.Size = new System.Drawing.Size(238, 21);
            this._cbParam4.TabIndex = 2;
            // 
            // _cbParam3
            // 
            this._cbParam3.DropDownHeight = 400;
            this._cbParam3.FormattingEnabled = true;
            this._cbParam3.IntegralHeight = false;
            this._cbParam3.Location = new System.Drawing.Point(93, 60);
            this._cbParam3.Name = "_cbParam3";
            this._cbParam3.Size = new System.Drawing.Size(238, 21);
            this._cbParam3.TabIndex = 2;
            // 
            // _cbParam8
            // 
            this._cbParam8.DropDownHeight = 400;
            this._cbParam8.FormattingEnabled = true;
            this._cbParam8.IntegralHeight = false;
            this._cbParam8.Location = new System.Drawing.Point(469, 84);
            this._cbParam8.Name = "_cbParam8";
            this._cbParam8.Size = new System.Drawing.Size(238, 21);
            this._cbParam8.TabIndex = 2;
            // 
            // _cbParam2
            // 
            this._cbParam2.DropDownHeight = 400;
            this._cbParam2.FormattingEnabled = true;
            this._cbParam2.IntegralHeight = false;
            this._cbParam2.Location = new System.Drawing.Point(93, 36);
            this._cbParam2.Name = "_cbParam2";
            this._cbParam2.Size = new System.Drawing.Size(238, 21);
            this._cbParam2.TabIndex = 1;
            // 
            // _cbParam7
            // 
            this._cbParam7.DropDownHeight = 400;
            this._cbParam7.FormattingEnabled = true;
            this._cbParam7.IntegralHeight = false;
            this._cbParam7.Location = new System.Drawing.Point(469, 60);
            this._cbParam7.Name = "_cbParam7";
            this._cbParam7.Size = new System.Drawing.Size(238, 21);
            this._cbParam7.TabIndex = 2;
            // 
            // _cbID
            // 
            this._cbID.DropDownHeight = 400;
            this._cbID.FormattingEnabled = true;
            this._cbID.IntegralHeight = false;
            this._cbID.Location = new System.Drawing.Point(93, 12);
            this._cbID.Name = "_cbID";
            this._cbID.Size = new System.Drawing.Size(238, 21);
            this._cbID.TabIndex = 0;
            // 
            // _cbParam6
            // 
            this._cbParam6.DropDownHeight = 400;
            this._cbParam6.FormattingEnabled = true;
            this._cbParam6.IntegralHeight = false;
            this._cbParam6.Location = new System.Drawing.Point(469, 36);
            this._cbParam6.Name = "_cbParam6";
            this._cbParam6.Size = new System.Drawing.Size(238, 21);
            this._cbParam6.TabIndex = 1;
            // 
            // _cbParam5
            // 
            this._cbParam5.DropDownHeight = 400;
            this._cbParam5.FormattingEnabled = true;
            this._cbParam5.IntegralHeight = false;
            this._cbParam5.Location = new System.Drawing.Point(469, 12);
            this._cbParam5.Name = "_cbParam5";
            this._cbParam5.Size = new System.Drawing.Size(238, 21);
            this._cbParam5.TabIndex = 0;
            // 
            // FormDbSearch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(759, 427);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this._bOk);
            this.Controls.Add(this._bCansel);
            this.Controls.Add(this._lvData);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormDbSearch";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "FormDbSearch";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView _lvData;
        private System.Windows.Forms.Button _bCansel;
        private System.Windows.Forms.Button _bOk;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox _cbParam4;
        private System.Windows.Forms.ComboBox _cbParam3;
        private System.Windows.Forms.ComboBox _cbParam8;
        private System.Windows.Forms.ComboBox _cbParam2;
        private System.Windows.Forms.ComboBox _cbParam7;
        private System.Windows.Forms.ComboBox _cbID;
        private System.Windows.Forms.ComboBox _cbParam6;
        private System.Windows.Forms.ComboBox _cbParam5;
    }
}